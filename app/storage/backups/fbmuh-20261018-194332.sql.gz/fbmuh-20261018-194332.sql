/*FBMUH BACKUP 20261018-194332*/
SET NAMES utf8mb4;
/*FBEND*/
SET FOREIGN_KEY_CHECKS=0;
/*FBEND*/
DROP TABLE IF EXISTS `accounts`;
/*FBEND*/
CREATE TABLE `accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `kind` enum('bank','cash') NOT NULL DEFAULT 'bank',
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `iban` varchar(40) DEFAULT NULL,
  `opening_minor` bigint(20) NOT NULL DEFAULT 0,
  `opening_date` date NOT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT 0,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ac_t` (`tenant_id`),
  KEY `fk_ac_w` (`workspace_id`),
  CONSTRAINT `fk_ac_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`),
  CONSTRAINT `fk_ac_w` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `accounts` VALUES ('1','1','1',NULL,'Ana Banka TL','bank','Test Bank','TRY',NULL,'5000000','2026-01-01','0','0','2026-10-18 19:42:33'),('2','1','1',NULL,'Kasa TL','cash',NULL,'TRY',NULL,'0','2026-01-01','0','0','2026-10-18 19:42:33'),('3','1','1',NULL,'Banka EUR','bank',NULL,'EUR',NULL,'100000','2026-01-01','0','0','2026-10-18 19:42:33'),('4','1','1',NULL,'Banka USD','bank',NULL,'USD',NULL,'200000','2026-01-01','0','0','2026-10-18 19:42:33'),('5','1','2',NULL,'Şahsi Banka','bank',NULL,'TRY',NULL,'1000000','2026-01-01','0','0','2026-10-18 19:42:34'),('6','1','1',NULL,'IBANlı','bank',NULL,'TRY','TR330006100519786457841326','0','2026-01-01','0','0','2026-10-18 19:42:34'),('7','2','3',NULL,'Beta Banka','bank',NULL,'TRY',NULL,'100','2026-01-01','0','0','2026-10-18 19:42:38');
/*FBEND*/
DROP TABLE IF EXISTS `audit_log`;
/*FBEND*/
CREATE TABLE `audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ts` datetime NOT NULL,
  `actor_user_id` bigint(20) unsigned DEFAULT NULL,
  `actor_role` varchar(20) DEFAULT NULL,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `category` enum('security','admin','data','access','system') NOT NULL,
  `action` varchar(80) NOT NULL,
  `entity` varchar(60) DEFAULT NULL,
  `entity_id` varchar(40) DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `prev_hash` char(64) NOT NULL,
  `hash` char(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_audit_tenant` (`tenant_id`,`id`),
  KEY `ix_audit_cat` (`category`,`id`),
  KEY `ix_audit_actor` (`actor_user_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `audit_log` VALUES ('1','2026-10-18 19:40:16','1','admin',NULL,'admin','admin_created','user','1',NULL,'installer','0000000000000000000000000000000000000000000000000000000000000000','1c56a94379d28309f23779fab5ebba320a44afeff41d7c9bd547de0aad2e4e40'),('2','2026-10-18 19:40:17','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','1c56a94379d28309f23779fab5ebba320a44afeff41d7c9bd547de0aad2e4e40','c699ac07cf5da9f12a060f91ce6077b2ce9df59d0d602a0bb3bff13d2aa72874'),('3','2026-10-18 19:40:17','1','admin',NULL,'security','2fa_enabled',NULL,NULL,NULL,'127.0.0.1','c699ac07cf5da9f12a060f91ce6077b2ce9df59d0d602a0bb3bff13d2aa72874','2c5d551212e2c3aacac982a7f108efbc4255fcf32a8d064b4d8f689c0d4d2f69'),('4','2026-10-18 19:40:17','1',NULL,NULL,'security','2fa_failed',NULL,NULL,NULL,'127.0.0.1','2c5d551212e2c3aacac982a7f108efbc4255fcf32a8d064b4d8f689c0d4d2f69','9cff67b49ecbb97249a44a9daa6228bd62710f088bf8f450cde05431503ba1fc'),('5','2026-10-18 19:40:17','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','9cff67b49ecbb97249a44a9daa6228bd62710f088bf8f450cde05431503ba1fc','bcee84c06b2ef4cf479bc56000b96d441c30a2b55d2bce530c9e0fe45cd0065e'),('6','2026-10-18 19:40:32','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','bcee84c06b2ef4cf479bc56000b96d441c30a2b55d2bce530c9e0fe45cd0065e','9812798a63d75461ac10d297d97c1e51014b89f40020b54f9aad389169adf0bd'),('7','2026-10-18 19:41:02','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','9812798a63d75461ac10d297d97c1e51014b89f40020b54f9aad389169adf0bd','613853052d3c4ff38735b528ef0112e901fcacbd2fe0355dc2902446b5360e27'),('8','2026-10-18 19:41:02','1','admin',NULL,'security','logout',NULL,NULL,NULL,'127.0.0.1','613853052d3c4ff38735b528ef0112e901fcacbd2fe0355dc2902446b5360e27','80d2adf3b141dd9ec14bc34f92f67ee2d8af375d145bb7b75232cb7b67109270'),('9','2026-10-18 19:41:30','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','80d2adf3b141dd9ec14bc34f92f67ee2d8af375d145bb7b75232cb7b67109270','181de9a7e2a859f1ea5bed7ca4de67e5beb7fd5937a6babcce6f7331666d178d'),('10','2026-10-18 19:42:00','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','181de9a7e2a859f1ea5bed7ca4de67e5beb7fd5937a6babcce6f7331666d178d','7ac737b397c36cfa12fce0a3140c497f3ec5cf94612e727942aefc2ca7e0ac19'),('11','2026-10-18 19:42:30','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','7ac737b397c36cfa12fce0a3140c497f3ec5cf94612e727942aefc2ca7e0ac19','f9af5177bbb4ae3b444694620aaa7585495a3dfc59cfbe868867242ce830bd01'),('12','2026-10-18 19:42:30',NULL,NULL,NULL,'security','login_failed',NULL,NULL,'{\"id\":\"bf7af0996800\",\"reason\":\"unknown\"}','127.0.0.1','f9af5177bbb4ae3b444694620aaa7585495a3dfc59cfbe868867242ce830bd01','e4931ce6bc15e81f7f5aaf9b026a3832a1f1e0cc714b7a01d4b9682f1a289ac3'),('13','2026-10-18 19:42:31','1','admin','1','admin','tenant_created','tenant','1','{\"mode\":\"invite\",\"email\":\"alfa@test.local\"}','127.0.0.1','e4931ce6bc15e81f7f5aaf9b026a3832a1f1e0cc714b7a01d4b9682f1a289ac3','65781d9ed484eff0b320bdcb0e267f4f6b49b33737fcfcd9a34d3152a859dbd7'),('14','2026-10-18 19:42:31','1','admin','2','admin','tenant_created','tenant','2','{\"mode\":\"temp\",\"email\":\"beta@test.local\"}','127.0.0.1','65781d9ed484eff0b320bdcb0e267f4f6b49b33737fcfcd9a34d3152a859dbd7','513a5f4a1df4bfd66f05f40cfbf0cfcd2d8f54969e86f48f9dffb04f4da85d9d'),('15','2026-10-18 19:42:31','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','513a5f4a1df4bfd66f05f40cfbf0cfcd2d8f54969e86f48f9dffb04f4da85d9d','3a1eee17299bd97f0f1071ff78e2402dd7ea3224ed117ce7c2f3c6593a2c630a'),('16','2026-10-18 19:42:31','3','customer','2','security','password_change_failed',NULL,NULL,NULL,'127.0.0.1','3a1eee17299bd97f0f1071ff78e2402dd7ea3224ed117ce7c2f3c6593a2c630a','686cfd749e269c100f3ce375016ec375f669014b7aaf14c7a7b03b2a5389e6b6'),('17','2026-10-18 19:42:31','3','customer','2','security','password_changed',NULL,NULL,NULL,'127.0.0.1','686cfd749e269c100f3ce375016ec375f669014b7aaf14c7a7b03b2a5389e6b6','ccc4425e3508d3bb769dcdf42f71f68bc6d69252898a15c66a0497e155d50d8f'),('18','2026-10-18 19:42:31','2','customer','1','security','invite_accepted',NULL,NULL,NULL,'127.0.0.1','ccc4425e3508d3bb769dcdf42f71f68bc6d69252898a15c66a0497e155d50d8f','1a19edc27596885c835cbff8ae2e5526059ab19b35372c12d913267e640b487b'),('19','2026-10-18 19:42:31','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','1a19edc27596885c835cbff8ae2e5526059ab19b35372c12d913267e640b487b','5c0701141d87e56c1911063f616accf453a9dc776f10846cf533e7c91d94625b'),('20','2026-10-18 19:42:31','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','5c0701141d87e56c1911063f616accf453a9dc776f10846cf533e7c91d94625b','85cc09365abf3a682f455214a9f4692d086540abc6a4b49bb4f75c0d5f0790af'),('21','2026-10-18 19:42:31','2','customer','1','security','admin_endpoint_denied','route','/admin/overview',NULL,'127.0.0.1','85cc09365abf3a682f455214a9f4692d086540abc6a4b49bb4f75c0d5f0790af','77884d39fe239309350eb60f0c17385d46570770583952917acbf96fe5820572'),('22','2026-10-18 19:42:31','2','customer','1','security','admin_endpoint_denied','route','/admin/tenants',NULL,'127.0.0.1','77884d39fe239309350eb60f0c17385d46570770583952917acbf96fe5820572','c772fe03707452ef3b46f121c026db2c4b282add6eac9238bfc920a4ccd13eb5'),('23','2026-10-18 19:42:32','2','customer','1','security','admin_endpoint_denied','route','/admin/tenants',NULL,'127.0.0.1','c772fe03707452ef3b46f121c026db2c4b282add6eac9238bfc920a4ccd13eb5','ebbbed46352a3ff053ae2206363e3573cc3cddc530150e611b6653674797a562'),('24','2026-10-18 19:42:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','ebbbed46352a3ff053ae2206363e3573cc3cddc530150e611b6653674797a562','64d0afb9fb4564f2e687b89d46e5ced2c49770710a15dc4b4f7718fb2ffbdc37'),('25','2026-10-18 19:42:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','64d0afb9fb4564f2e687b89d46e5ced2c49770710a15dc4b4f7718fb2ffbdc37','2aeee19c25f2f06b7f518bf262ea3c967255a878183275806f5c739252597193'),('26','2026-10-18 19:42:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','2aeee19c25f2f06b7f518bf262ea3c967255a878183275806f5c739252597193','69b557485ad1acebde66c5a507e1f977c93fd3f87e76a78b056e77417befa759'),('27','2026-10-18 19:42:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','69b557485ad1acebde66c5a507e1f977c93fd3f87e76a78b056e77417befa759','8a89ab4c5255e45383d44963b280821a84b20008432a4db6af48a223de00dc38'),('28','2026-10-18 19:42:32','2',NULL,'1','security','account_locked',NULL,NULL,'{\"level\":1}','127.0.0.1','8a89ab4c5255e45383d44963b280821a84b20008432a4db6af48a223de00dc38','8635a85a1442c8cc7c0792d367c3c2fdcacfd03c78484553e84c05f0522a4fd5'),('29','2026-10-18 19:42:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','8635a85a1442c8cc7c0792d367c3c2fdcacfd03c78484553e84c05f0522a4fd5','8ba651c33e5caac7b787ad28c24cf12f50d02c38a70f0b60d57e83182b85d484'),('30','2026-10-18 19:42:32','2',NULL,'1','security','login_locked',NULL,NULL,NULL,'127.0.0.1','8ba651c33e5caac7b787ad28c24cf12f50d02c38a70f0b60d57e83182b85d484','0e7fec7c75d5dadd7a6a400eeab1b74b11c2aaa68e4b9fd6ca73b9f67b169dad'),('31','2026-10-18 19:42:32','1','admin','1','admin','tenant_unlocked',NULL,NULL,NULL,'127.0.0.1','0e7fec7c75d5dadd7a6a400eeab1b74b11c2aaa68e4b9fd6ca73b9f67b169dad','eb1973509b4527365f51a4e97cdb0862a61cc2e047edd3c38ffd756723e2451f'),('32','2026-10-18 19:42:32','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','eb1973509b4527365f51a4e97cdb0862a61cc2e047edd3c38ffd756723e2451f','b98e9ec7fce6657c5937f3c2e4247466f22db6324e9aaae7b65f5f9481844e1d'),('33','2026-10-18 19:42:32','2',NULL,'1','security','password_reset_requested',NULL,NULL,NULL,'127.0.0.1','b98e9ec7fce6657c5937f3c2e4247466f22db6324e9aaae7b65f5f9481844e1d','c67c927627db40d8695ec42b0323a109479fb2137d2b2a60b5f1e9b18fdda401'),('34','2026-10-18 19:42:33','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','c67c927627db40d8695ec42b0323a109479fb2137d2b2a60b5f1e9b18fdda401','c65caadfdec63565afcab29476ef711965d4bcc5dfc0eb3b9451a6a00afb59fa'),('35','2026-10-18 19:42:33','2','customer','1','security','password_reset_done',NULL,NULL,NULL,'127.0.0.1','c65caadfdec63565afcab29476ef711965d4bcc5dfc0eb3b9451a6a00afb59fa','ba766bc6aff4e3021bbda6a98bf091285953474e04d143d7d3dd76f864aaad25'),('36','2026-10-18 19:42:33','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','ba766bc6aff4e3021bbda6a98bf091285953474e04d143d7d3dd76f864aaad25','1239a1b654c965909db194d1633f5571d0d1bf1f453bfaea008883b8005cc9cf'),('37','2026-10-18 19:42:33','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','1239a1b654c965909db194d1633f5571d0d1bf1f453bfaea008883b8005cc9cf','348737cbfa840f6197ec8b9b6c56c4acdcc2393043ee08fd4006c232802fcb5e'),('38','2026-10-18 19:42:33','1','admin','2','admin','tenant_status_suspended','tenant','2','{\"from\":\"active\"}','127.0.0.1','348737cbfa840f6197ec8b9b6c56c4acdcc2393043ee08fd4006c232802fcb5e','f6ef9cf33e42204a976346428de889582bfcc1aaa9856a93ef1a17bca7188686'),('39','2026-10-18 19:42:33','3',NULL,'2','security','login_blocked_suspended',NULL,NULL,NULL,'127.0.0.1','f6ef9cf33e42204a976346428de889582bfcc1aaa9856a93ef1a17bca7188686','13e2804f88976c17bd21414110abbc3131392cf3c6db6971770493ed2ee690f6'),('40','2026-10-18 19:42:33','1','admin','2','admin','tenant_status_active','tenant','2','{\"from\":\"suspended\"}','127.0.0.1','13e2804f88976c17bd21414110abbc3131392cf3c6db6971770493ed2ee690f6','e94f11808a8374ec957c948d3599810337ab389df4e77ddfce87458b29bfe02b'),('41','2026-10-18 19:42:33','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','e94f11808a8374ec957c948d3599810337ab389df4e77ddfce87458b29bfe02b','42c8150c87d414726031ba0811b9dfa9ed897c5e3298e6f0931dd9e2b1a51387'),('42','2026-10-18 19:42:33','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','42c8150c87d414726031ba0811b9dfa9ed897c5e3298e6f0931dd9e2b1a51387','d9c16495dc85384263da52ad01a5b3cef15eaea1b27fd7abe158360e4f4c90a7'),('43','2026-10-18 19:42:33','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','d9c16495dc85384263da52ad01a5b3cef15eaea1b27fd7abe158360e4f4c90a7','b389661aece1583fb35e0fb689235ccb484bc29a0824b2456e3c4b6458ff8bfb'),('44','2026-10-18 19:42:33','2','customer','1','data','workspace_created','workspace','1',NULL,'127.0.0.1','b389661aece1583fb35e0fb689235ccb484bc29a0824b2456e3c4b6458ff8bfb','de6c14c31b150a9383245aab4cc651e2ed6da5c0da0985c3809a552b3dc9cbe7'),('45','2026-10-18 19:42:33','2','customer','1','data','workspace_created','workspace','2',NULL,'127.0.0.1','de6c14c31b150a9383245aab4cc651e2ed6da5c0da0985c3809a552b3dc9cbe7','745f7cb6ad16d0c73021777f144f6a985120b82f6d79fd449205b541e39cd7ed'),('46','2026-10-18 19:42:33','2','customer','1','data','account_created','account','1','{\"opening_minor\":5000000}','127.0.0.1','745f7cb6ad16d0c73021777f144f6a985120b82f6d79fd449205b541e39cd7ed','a3f01d7e071a187f27cc1d5fe8387a7f165b80b4f1fceb1dfea7bd5aba26ba9b'),('47','2026-10-18 19:42:33','2','customer','1','data','account_created','account','2','{\"opening_minor\":0}','127.0.0.1','a3f01d7e071a187f27cc1d5fe8387a7f165b80b4f1fceb1dfea7bd5aba26ba9b','ea8daf657b0e7c921f02c75e0585c7718b6aa4d5f8bae7ea7e1b683d9fca13ad'),('48','2026-10-18 19:42:33','2','customer','1','data','account_created','account','3','{\"opening_minor\":100000}','127.0.0.1','ea8daf657b0e7c921f02c75e0585c7718b6aa4d5f8bae7ea7e1b683d9fca13ad','ea45776387ff26671f9cd9f67fde40fb655b9b45ffe081651155e6e80315551e'),('49','2026-10-18 19:42:33','2','customer','1','data','account_created','account','4','{\"opening_minor\":200000}','127.0.0.1','ea45776387ff26671f9cd9f67fde40fb655b9b45ffe081651155e6e80315551e','ea2c4b85a3d2641594b323b95a3df5076d4fcfb9bfb6903a62d7c733eae9dad0'),('50','2026-10-18 19:42:34','2','customer','1','data','account_created','account','5','{\"opening_minor\":1000000}','127.0.0.1','ea2c4b85a3d2641594b323b95a3df5076d4fcfb9bfb6903a62d7c733eae9dad0','ce6b6f5626eb4b924f20fc7dc19f5e0c5b166b1da7cd2a4bb2dab64bff674477'),('51','2026-10-18 19:42:34','2','customer','1','data','account_created','account','6','{\"opening_minor\":0}','127.0.0.1','ce6b6f5626eb4b924f20fc7dc19f5e0c5b166b1da7cd2a4bb2dab64bff674477','6bd7a0164eb4b57c867f5bd1e7dd03abd30132a3c1e5cf194206e95bc6fbdec7'),('52','2026-10-18 19:42:34','2','customer','1','data','contact_created','contact','1',NULL,'127.0.0.1','6bd7a0164eb4b57c867f5bd1e7dd03abd30132a3c1e5cf194206e95bc6fbdec7','7c1970e8e27692965d3646f93ee21b5a6f98c22a8b4581d1c40c147b4d9f4eca'),('53','2026-10-18 19:42:34','2','customer','1','data','contact_created','contact','2',NULL,'127.0.0.1','7c1970e8e27692965d3646f93ee21b5a6f98c22a8b4581d1c40c147b4d9f4eca','4cf66c5c67fb4430051d58cd5d95cb2e485035d5998dca961587016798c7e8d4'),('54','2026-10-18 19:42:34','2','customer','1','data','entry_created','entry','1','{\"kind\":\"receivable\",\"amount_minor\":10000000,\"installments\":1}','127.0.0.1','4cf66c5c67fb4430051d58cd5d95cb2e485035d5998dca961587016798c7e8d4','d500aec1c5a175065a25471e0a887c93f72cc2f1a26bf44493147c1cbffb7f68'),('55','2026-10-18 19:42:34','2','customer','1','data','collection_created','entry','1','{\"txn\":1,\"amount_minor\":6000000}','127.0.0.1','d500aec1c5a175065a25471e0a887c93f72cc2f1a26bf44493147c1cbffb7f68','e49f6fd0ce5deba61027aef314ab06e485b4da66c9e2497bb83ecbf4e202bf39'),('56','2026-10-18 19:42:34','2','customer','1','data','collection_created','entry','1','{\"txn\":2,\"amount_minor\":4000000}','127.0.0.1','e49f6fd0ce5deba61027aef314ab06e485b4da66c9e2497bb83ecbf4e202bf39','937b760e95f24967f760eca11dd59edf6260a8e23aee39641ab4d9d05ba6953b'),('57','2026-10-18 19:42:34','2','customer','1','data','transfer_created','transfer','cdb49f8568ef8432f531452186','{\"from\":1,\"to\":2,\"amount_minor\":2000000}','127.0.0.1','937b760e95f24967f760eca11dd59edf6260a8e23aee39641ab4d9d05ba6953b','c3639eab8102abfa69ec449fc14551088dddba65e85177fd0f8dd42a8956470f'),('58','2026-10-18 19:42:34','2','customer','1','data','entry_created','entry','2','{\"kind\":\"payable\",\"amount_minor\":500000,\"installments\":1}','127.0.0.1','c3639eab8102abfa69ec449fc14551088dddba65e85177fd0f8dd42a8956470f','3abb2aa5ef4ca5df03fe7661c85b2ed2427bb6e192e688d70a4de8527176eb3c'),('59','2026-10-18 19:42:34','2','customer','1','data','invoice_created','invoice','1','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":120000}','127.0.0.1','3abb2aa5ef4ca5df03fe7661c85b2ed2427bb6e192e688d70a4de8527176eb3c','0701acff3b0bb8e19c8e1eb33081c37d83ba49b9ea6368faf3094452746e7f5a'),('60','2026-10-18 19:42:34','2','customer','1','data','collection_created','entry','5','{\"txn\":5,\"amount_minor\":120000}','127.0.0.1','0701acff3b0bb8e19c8e1eb33081c37d83ba49b9ea6368faf3094452746e7f5a','b1f7f55104fbcb7ed56841061b7042df3787609c9a20ae943f831b141446c0d9'),('61','2026-10-18 19:42:35','2','customer','1','data','entry_created','entry','7','{\"kind\":\"receivable\",\"amount_minor\":50000,\"installments\":1}','127.0.0.1','b1f7f55104fbcb7ed56841061b7042df3787609c9a20ae943f831b141446c0d9','5ed3bd2fc91b18c96d075162b11d1ae9d266bf6e9fa32c88b7969a0733d7eb39'),('62','2026-10-18 19:42:35','2','customer','1','data','fx_created','transfer','1229d0cf2ed6fb5ccd697deae8','{\"out\":1000000,\"in\":25000,\"rate\":\"0.02500000\",\"fee\":1500}','127.0.0.1','5ed3bd2fc91b18c96d075162b11d1ae9d266bf6e9fa32c88b7969a0733d7eb39','e1d4a650c2da9f6eb3b848f9f17408625c8101883ff4452b94f48d504574838a'),('63','2026-10-18 19:42:35','2','customer','1','data','entry_created','entry','8','{\"kind\":\"payable\",\"amount_minor\":1000000,\"installments\":1}','127.0.0.1','e1d4a650c2da9f6eb3b848f9f17408625c8101883ff4452b94f48d504574838a','faf5a0f449294b6416a87ba71b8123ab2c21b861894f1f52c4c5c9422dafef14'),('64','2026-10-18 19:42:35','2','customer','1','data','payment_created','entry','8','{\"txn\":9,\"amount_minor\":300000}','127.0.0.1','faf5a0f449294b6416a87ba71b8123ab2c21b861894f1f52c4c5c9422dafef14','b6d4595b9d629e7f6f5a294667b3a34b8120cab7e103de1fb7ac228d46971e05'),('65','2026-10-18 19:42:35','2','customer','1','data','entry_rescheduled','entry','8','{\"before\":{\"due_date\":\"2026-10-15\"},\"after\":{\"due_date\":\"2026-10-28\"}}','127.0.0.1','b6d4595b9d629e7f6f5a294667b3a34b8120cab7e103de1fb7ac228d46971e05','1ed9c5267b28111fbf424193b54a28f349e7d178715a3273731f14dbee9a5ad2'),('66','2026-10-18 19:42:35','2','customer','1','data','card_created','card','1',NULL,'127.0.0.1','1ed9c5267b28111fbf424193b54a28f349e7d178715a3273731f14dbee9a5ad2','492327d0f0fecb4e50320b0c04b904db56ebbfdb2f1e790cf4537ddcf8358096'),('67','2026-10-18 19:42:35','2','customer','1','data','card_purchase','card_purchase','1','{\"amount_minor\":120000,\"installments\":3}','127.0.0.1','492327d0f0fecb4e50320b0c04b904db56ebbfdb2f1e790cf4537ddcf8358096','f9f971557994902069ec661f0f4f48a85538b86e3ebf694be6fd8450699895b7'),('68','2026-10-18 19:42:35','2','customer','1','data','card_payment','card','1','{\"txn\":10,\"amount_minor\":40000}','127.0.0.1','f9f971557994902069ec661f0f4f48a85538b86e3ebf694be6fd8450699895b7','2c2ace01af573a11d6b46a4d2b7e5ec060539130ab9a839cc72b2d5270953d54'),('69','2026-10-18 19:42:35','2','customer','1','data','loan_created','loan','1','{\"principal_minor\":12000000,\"term\":12}','127.0.0.1','2c2ace01af573a11d6b46a4d2b7e5ec060539130ab9a839cc72b2d5270953d54','f05979b5523b11170544c6eac1e81f4dd24797771bc4bed0c49c58ab46664602'),('70','2026-10-18 19:42:36','2','customer','1','data','loan_payment','loan','1','{\"txn\":12,\"seq\":1}','127.0.0.1','f05979b5523b11170544c6eac1e81f4dd24797771bc4bed0c49c58ab46664602','1914117e532f9411af810a6db8606f72048fe74604148a013fec7d451c0179d9'),('71','2026-10-18 19:42:36','2','customer','1','data','entry_created','entry','9','{\"kind\":\"payable\",\"amount_minor\":80000,\"installments\":1}','127.0.0.1','1914117e532f9411af810a6db8606f72048fe74604148a013fec7d451c0179d9','915c6abc82e19862adea0d9469d071d234fa659eed44b358b988a595549f688b'),('72','2026-10-18 19:42:36','2','customer','1','data','statement_imported','account','1','{\"added\":3,\"duplicates\":0}','127.0.0.1','915c6abc82e19862adea0d9469d071d234fa659eed44b358b988a595549f688b','b8e6a62954d9e21f80fe773c513c2acafb0386dc672b599d1655c8ecda6f53b5'),('73','2026-10-18 19:42:36','2','customer','1','data','statement_imported','account','1','{\"added\":0,\"duplicates\":3}','127.0.0.1','b8e6a62954d9e21f80fe773c513c2acafb0386dc672b599d1655c8ecda6f53b5','e9544f9b8589a6f910df57e0d34ad578a45821a997c9662afa5fd5cc0193e258'),('74','2026-10-18 19:42:36','2','customer','1','data','statement_line_posted','statement_line','1','{\"txn\":13}','127.0.0.1','e9544f9b8589a6f910df57e0d34ad578a45821a997c9662afa5fd5cc0193e258','57fc628cdfca5af1426f0a460ec2ef922cc8d0bfc4b4f2f01b340e0305ad74bf'),('75','2026-10-18 19:42:36','2','customer','1','data','project_created','project','1',NULL,'127.0.0.1','57fc628cdfca5af1426f0a460ec2ef922cc8d0bfc4b4f2f01b340e0305ad74bf','e4cf66050b237f3816b0ee3d49c50f64c5042e90ddd6053751c6c849c05342c2'),('76','2026-10-18 19:42:36','2','customer','1','data','invoice_created','invoice','3','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":1200000}','127.0.0.1','e4cf66050b237f3816b0ee3d49c50f64c5042e90ddd6053751c6c849c05342c2','7cd2b145ace79a9226a7cd91269dc4f53943a792d85d1bbe1efc687684be7d67'),('77','2026-10-18 19:42:36','2','customer','1','data','collection_created','entry','10','{\"txn\":14,\"amount_minor\":1200000}','127.0.0.1','7cd2b145ace79a9226a7cd91269dc4f53943a792d85d1bbe1efc687684be7d67','50d999858dd0d1c386854ef7661ad861e513b06dabed94eadb599bb46c67a879'),('78','2026-10-18 19:42:36','2','customer','1','data','invoice_created','invoice','4','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":480000}','127.0.0.1','50d999858dd0d1c386854ef7661ad861e513b06dabed94eadb599bb46c67a879','55edf834b0d1e9eae0523d3de3f73857e18694792e718078b1c5565f4ff9c375'),('79','2026-10-18 19:42:36','2','customer','1','data','payment_created','entry','11','{\"txn\":15,\"amount_minor\":480000}','127.0.0.1','55edf834b0d1e9eae0523d3de3f73857e18694792e718078b1c5565f4ff9c375','8838843ab9374f88f7cf34fe1f4ca13c5238a22006020f48d724c5756bd6b259'),('80','2026-10-18 19:42:36','2','customer','1','data','transaction_created','transaction','16','{\"kind\":\"expense\",\"amount_minor\":50000,\"replaces\":null}','127.0.0.1','8838843ab9374f88f7cf34fe1f4ca13c5238a22006020f48d724c5756bd6b259','9e00b0265c3c873a10a9d3198c7967b4df1309311c7b4e7261739804441147fe'),('81','2026-10-18 19:42:36','2','customer','1','data','invoice_created','invoice','5','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":120000}','127.0.0.1','9e00b0265c3c873a10a9d3198c7967b4df1309311c7b4e7261739804441147fe','e820b3b393d3dddc8dae07512555ef10ab9d47b6747f5f8facaea9902132b28d'),('82','2026-10-18 19:42:36','2','customer','1','data','stock_movement','stock_movement','2','{\"kind\":\"out\",\"qty_milli\":2000}','127.0.0.1','e820b3b393d3dddc8dae07512555ef10ab9d47b6747f5f8facaea9902132b28d','bbdee6c5dd0480b26340faedf7cc0c0e2d1f8d4d740e2d3d26794e90b5e0b988'),('83','2026-10-18 19:42:36','2','customer','1','data','stock_movement','stock_movement','3','{\"kind\":\"out\",\"qty_milli\":9000}','127.0.0.1','bbdee6c5dd0480b26340faedf7cc0c0e2d1f8d4d740e2d3d26794e90b5e0b988','3f17a4c55c336bc24829423a7c186da5a6700ed17a344c42a84c4b37c721e27e'),('84','2026-10-18 19:42:36','2','customer','1','data','transaction_created','transaction','17','{\"kind\":\"income\",\"amount_minor\":100000,\"replaces\":null}','127.0.0.1','3f17a4c55c336bc24829423a7c186da5a6700ed17a344c42a84c4b37c721e27e','7c99f1e8d8e24c024853156179f6b1e859977d490fea038942ddef9cb68c983c'),('85','2026-10-18 19:42:37','2','customer','1','data','transaction_voided','transaction','17','{\"reason\":\"Hatalı giriş\",\"before\":{\"kind\":\"income\",\"amount_minor\":100000,\"date\":\"2026-10-18\",\"account_id\":1},\"legs\":[17]}','127.0.0.1','7c99f1e8d8e24c024853156179f6b1e859977d490fea038942ddef9cb68c983c','8713b4453b521f82fab97249355df1b6ef98aabd7393af34573fb9b54ca058b0'),('86','2026-10-18 19:42:37','2','customer','1','data','transaction_created','transaction','18','{\"kind\":\"expense\",\"amount_minor\":10000,\"replaces\":null}','127.0.0.1','8713b4453b521f82fab97249355df1b6ef98aabd7393af34573fb9b54ca058b0','b9a2780801976f1cdfb986169f8d5b1ae53bf59d10da3afa557bcfa4d6efed9f'),('87','2026-10-18 19:42:37','2','customer','1','data','transaction_voided','transaction','18','{\"reason\":\"Düzenleme ile yenisi oluşturuldu\",\"before\":{\"kind\":\"expense\",\"amount_minor\":10000,\"date\":\"2026-10-18\",\"account_id\":1},\"legs\":[18]}','127.0.0.1','b9a2780801976f1cdfb986169f8d5b1ae53bf59d10da3afa557bcfa4d6efed9f','3a97280008858ea556249801f4816a1e89fea4fd7f216a75562e99ed221bf7f9'),('88','2026-10-18 19:42:37','2','customer','1','data','transaction_replaced','transaction','19','{\"kind\":\"expense\",\"amount_minor\":12000,\"replaces\":18}','127.0.0.1','3a97280008858ea556249801f4816a1e89fea4fd7f216a75562e99ed221bf7f9','5a8a2d8cef470a7ef505d715bd3122cfc7a9613b3c0a175f771fa21e80bca759'),('89','2026-10-18 19:42:37','2','customer','1','data','transaction_created','transaction','20','{\"kind\":\"expense\",\"amount_minor\":120000,\"replaces\":null}','127.0.0.1','5a8a2d8cef470a7ef505d715bd3122cfc7a9613b3c0a175f771fa21e80bca759','e89e1532d57d79131bf0beac11b6b47b4a0b204107d29a964faeba4deb468b28'),('90','2026-10-18 19:42:37','2','customer','1','data','transaction_created','transaction','21','{\"kind\":\"expense\",\"amount_minor\":120000,\"replaces\":null}','127.0.0.1','e89e1532d57d79131bf0beac11b6b47b4a0b204107d29a964faeba4deb468b28','d481347108efda96070209d4a6672eace5384b0407a6130f9407ca4acd1c1db8'),('91','2026-10-18 19:42:37','2','customer','1','data','balance_adjusted','account','2','{\"delta_minor\":-5000,\"reason\":\"Sayım farkı\"}','127.0.0.1','d481347108efda96070209d4a6672eace5384b0407a6130f9407ca4acd1c1db8','19dc3a982b80920d9249bc8d36bf31bb0ef6c78ea4082e207cec14b1ca81095c'),('92','2026-10-18 19:42:38','3','customer','2','data','workspace_created','workspace','3',NULL,'127.0.0.1','19dc3a982b80920d9249bc8d36bf31bb0ef6c78ea4082e207cec14b1ca81095c','6a59416b9520e490109708e7bf0fd7f4b733501320b24dd9fc63791e2de4a0a7'),('93','2026-10-18 19:42:38','3','customer','2','data','account_created','account','7','{\"opening_minor\":100}','127.0.0.1','6a59416b9520e490109708e7bf0fd7f4b733501320b24dd9fc63791e2de4a0a7','e50b3e117df5932da26bac13d8b199569985f528b4ddd6e644acffc4b8111b8f'),('94','2026-10-18 19:42:38','2','customer','1','data','document_uploaded','transaction','18','{\"doc\":1,\"size\":70}','127.0.0.1','e50b3e117df5932da26bac13d8b199569985f528b4ddd6e644acffc4b8111b8f','783159aa399de02791a421824285a4b6fcb4b5f3051717e4653297407b61d25b'),('95','2026-10-18 19:42:38','2','customer','1','data','export_transactions',NULL,NULL,'{\"format\":\"csv\",\"rows\":20}','127.0.0.1','783159aa399de02791a421824285a4b6fcb4b5f3051717e4653297407b61d25b','c8bfebeae5a6b27d8908fd0181bbcbabb769b6c3fdffd142d8ad1aa636c74623'),('96','2026-10-18 19:42:38','2','customer','1','data','transaction_created','transaction','23','{\"kind\":\"expense\",\"amount_minor\":100,\"replaces\":null}','127.0.0.1','c8bfebeae5a6b27d8908fd0181bbcbabb769b6c3fdffd142d8ad1aa636c74623','6627a03babc267eb0a140a2f0597cc8167a7b65ce48db32995639aff8ff719d3'),('97','2026-10-18 19:42:38','2','customer','1','data','export_transactions',NULL,NULL,'{\"format\":\"csv\",\"rows\":21}','127.0.0.1','6627a03babc267eb0a140a2f0597cc8167a7b65ce48db32995639aff8ff719d3','0f4d5b264e46aa5473f9055a613f1ff5b57eb33d0c02713cdb79723ae1ae940d'),('98','2026-10-18 19:42:38','2','customer','1','data','export_income-expense',NULL,NULL,'{\"format\":\"xlsx\",\"rows\":1}','127.0.0.1','0f4d5b264e46aa5473f9055a613f1ff5b57eb33d0c02713cdb79723ae1ae940d','4f83d63b608c5a7ac757063a2e49624be0d6ce428334576ce7baad373770a483'),('99','2026-10-18 19:42:38','2','customer','1','data','export_vat',NULL,NULL,'{\"format\":\"csv\",\"rows\":4}','127.0.0.1','4f83d63b608c5a7ac757063a2e49624be0d6ce428334576ce7baad373770a483','45ddeec716a5d7c5d7f76dc54d0c0a20f239b8559f55a743f3df41332909fa78'),('100','2026-10-18 19:42:38','2','customer','1','data','tenant_data_export',NULL,NULL,NULL,'127.0.0.1','45ddeec716a5d7c5d7f76dc54d0c0a20f239b8559f55a743f3df41332909fa78','208206304045cf53924058e5af69ef081ab265affacfbe9f90f89f33f2bec3f3'),('101','2026-10-18 19:42:38','2','customer','1','data','settings_changed',NULL,NULL,NULL,'127.0.0.1','208206304045cf53924058e5af69ef081ab265affacfbe9f90f89f33f2bec3f3','5c6d91540400a341e31d3c2490f6cf101864109ac69307b2b2ad8486a9d86bce'),('102','2026-10-18 19:43:00','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','5c6d91540400a341e31d3c2490f6cf101864109ac69307b2b2ad8486a9d86bce','128c425ff0ac7c57c194067eea5552a88f215db5a929fa6b5447ea392ca8e5b5'),('103','2026-10-18 19:43:00','1','admin','1','access','admin_view_tenant_data','accounts',NULL,NULL,'127.0.0.1','128c425ff0ac7c57c194067eea5552a88f215db5a929fa6b5447ea392ca8e5b5','5cef2163564fbcf3cd3a44213761bba01163de74df126b011fa486150fff1b3e'),('104','2026-10-18 19:43:00','1','admin','1','access','admin_view_tenant_data','transactions',NULL,NULL,'127.0.0.1','5cef2163564fbcf3cd3a44213761bba01163de74df126b011fa486150fff1b3e','dace5fbd35df079dd90892a4db506469070a04699d5e774188f18ff94b66d597'),('105','2026-10-18 19:43:00','1','admin','1','access','admin_view_tenant_data','reports',NULL,NULL,'127.0.0.1','dace5fbd35df079dd90892a4db506469070a04699d5e774188f18ff94b66d597','2b31a619eea658dad728ea7a0f2ec506a6516259eaa2c1763a2ff76490c82538'),('106','2026-10-18 19:43:00','2','customer','1','data','transaction_created','transaction','24','{\"kind\":\"expense\",\"amount_minor\":7700,\"replaces\":null}','127.0.0.1','2b31a619eea658dad728ea7a0f2ec506a6516259eaa2c1763a2ff76490c82538','a7d7ac474fd931badc31ec7397552528b400726833770c4ff222ccd9df3d9723'),('107','2026-10-18 19:43:00','1','admin','1','data','transaction_voided','transaction','24','{\"reason\":\"[Yönetici düzeltmesi] Mükerrer giriş\",\"before\":{\"kind\":\"expense\",\"amount_minor\":7700,\"date\":\"2026-10-18\",\"account_id\":1},\"legs\":[24]}','127.0.0.1','a7d7ac474fd931badc31ec7397552528b400726833770c4ff222ccd9df3d9723','35d9a4c483f23e6a825808abd9a2d5a996e79bdf503f67fb9890c39d4925a5e7'),('108','2026-10-18 19:43:00','1','admin','1','admin','admin_correction_void','transaction','24','{\"reason\":\"Mükerrer giriş\",\"legs\":[24]}','127.0.0.1','35d9a4c483f23e6a825808abd9a2d5a996e79bdf503f67fb9890c39d4925a5e7','2282ff637c03e7db458b01a6d9a0f8fd63394f7b3b43cce3a5feaa188c66b583'),('109','2026-10-18 19:43:00','1','admin','1','admin','tenant_status_archived','tenant','1','{\"from\":\"active\"}','127.0.0.1','2282ff637c03e7db458b01a6d9a0f8fd63394f7b3b43cce3a5feaa188c66b583','14b99f4dd3ffd8ce2954561352f692c8e9eaf9ffaf99274d34764deeb66ce4f0'),('110','2026-10-18 19:43:00','1','admin','1','admin','tenant_status_active','tenant','1','{\"from\":\"archived\"}','127.0.0.1','14b99f4dd3ffd8ce2954561352f692c8e9eaf9ffaf99274d34764deeb66ce4f0','46fc2fd82533cff86febb8a77e562d261efce97875ddf4cbc88d5198252a995f'),('111','2026-10-18 19:43:00','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','46fc2fd82533cff86febb8a77e562d261efce97875ddf4cbc88d5198252a995f','e698bda004bb5eff83f064a4b280407bcb8b1c3a963e5b45937cc2e505eff861'),('112','2026-10-18 19:43:30','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','e698bda004bb5eff83f064a4b280407bcb8b1c3a963e5b45937cc2e505eff861','fa88f910501e98548b645eb4077327df566ae6f46fc33d27ca64bd5213fde6a1'),('113','2026-10-18 19:43:31','2','customer','1','data','contact_created','contact','3',NULL,'127.0.0.1','fa88f910501e98548b645eb4077327df566ae6f46fc33d27ca64bd5213fde6a1','2489d366f00598782db5903c31614c8dbe06d95b6cab4f57c29bc91d9cca60f7'),('114','2026-10-18 19:43:31','2','customer','1','data','document_uploaded','transaction','23','{\"doc\":2,\"size\":70}','127.0.0.1','2489d366f00598782db5903c31614c8dbe06d95b6cab4f57c29bc91d9cca60f7','f00ebed8e86e1892d871f5a8385088179ce96e782dd829e14451521e30f5ec08');
/*FBEND*/
DROP TABLE IF EXISTS `budgets`;
/*FBEND*/
CREATE TABLE `budgets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `month` char(7) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `amount_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_bud` (`tenant_id`,`category_id`,`month`,`currency`),
  CONSTRAINT `fk_bu_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `budgets` VALUES ('1','1','9','2026-10','TRY','200000');
/*FBEND*/
DROP TABLE IF EXISTS `captchas`;
/*FBEND*/
CREATE TABLE `captchas` (
  `id` char(32) NOT NULL,
  `answer_hash` char(64) NOT NULL,
  `pow_seed` char(32) NOT NULL,
  `pow_bits` tinyint(4) NOT NULL,
  `ip_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_captcha_exp` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `captchas` VALUES ('0e846bae1e93ed21da210202534ccf6c','35a78ee0af363b9c952b8422389eea2ab443b8ca33865c54622cedaec6bb252a','baea78b6092dd293','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:43:17','2026-10-18 19:40:17'),('1133b7037f03a81592c61a2699676000','3d807b54e291671cd87c7ae2e8e865b42f23fd350326ba4f8856c117be81c5ae','b114d48523cc03bc','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:32','2026-10-18 19:42:32'),('1312476bf71ded30a3047057f86d013f','d022666d7e111f961d16ff899754ff4e5dabc72127952abe01249011bda4ace7','72d78337de164807','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:33','2026-10-18 19:42:33'),('13a523712891efae249ea15a31a7de60','b482a6757d66411ea6c2e5f69f1ba829b24dc986e852ca5093311d66e4ef5c09','d69b1d6864b1a25e','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:33','2026-10-18 19:42:33'),('198aa3535d7aa248a630f67f8d651050','b413ee4a714c61c361c8ae9aa1c37937c6e9bb02ae0c48e72e9b2edc2e06cd00','893155e6cab9e2ed','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:38','2026-10-18 19:42:38'),('1e59777f1951f940fa032c5dcb903c91','a5df0c9a9ee28faeedb6bc2dcd35882b0ef21bad5053bbc4583e57b7213dae6d','96897569d9b8ebb8','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:00','2026-10-18 19:42:00'),('30e917f9671b4fcff27dbd097c6c9c00','e59505b1167d86eeb272bc45313bbcba813bc53d2e38a0dcf8a028c9247a09a0','a45b2fcfcda13eb7','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:30','2026-10-18 19:42:30'),('31a908093715154efe8e97ec04feb42f','7618db20369df201ef12c3a6210ab8b3fc30c751c45d609b8beab5046e43c5e0','de7d1fb9c04d93bf','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:32','2026-10-18 19:42:32'),('35870e09d983c1194316be9879a904e0','5aa28a9a3668eea2d32605ec0617fb4d6dbdbb7fc56d3e8acff4167f521abd5f','c7d77021861cc493','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:44:30','2026-10-18 19:41:30'),('360baa7f78b4c930ef92301849607fb2','06bbaa4d2c7aafd65e1109484bba8d2a9cd924ef08e1459ca7311890733a5edb','a1a57ff159f10eea','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:31','2026-10-18 19:42:31'),('3612b515131d3ea9cc83e08381ca5152','4f5527d6b6e19c53344f9bcbe271d63093c9b641a3954586ab67da39a4cda6a9','f3531c9a77d28bbf','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:44:03',NULL),('387209fc554882181757db2a06963667','3f3d93744c5576151523a3cb01ef39ae0251119e0617d07464a6b575e624931a','58cc8d911e3f4bc2','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:32','2026-10-18 19:42:32'),('3e6aad92fb6259f20f43e69178c6feb2','39d97c1df7ae3e13aa8b21a5bc1f1d2a8577a2738062d4f2dadbd68234b6ce57','e7ab0b6bab503ab7','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:32','2026-10-18 19:42:32'),('49cfb391eab8a43cf3daa6462f695932','7800468cde2c584042a127be630a81493c8e9a6c031b1b6c03f3912412bcd339','e3e19211262aa483','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:31','2026-10-18 19:42:31'),('4abb73da98aa980e434e84dfed8a0463','0703427cc873ba22e3ccf0e0d6170a22b97f99a237f1f14ec3ba2319324a1ab9','147b200b1a3564f3','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:32','2026-10-18 19:42:32'),('5754ae425fb0b5e3a10cea0cbcc45a6a','c937ee0b2ec656ad5c48be6d1f2493124f066bbc55acf9a078c39f7f677dc688','f13fd447850e6664','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:43:17','2026-10-18 19:40:17'),('63fa4a3f5c6982245de2a89f7b3b6dda','3fd848242d9877292885835c15644a24174e70a6c1e58a6d061725723b3141d5','4acd5df7c1d02939','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:43:20','2026-10-18 19:40:20'),('6680b19b98b1064d251d5411a8f83ff7','2a77155a072c75c6abd5e39b4b2a6f98047d700672afe2d54e36e7eb0db69267','c372c3a5abf3ecdf','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:32','2026-10-18 19:42:32'),('72ae166453700e8a55a398428bbfd004','d9c7f208920eecde64bf71d912bf37cb219315f359f440a5850fd2f9b1266273','4233ac8508c1f2e7','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:43:32','2026-10-18 19:40:32'),('77cc9c436c7c1f311cafb28559028a85','aebc8180966547197bcbe7404170387e6b50d1b0985886ea3a0eba4fae0a6a33','a0152962108573a8','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:46:00','2026-10-18 19:43:00'),('a4689d736c52c22234474302afdb17cb','509f9f439a199306b661ac22855176d9597f904a6e3744b3b6c28f030a148904','45f08b081635282b','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:32','2026-10-18 19:42:32'),('a7b683d342c403f1ca0daa17e305268b','3d1bcb0b2c4525cc4f61e44d752550988ce299c5f6fc8342b839c560870966c1','4c3940c5d1a52cad','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:46:00','2026-10-18 19:43:00'),('a8cfb9beb69635b548082870ebe180b1','39667d07df61da15c8326c8b5816c7021abea0f73d8be905a674ac52a326aa47','b58818d1b099a026','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:31',NULL),('a921a6b16844a81eca90e16b54e89f2b','27286d0798f41063516a13f899312af66b5450e13982127b24e1e4c811c7333b','655911a83b5e7c7a','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:33','2026-10-18 19:42:33'),('afe5ae0878d3247797ee7b1f7c36eefe','a415cbf946ccf82ba70abc21e05e68365cb6ccf9c1be7d6ae1c32a2f9ce49c2d','d3572f33ecd97b1b','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:32','2026-10-18 19:42:32'),('bc79e9190bacd8065ad41ed06f7d26aa','b1790112c02901285c06a62c8aaf9dadb5d75d19bcdb70da23fe3a22a024f9fb','788007c2a8fa2c3d','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:32','2026-10-18 19:42:32'),('bf1cdb3f71620753ea5dfea8fd677212','e572ece7ebdf88307d7ef38516c50615d67ea760bca712105d44d74500bc67be','dceb72743dd5f989','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:43:17','2026-10-18 19:40:17'),('c205df797a908540f010334516d0c525','ddc0e09f6563f93bb58e8e7e2cf9415c3dfb1d22f18a06985e5c230923410e64','806d236de2a56e52','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:31','2026-10-18 19:42:31'),('c48f845aa3b9f85e9d3ab651bc23c7b2','f0a336e8ca4caaf961e7d998a51e735d705eb39d3e685994f15c15bd11319550','ebd192f3e65f5cba','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:31','2026-10-18 19:42:31'),('c559ece90f497246926b1e08c2528d33','439af07b8140c1b5b455a873474717fb7e48565a398dc6dcf7523ee71a17e59b','3aee744f4eefbbf4','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:44:03','2026-10-18 19:41:03'),('c8413b18c13314f32ff057708974da03','9489d36a8b078200d16899eabe467c02e038f8189cc321d0252da9429518641c','7a9c2f90d7795df7','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:31','2026-10-18 19:42:31'),('ce56d924c27c51807ac3133890ff2799','83c739963ad44af283b0a4445d514b588a6132e8b42d808c406e179ec3adb620','d1af718bc848b0f1','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:33','2026-10-18 19:42:33'),('d46ebb91080e479b53c7b6681a46a55f','fb764f65aa1042b243f03a59028413e74c0cc3778cba01dc16558dc053e7e6b0','557089fd050ba3b4','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:33','2026-10-18 19:42:33'),('dfb61fdaeb6b69e606456c93beb0ef64','a9f365b3f772244362c71b34f371b76603bbbb453f164f6b51210c65f91fbcd8','7a2d0907fd4a71d0','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:33','2026-10-18 19:42:33'),('e9bd08e75d00f30689a1668fea433840','a5d05ac776d77ad67a3c80fb8f37d79241e2bd3c3de8f9aa9da8a4ed290f721f','9da655a39eb81c71','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:44:03','2026-10-18 19:41:03'),('ffcd71cfa132fb8cd82cc0fac2e3210d','1c195fd785fd5f09040ad24e0e443cc3ccff8cef0589b0c65e92619b340a3fd4','a41f9a0f4db50cb5','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-18 19:45:32','2026-10-18 19:42:32');
/*FBEND*/
DROP TABLE IF EXISTS `card_installments`;
/*FBEND*/
CREATE TABLE `card_installments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `card_id` bigint(20) unsigned NOT NULL,
  `purchase_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ci_t` (`tenant_id`,`card_id`,`due_date`),
  KEY `fk_ci_p` (`purchase_id`),
  CONSTRAINT `fk_ci_p` FOREIGN KEY (`purchase_id`) REFERENCES `card_purchases` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `card_installments` VALUES ('1','1','1','1','1','2026-11-15','40000'),('2','1','1','1','2','2026-12-15','40000'),('3','1','1','1','3','2027-01-15','40000');
/*FBEND*/
DROP TABLE IF EXISTS `card_purchases`;
/*FBEND*/
CREATE TABLE `card_purchases` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `card_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `txn_date` date NOT NULL,
  `description` varchar(250) NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `installments` int(11) NOT NULL DEFAULT 1,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_cp_t` (`tenant_id`,`card_id`),
  CONSTRAINT `fk_cp_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `card_purchases` VALUES ('1','1','1','1','2026-10-18','Ofis malzemesi','120000','2000','20000','3','9',NULL,NULL,'posted','2026-10-18 19:42:35');
/*FBEND*/
DROP TABLE IF EXISTS `cards`;
/*FBEND*/
CREATE TABLE `cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `limit_minor` bigint(20) NOT NULL DEFAULT 0,
  `statement_day` tinyint(4) NOT NULL DEFAULT 1,
  `due_day` tinyint(4) NOT NULL DEFAULT 10,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cd_t` (`tenant_id`),
  CONSTRAINT `fk_cd_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `cards` VALUES ('1','1','1','Kurumsal Kart',NULL,'TRY','5000000','5','15','0','2026-10-18 19:42:35');
/*FBEND*/
DROP TABLE IF EXISTS `categories`;
/*FBEND*/
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('income','expense') NOT NULL,
  `name` varchar(100) NOT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_cat` (`tenant_id`,`kind`,`name`),
  CONSTRAINT `fk_cat_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `categories` VALUES ('1','1','income','Satış Geliri','0'),('2','1','income','Hizmet Geliri','0'),('3','1','income','Kira Geliri','0'),('4','1','income','Faiz Geliri','0'),('5','1','income','Diğer Gelirler','0'),('6','1','expense','Yakıt','0'),('7','1','expense','Ulaşım','0'),('8','1','expense','Yemek','0'),('9','1','expense','Malzeme','0'),('10','1','expense','İşçilik','0'),('11','1','expense','Taşeron','0'),('12','1','expense','Kira','0'),('13','1','expense','Abonelik','0'),('14','1','expense','Banka Masrafı','0'),('15','1','expense','Vergi','0'),('16','1','expense','Sigorta','0'),('17','1','expense','Diğer Giderler','0'),('18','2','income','Satış Geliri','0'),('19','2','income','Hizmet Geliri','0'),('20','2','income','Kira Geliri','0'),('21','2','income','Faiz Geliri','0'),('22','2','income','Diğer Gelirler','0'),('23','2','expense','Yakıt','0'),('24','2','expense','Ulaşım','0'),('25','2','expense','Yemek','0'),('26','2','expense','Malzeme','0'),('27','2','expense','İşçilik','0'),('28','2','expense','Taşeron','0'),('29','2','expense','Kira','0'),('30','2','expense','Abonelik','0'),('31','2','expense','Banka Masrafı','0'),('32','2','expense','Vergi','0'),('33','2','expense','Sigorta','0'),('34','2','expense','Diğer Giderler','0');
/*FBEND*/
DROP TABLE IF EXISTS `contacts`;
/*FBEND*/
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('customer','supplier','both') NOT NULL DEFAULT 'customer',
  `name` varchar(200) NOT NULL,
  `tax_no` varchar(30) DEFAULT NULL,
  `tax_office` varchar(100) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `address` varchar(400) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ct_t` (`tenant_id`),
  CONSTRAINT `fk_ct_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `contacts` VALUES ('1','1','customer','Müşteri A',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-18 19:42:34'),('2','1','supplier','Tedarikçi B',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-18 19:42:34'),('3','1','customer','<script>alert(1)</script>',NULL,NULL,NULL,NULL,NULL,'\"><img src=x onerror=alert(1)>','0','2026-10-18 19:43:31');
/*FBEND*/
DROP TABLE IF EXISTS `documents`;
/*FBEND*/
CREATE TABLE `documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `entity` varchar(30) NOT NULL,
  `entity_id` bigint(20) unsigned NOT NULL,
  `orig_name` varchar(200) NOT NULL,
  `stored_name` char(64) NOT NULL,
  `mime` varchar(100) NOT NULL,
  `size_bytes` bigint(20) NOT NULL,
  `sha256` char(64) NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_doc_ent` (`tenant_id`,`entity`,`entity_id`),
  CONSTRAINT `fk_doc_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `documents` VALUES ('1','1','transaction','18','fis.png','2b841bf6fadb05a130914805ae100d4fe59ddb0dc0c74bb08c36e0c77625b787','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-18 19:42:38',NULL),('2','1','transaction','23','fis2.png','b944a30691e8a6f33197212fd51c54c76fd21901c101bd509757ff4156471e87','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-18 19:43:31',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `entries`;
/*FBEND*/
CREATE TABLE `entries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `kind` enum('receivable','payable') NOT NULL,
  `source` enum('manual','invoice','personal_bill','recurring','milestone') NOT NULL DEFAULT 'manual',
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `recurring_id` bigint(20) unsigned DEFAULT NULL,
  `group_id` varchar(26) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  `seq_total` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `provider` varchar(120) DEFAULT NULL,
  `period` varchar(20) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `amount_minor` bigint(20) NOT NULL,
  `due_date` date NOT NULL,
  `original_due_date` date NOT NULL,
  `priority` tinyint(4) NOT NULL DEFAULT 2,
  `affects_pl` tinyint(4) NOT NULL DEFAULT 0,
  `status` enum('open','cancelled') NOT NULL DEFAULT 'open',
  `note` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `invoice_key` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_entry_invoice` (`tenant_id`,`invoice_key`),
  UNIQUE KEY `ux_entry_recur` (`tenant_id`,`recurring_id`,`due_date`),
  KEY `ix_en_t` (`tenant_id`,`status`,`due_date`),
  CONSTRAINT `fk_en_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `entries` VALUES ('1','1','1','receivable','manual','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Büyük satış',NULL,NULL,'TRY','10000000','2026-10-28','2026-10-28','2','0','open',NULL,'2026-10-18 19:42:34',NULL,NULL),('2','1','1','payable','manual','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Plan: kira',NULL,NULL,'TRY','500000','2026-11-07','2026-11-07','2','1','open',NULL,'2026-10-18 19:42:34',NULL,NULL),('3','1','1','payable','recurring',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'Aylık abonelik',NULL,NULL,'TRY','30000','2026-10-21','2026-10-21','2','1','open',NULL,'2026-10-18 19:42:34',NULL,NULL),('4','1','1','payable','recurring',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'Aylık abonelik',NULL,NULL,'TRY','30000','2026-11-21','2026-11-21','2','1','open',NULL,'2026-10-18 19:42:34',NULL,NULL),('5','1','1','receivable','invoice','1',NULL,NULL,'1',NULL,NULL,NULL,NULL,'Satış faturası FB-2026-001 — Müşteri A',NULL,NULL,'TRY','120000','2026-11-02','2026-11-02','2','0','open',NULL,'2026-10-18 19:42:34',NULL,'1'),('7','1','1','receivable','manual','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'EUR alacak',NULL,NULL,'EUR','50000','2026-10-23','2026-10-23','2','0','open',NULL,'2026-10-18 19:42:35',NULL,NULL),('8','1','1','payable','manual','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tedarikçi borcu',NULL,NULL,'TRY','1000000','2026-10-28','2026-10-15','2','0','open',NULL,'2026-10-18 19:42:35',NULL,NULL),('9','1','2','payable','personal_bill',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Elektrik','Enerjisa','2026-10','TRY','80000','2026-10-18','2026-10-18','2','1','open',NULL,'2026-10-18 19:42:36',NULL,NULL),('10','1','1','receivable','invoice','1','1',NULL,'3',NULL,NULL,NULL,NULL,'Satış faturası PR-1 — Müşteri A',NULL,NULL,'TRY','1200000','2026-10-18','2026-10-18','2','0','open',NULL,'2026-10-18 19:42:36',NULL,'3'),('11','1','1','payable','invoice','2','1',NULL,'4',NULL,NULL,NULL,NULL,'Alış faturası ALIS-9 — Tedarikçi B',NULL,NULL,'TRY','480000','2026-10-18','2026-10-18','2','0','open',NULL,'2026-10-18 19:42:36',NULL,'4'),('12','1','1','receivable','milestone','1','1',NULL,NULL,NULL,NULL,NULL,NULL,'Santral Kurulumu — Hakediş 2',NULL,NULL,'TRY','2000000','2026-11-17','2026-11-17','2','1','open',NULL,'2026-10-18 19:42:36',NULL,NULL),('13','1','1','payable','invoice','2',NULL,NULL,'5',NULL,NULL,NULL,NULL,'Alış faturası STK-1 — Tedarikçi B',NULL,NULL,'TRY','120000','2026-10-18','2026-10-18','2','0','open',NULL,'2026-10-18 19:42:36',NULL,'5');
/*FBEND*/
DROP TABLE IF EXISTS `fx_rates`;
/*FBEND*/
CREATE TABLE `fx_rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `currency` char(3) NOT NULL,
  `rate_date` date NOT NULL,
  `rate` decimal(18,8) NOT NULL,
  `source` varchar(30) NOT NULL DEFAULT 'manual',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_fx` (`tenant_id`,`currency`,`rate_date`),
  CONSTRAINT `fk_fx_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `fx_rates` VALUES ('1','1','EUR','2026-10-18','40.50000000','manual'),('2','1','USD','2026-10-18','35.25000000','manual');
/*FBEND*/
DROP TABLE IF EXISTS `idempotency_keys`;
/*FBEND*/
CREATE TABLE `idempotency_keys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `ikey` char(64) NOT NULL,
  `route` varchar(160) NOT NULL,
  `status_code` smallint(6) DEFAULT NULL,
  `response` mediumtext DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_idem` (`tenant_id`,`ikey`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `idempotency_keys` VALUES ('1','1','a7dc812367562fd1fc26e6da05f12d86e42bf889dfc882f9e41bf35227e3eebc','POST /transactions','201','{\"ok\":true,\"id\":17,\"warning\":null}','2026-10-18 19:42:36');
/*FBEND*/
DROP TABLE IF EXISTS `invoice_lines`;
/*FBEND*/
CREATE TABLE `invoice_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `invoice_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `description` varchar(300) NOT NULL,
  `item_id` bigint(20) unsigned DEFAULT NULL,
  `warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `qty_milli` bigint(20) NOT NULL,
  `unit` varchar(20) NOT NULL DEFAULT 'adet',
  `unit_price_minor` bigint(20) NOT NULL,
  `discount_bp` int(11) NOT NULL DEFAULT 0,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `net_minor` bigint(20) NOT NULL,
  `vat_minor` bigint(20) NOT NULL,
  `total_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_il_inv` (`invoice_id`),
  CONSTRAINT `fk_il_inv` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `invoice_lines` VALUES ('1','1','1','1','Danışmanlık',NULL,NULL,'1000','adet','100000','0','2000','100000','20000','120000'),('2','1','3','1','Hakediş 1',NULL,NULL,'1000','adet','1000000','0','2000','1000000','200000','1200000'),('3','1','4','1','Malzeme',NULL,NULL,'1000','adet','400000','0','2000','400000','80000','480000'),('4','1','5','1','Kablo','1','1','10000','adet','10000','0','2000','100000','20000','120000');
/*FBEND*/
DROP TABLE IF EXISTS `invoices`;
/*FBEND*/
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `kind` enum('sales','purchase') NOT NULL,
  `number` varchar(60) DEFAULT NULL,
  `contact_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `issue_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `status` enum('planned','issued','cancelled') NOT NULL DEFAULT 'issued',
  `subtotal_minor` bigint(20) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `total_minor` bigint(20) NOT NULL DEFAULT 0,
  `note` text DEFAULT NULL,
  `cancel_reason` varchar(300) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `dedupe_key` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_inv_dedupe` (`tenant_id`,`dedupe_key`),
  KEY `ix_inv_t` (`tenant_id`,`issue_date`),
  CONSTRAINT `fk_inv_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `invoices` VALUES ('1','1','1','sales','FB-2026-001','1',NULL,'2026-10-18','2026-11-02','TRY','issued','100000','20000','120000',NULL,NULL,NULL,'2','2026-10-18 19:42:34','a754d2aa8eeed97efccef5a323ae68f9e6c145b8a336eb2712976e6d4c2d2240'),('3','1','1','sales','PR-1','1','1','2026-10-18',NULL,'TRY','issued','1000000','200000','1200000',NULL,NULL,NULL,'2','2026-10-18 19:42:36','b8bc46e741c40ec3b74a4651c8dd1fa976d82fbcf0a1be20c7c81f4972a509ad'),('4','1','1','purchase','ALIS-9','2','1','2026-10-18',NULL,'TRY','issued','400000','80000','480000',NULL,NULL,NULL,'2','2026-10-18 19:42:36','7e15c3cdf198254634085553a61d00d96f61631d5e3c9d5ebf1177cfcda79456'),('5','1','1','purchase','STK-1','2',NULL,'2026-10-18',NULL,'TRY','issued','100000','20000','120000',NULL,NULL,NULL,'2','2026-10-18 19:42:36','f9a2c7eab1de39765fe12024afa7c15639f12f15ebebef3f0f3282fa95242c94');
/*FBEND*/
DROP TABLE IF EXISTS `loan_installments`;
/*FBEND*/
CREATE TABLE `loan_installments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `loan_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `principal_minor` bigint(20) NOT NULL,
  `interest_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_li_t` (`tenant_id`,`loan_id`),
  KEY `fk_li_l` (`loan_id`),
  CONSTRAINT `fk_li_l` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `loan_installments` VALUES ('1','1','1','1','2026-11-18','894715','240000'),('2','1','1','2','2026-12-18','912609','222106'),('3','1','1','3','2027-01-18','930861','203854'),('4','1','1','4','2027-02-18','949479','185236'),('5','1','1','5','2027-03-18','968468','166247'),('6','1','1','6','2027-04-18','987838','146877'),('7','1','1','7','2027-05-18','1007594','127121'),('8','1','1','8','2027-06-18','1027746','106969'),('9','1','1','9','2027-07-18','1048301','86414'),('10','1','1','10','2027-08-18','1069267','65448'),('11','1','1','11','2027-09-18','1090653','44062'),('12','1','1','12','2027-10-18','1112469','22249');
/*FBEND*/
DROP TABLE IF EXISTS `loans`;
/*FBEND*/
CREATE TABLE `loans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `principal_minor` bigint(20) NOT NULL,
  `monthly_rate_bp` int(11) NOT NULL DEFAULT 0,
  `term_months` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `status` enum('active','closed','cancelled') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ln_t` (`tenant_id`),
  CONSTRAINT `fk_ln_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `loans` VALUES ('1','1','1','İşletme Kredisi',NULL,'TRY','12000000','200','12','2026-10-18','active','2026-10-18 19:42:35');
/*FBEND*/
DROP TABLE IF EXISTS `login_tickets`;
/*FBEND*/
CREATE TABLE `login_tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `token_hash` char(64) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `ip` varchar(64) NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_tickets_token` (`token_hash`),
  KEY `fk_tickets_user` (`user_id`),
  CONSTRAINT `fk_tickets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `login_tickets` VALUES ('1','18730dbf554bf0244aeac53129e442b64239c5beceac65ac370c0c40129467c0','1','127.0.0.1','1','2026-10-18 19:45:17',NULL),('2','bb546c5bcd8c6370b99c7cd701d51c3b8124dd7e78514cca0dc0f418dc5285e0','1','127.0.0.1','1','2026-10-18 19:45:17','2026-10-18 19:40:17'),('3','6cb91b9c863d09a44fed139a7fd03471d08ef38f0ebd7953036dd3fb82c20e57','1','127.0.0.1','1','2026-10-18 19:45:20','2026-10-18 19:40:32'),('4','4438907faeade36a0d3f22b9b526a17c6ec9d97e6df209430bf9b99871c64a29','1','127.0.0.1','1','2026-10-18 19:45:32','2026-10-18 19:41:02'),('5','39914acb1d1b6aef46b87f05b9c7b15696dcfc25d226df79b9021ee603fb827c','1','127.0.0.1','0','2026-10-18 19:46:03',NULL),('6','92cc0f8896238d9e3fea522378e174ce3651b4bdce5c5b5d9f4c5331ca10c866','1','127.0.0.1','1','2026-10-18 19:46:03','2026-10-18 19:41:30'),('7','fa29f81b1da91f32fced23b9e52d294627bfcb8cfb9235bffcfb4df0dab3fc2a','1','127.0.0.1','1','2026-10-18 19:46:30','2026-10-18 19:42:00'),('8','f72ef5534fbcadbdc52d506ff4118aa2217b1bf86efb5c85d5230f684902b2cd','1','127.0.0.1','1','2026-10-18 19:47:00','2026-10-18 19:42:30'),('9','011462b160ec654a86e84838699fea3f26084fcc0e5f944840685cf79af4b2c5','1','127.0.0.1','1','2026-10-18 19:47:39','2026-10-18 19:43:00'),('10','3f3452b660d368f5f69549770c33a6d9963494be803ee0fbd9659b3476cef677','1','127.0.0.1','1','2026-10-18 19:48:00','2026-10-18 19:43:30');
/*FBEND*/
DROP TABLE IF EXISTS `password_tokens`;
/*FBEND*/
CREATE TABLE `password_tokens` (
  `token_hash` char(64) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `purpose` enum('reset','invite') NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`token_hash`),
  KEY `ix_pt_user` (`user_id`),
  CONSTRAINT `fk_pt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `password_tokens` VALUES ('3384eba1b454f28017b31227a62686d8c7d45c94635c7d1402452d42351f56a8','2','reset','2026-10-18 20:12:32','2026-10-18 19:42:33',NULL,'2026-10-18 19:42:32'),('a25c9aa71b8933a5f90365f4f32563b727aaa7be3a94a95f11def63311849ba7','2','invite','2026-10-21 19:42:31','2026-10-18 19:42:31','1','2026-10-18 19:42:31');
/*FBEND*/
DROP TABLE IF EXISTS `project_milestones`;
/*FBEND*/
CREATE TABLE `project_milestones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `due_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `entry_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pm_t` (`tenant_id`),
  CONSTRAINT `fk_pm_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `project_milestones` VALUES ('1','1','1','Hakediş 2','2026-11-17','2000000','12','2026-10-18 19:42:36');
/*FBEND*/
DROP TABLE IF EXISTS `project_quotes`;
/*FBEND*/
CREATE TABLE `project_quotes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned NOT NULL,
  `kind` enum('quote','order') NOT NULL DEFAULT 'quote',
  `number` varchar(60) DEFAULT NULL,
  `quote_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `status` enum('draft','sent','accepted','rejected') NOT NULL DEFAULT 'draft',
  `note` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pq_t` (`tenant_id`),
  CONSTRAINT `fk_pq_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
DROP TABLE IF EXISTS `projects`;
/*FBEND*/
CREATE TABLE `projects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(160) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `contract_minor` bigint(20) NOT NULL DEFAULT 0,
  `est_cost_minor` bigint(20) NOT NULL DEFAULT 0,
  `status` enum('planned','active','done','cancelled') NOT NULL DEFAULT 'active',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_pr_t` (`tenant_id`),
  CONSTRAINT `fk_pr_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `projects` VALUES ('1','1','1','1','Santral Kurulumu','TRY','5000000','3000000','active',NULL,NULL,NULL,'0','2026-10-18 19:42:36');
/*FBEND*/
DROP TABLE IF EXISTS `rate_limits`;
/*FBEND*/
CREATE TABLE `rate_limits` (
  `k` varchar(120) NOT NULL,
  `hits` int(11) NOT NULL,
  `window_start` datetime NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `rate_limits` VALUES ('2fa_enable:1','2','2026-10-18 19:40:17'),('2fa_ip:127.0.0.1','9','2026-10-18 19:40:17'),('adm_acc:1:1:accounts','1','2026-10-18 19:43:00'),('adm_acc:1:1:reports','1','2026-10-18 19:43:00'),('adm_acc:1:1:transactions','1','2026-10-18 19:43:00'),('api_ip:127.0.0.1','4','2026-10-18 19:43:32'),('api_user:1','4','2026-10-18 19:43:32'),('api_user:2','1','2026-10-18 19:43:32'),('api_user:3','26','2026-10-18 19:42:31'),('captcha_ip:127.0.0.1','36','2026-10-18 19:40:17'),('forgot_id:10b002daf7d0d7bb6ce4ddb1eace6e6ea8797dc2ae8eac370896018434fdc32b','1','2026-10-18 19:42:32'),('forgot_id:9d158211d6d187975b6ea8731d701836746c45264805fb516c4b825d77575a12','1','2026-10-18 19:42:32'),('forgot_ip:127.0.0.1','2','2026-10-18 19:42:32'),('honeypot:127.0.0.1','1','2026-10-18 19:42:31'),('login_id:2adbc0b959b6cefa8a28619eba9556a8b3e989948da312fdc252299441054066','11','2026-10-18 19:40:17'),('login_id:9d158211d6d187975b6ea8731d701836746c45264805fb516c4b825d77575a12','13','2026-10-18 19:42:31'),('login_id:bf7af099680062112c03af6bf21788199efd3be7eb5577030428c546327e2d13','1','2026-10-18 19:42:30'),('login_id:d3206c76a6d95265cea4f2b55e315c420f7dadad3198cdfba7831a080179d026','5','2026-10-18 19:42:31'),('login_ip:127.0.0.1','36','2026-10-18 19:40:17'),('pwchange:3','4','2026-10-18 19:42:31'),('reset_ip:127.0.0.1','4','2026-10-18 19:42:31');
/*FBEND*/
DROP TABLE IF EXISTS `recurring_templates`;
/*FBEND*/
CREATE TABLE `recurring_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `entry_kind` enum('receivable','payable') NOT NULL,
  `title` varchar(200) NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `frequency` enum('weekly','monthly','yearly') NOT NULL DEFAULT 'monthly',
  `next_date` date NOT NULL,
  `anchor_day` tinyint(4) NOT NULL DEFAULT 1,
  `end_date` date DEFAULT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `last_generated` date DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_rt_t` (`tenant_id`),
  CONSTRAINT `fk_rt_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `recurring_templates` VALUES ('1','1','1','payable','Aylık abonelik','30000','TRY',NULL,NULL,'monthly','2026-12-21','21',NULL,'1','2026-10-18','2026-10-18 19:42:34');
/*FBEND*/
DROP TABLE IF EXISTS `schema_migrations`;
/*FBEND*/
CREATE TABLE `schema_migrations` (
  `version` varchar(100) NOT NULL,
  `checksum` char(64) NOT NULL,
  `applied_at` datetime NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*FBEND*/
INSERT INTO `schema_migrations` VALUES ('001_core','2d7a0f529b8d465b588d781044a60d9cb4baf28da2486cf3fea7a419c77b2087','2026-10-18 19:40:16'),('002_finance','280896f0df01ee75f67ba9f9195332cffca21c8e6a49a5c4c3626a6abd726ced','2026-10-18 19:40:16');
/*FBEND*/
DROP TABLE IF EXISTS `sessions`;
/*FBEND*/
CREATE TABLE `sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `token_hash` char(64) NOT NULL,
  `prev_token_hash` char(64) DEFAULT NULL,
  `prev_valid_until` datetime DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `epoch` int(11) NOT NULL,
  `csrf_secret` char(64) NOT NULL,
  `ip` varchar(64) NOT NULL,
  `ua_hash` char(64) NOT NULL,
  `label` varchar(160) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `last_seen_at` datetime NOT NULL,
  `rotated_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `revoked_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sessions_token` (`token_hash`),
  KEY `ix_sessions_prev` (`prev_token_hash`),
  KEY `ix_sessions_user` (`user_id`),
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `sessions` VALUES ('1','a2b19cb3c32331f78ea9eebd32704d8fd6aa84f01be63204d7d98b04753044be',NULL,'2026-10-18 19:40:15','1','2','c958121d871785fbc23edbce8c7d07babd283e1754662242f7793d884e0beccd','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:40:17','2026-10-18 19:40:17','2026-10-18 19:40:17','2026-10-19 07:40:17',NULL),('2','6c27152b838e4efae485bcdf289f0266e3de367399634b4f497e3dac90c82e5f','c80d5713461701e6fb1115cbdafd0f2ed6e601c82dce3873787564d1cd1df05b','2026-10-18 19:40:15','1','2','a6ff7b0796c02d9b51a5cd6852a5bcb0fbe4796c2b304f0145270f0fcd56acce','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:40:17','2026-10-18 19:40:20','2026-10-18 19:40:20','2026-10-19 07:40:17',NULL),('3','52e6f0410b7d5fed403f3ef30df729466108bd1d010139a7288a4a92c7fddd9c',NULL,NULL,'1','2','9c05888679f5bf54dfa20d760e2e841e1f2fcd6eda209b8f2c395e37a916fa2b','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:40:32','2026-10-18 19:40:32','2026-10-18 19:40:32','2026-10-19 07:40:32',NULL),('4','f4341eff65d5fd4cfcc3f0600bb9d180b467a29eadc17464a5248f8e241b2219',NULL,NULL,'1','2','a787061d10b4fba0d0728b47192445d95fedf75f9b5384ccff18b89eff231786','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:41:02','2026-10-18 19:41:02','2026-10-18 19:41:02','2026-10-19 07:41:02','2026-10-18 19:41:02'),('5','02946160c11c79ad31706dad6644460f9dc1b53e3eb04ad31e18ee0820002924',NULL,NULL,'1','2','87916c662e81883caaf5d9a92d9bc7afaac6c5ab9bd3d31408b2b13ff68ea276','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:41:30','2026-10-18 19:41:30','2026-10-18 19:41:30','2026-10-19 07:41:30',NULL),('6','a9413343f7bd9cc3c325fc02b477cc902d60afbd06386f475ad9757daa719355',NULL,NULL,'1','2','9930883c255c372a2f80fc50921dbf0d85e76a7cb1f127cb59e9bfc0b547f8d2','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:00','2026-10-18 19:42:00','2026-10-18 19:42:00','2026-10-19 07:42:00',NULL),('7','ca5333ddc3ae84fb4cae1e3e7fa51ea62933c259920e496a6e38a04b8a7e90ac','0c5bd33a60f32ac510180aa9eb2933181675bbd77a70bcd0e044d80f8957f076','2026-10-18 19:43:33','1','2','0fbd460a35f531bc61f0a0afc72701dd06db5cbe78b2be5810a22ba9512c02c6','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:30','2026-10-18 19:42:33','2026-10-18 19:42:33','2026-10-19 07:42:30',NULL),('8','4a9641310b6479ec44ebce3fd67fc137d1b37fff8353586a75ccc2fb8f6d0555',NULL,NULL,'3','1','5e46b556d621292fec83428a361d19e2b82728b29946e4cbbf360411d2739b30','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:31','2026-10-18 19:42:31','2026-10-18 19:42:31','2026-10-19 07:42:31','2026-10-18 19:42:31'),('9','148e9e7e0892c8b9204b41cdcd7f9c4f3df2f8b3d155e9216341d256335f1585',NULL,NULL,'3','2','6bf2ca2c7e5bd52bbaae0a2be083f2b84a4a6f4b521d82f6b04894fbdd4a5d47','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:31','2026-10-18 19:42:31','2026-10-18 19:42:31','2026-10-19 07:42:31','2026-10-18 19:42:33'),('10','96209d40055e586e03739e489fb3e441a3813a8d87ec598399ea6fa16a8e8dc1',NULL,NULL,'2','2','783141562756caee174726ab2247f866728c00baebb4de72d2077d3e36ff9b65','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:31','2026-10-18 19:42:31','2026-10-18 19:42:31','2026-10-19 07:42:31','2026-10-18 19:42:31'),('11','0941f9861de7b81b56506253d7d7b697a434c6969f3344f17ad402900359d29f',NULL,NULL,'2','2','bb7249ead01517b8e1479739e431bdc400fbe4464296044ed4fbdcf005167e5e','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:31','2026-10-18 19:42:31','2026-10-18 19:42:31','2026-10-19 07:42:31','2026-10-18 19:42:33'),('12','ed3b4e348c4a88896f4da57dc6221a2e6438b9791e08c16f331c53e101ef93f2',NULL,NULL,'2','2','2185ab0a838a1ab6fba38d440f05511aed6ae97d2289309fd1c187906ef86ebb','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:32','2026-10-18 19:42:32','2026-10-18 19:42:32','2026-10-19 07:42:32','2026-10-18 19:42:33'),('13','4058e827e59a1716ee3e9a4fcb35e3301a6ae0942cbf4185af4134f140420363',NULL,NULL,'2','2','11d8a4260aea5d59d71a4a7a89b483199a214dc068126d9878820f2d61f42cee','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:33','2026-10-18 19:42:33','2026-10-18 19:42:33','2026-10-19 07:42:33','2026-10-18 19:42:33'),('14','d44d23a8fcea60beadf6b4e8ce5c52af470d4035a569f28255514a7fd316bc02',NULL,NULL,'2','3','bc8db63f7077dedf1ad62ac5cacf67b61c890392eb65ba5a47c7eb2922e4a8bb','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:33','2026-10-18 19:42:33','2026-10-18 19:42:33','2026-10-19 07:42:33','2026-10-18 19:43:00'),('15','86483568fab4be7de47cf90e1a29732ef7c408eab7c19e656d66fe7f63e082dd',NULL,NULL,'3','2','46ba220060a98d140562b5d58408869ff78337fd689ce606f467169de2c65a41','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:33','2026-10-18 19:42:33','2026-10-18 19:42:33','2026-10-19 07:42:33','2026-10-18 19:42:33'),('16','8f8150ec832ecc16313f6d1e3e80d92c619fdab110465d37ae42edfb4e609bbc',NULL,NULL,'3','3','90f3d0f0803488633c3698b338c6d3b9331b873be29d5127eb5ea254fb16e44e','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:33','2026-10-18 19:42:33','2026-10-18 19:42:33','2026-10-19 07:42:33',NULL),('17','e2ae9da181f7c6a7376e4a32955ee0ca1cd8a98cb37de48b5343ce83292ab98e','65302f3e57c1bf8b6940df5ee8521742d9c7681093f405d54f4b53d27a16c80e','2026-10-18 19:44:00','2','3','7e5c5142379caee78d41f72a8575ce8b600aa4253307f7c5b48e5d6f22d3a73b','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:33','2026-10-18 19:43:00','2026-10-18 19:43:00','2026-10-19 07:42:33','2026-10-18 19:43:00'),('18','6b9b982624d5cba479e35ab1d254060bd79044d98842dfac098cbf6fb020f8a6','10b90cec2f1bd4feb5e3469b61a5f94855ea5c8ff05b43f7a3a9fe59d2ca193e','2026-10-18 19:43:37','3','3','df62d96c65126a9958c046f5c49f1e2b5fc92d761f903e69090b27c0fd780a4d','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:42:33','2026-10-18 19:42:37','2026-10-18 19:42:37','2026-10-19 07:42:33',NULL),('19','8cb6fe418bd603349a1fdee0a07e3898726d67b7bcd388698b60dda6c656b49f',NULL,NULL,'1','2','8173b7a7f506f5f244f3572bd8b5d3a3f7c8138bceadbaf90c1db55a8c518cae','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:43:00','2026-10-18 19:43:00','2026-10-18 19:43:00','2026-10-19 07:43:00',NULL),('20','b9b0209ee2412e20f0b57a1426ba77e4195b8973af37e583617ec50736534c4e','5884b850be0e3907b1b76ee9fb17775dbb1bab85ff143c1dcb07ffc910140ad7','2026-10-18 19:44:30','2','4','af6a42022710a0fb0a359bad9e10642216c663e0c4caa3e49354677944ac28af','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:43:00','2026-10-18 19:43:30','2026-10-18 19:43:30','2026-10-19 07:43:00',NULL),('21','382d37a0e3b86880b9ebd4a6281b82e051a93f3490cf3e91108f21d31a32d67f',NULL,NULL,'1','2','20bea0414b4b108acd84d4e365c564ecbf4638dc8c4d1fd373d654b80698f400','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-18 19:43:30','2026-10-18 19:43:30','2026-10-18 19:43:30','2026-10-19 07:43:30',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `statement_lines`;
/*FBEND*/
CREATE TABLE `statement_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `line_date` date NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `line_hash` char(64) NOT NULL,
  `matched_txn_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('unmatched','matched','ignored') NOT NULL DEFAULT 'unmatched',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sl_hash` (`tenant_id`,`account_id`,`line_hash`),
  CONSTRAINT `fk_sl_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `statement_lines` VALUES ('1','1','1','2026-10-18','POS TAHSILAT','25000','0b714abcd869f4aa9565b0830ad1ffa259edff261a42ad1c8dfdb88413d3c16b','13','matched','2026-10-18 19:42:36'),('2','1','1','2026-10-18','KOMISYON','-500','1d182ee4d5df71ec62ee273c691fdef7bbf8d1d2cb1a2b13bbe3e7ddf5a8f782',NULL,'unmatched','2026-10-18 19:42:36'),('3','1','1','2026-10-18','KOMISYON','-500','9dfe9a6937c3e8cc2343af56775acf530de51aa39d678e896c2841ec24089737',NULL,'unmatched','2026-10-18 19:42:36');
/*FBEND*/
DROP TABLE IF EXISTS `stock_items`;
/*FBEND*/
CREATE TABLE `stock_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('product','service') NOT NULL DEFAULT 'product',
  `code` varchar(60) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `unit` varchar(20) NOT NULL DEFAULT 'adet',
  `barcode` varchar(60) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `sale_price_minor` bigint(20) NOT NULL DEFAULT 0,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 2000,
  `min_qty_milli` bigint(20) NOT NULL DEFAULT 0,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_si_code` (`tenant_id`,`code`),
  CONSTRAINT `fk_si_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `stock_items` VALUES ('1','1','product','KBL-1','Kablo 10m','adet',NULL,'TRY','0','2000','0','0','2026-10-18 19:42:36');
/*FBEND*/
DROP TABLE IF EXISTS `stock_movements`;
/*FBEND*/
CREATE TABLE `stock_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `warehouse_id` bigint(20) unsigned NOT NULL,
  `kind` enum('in','out','return_in','return_out') NOT NULL,
  `qty_milli` bigint(20) NOT NULL,
  `unit_cost_minor` bigint(20) NOT NULL DEFAULT 0,
  `move_date` date NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_sm_t` (`tenant_id`,`item_id`),
  KEY `ix_sm_inv` (`invoice_id`),
  CONSTRAINT `fk_sm_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `stock_movements` VALUES ('1','1','1','1','in','10000','10000','2026-10-18',NULL,'5','Alış faturası','posted','2026-10-18 19:42:36'),('2','1','1','1','out','2000','10000','2026-10-18','1',NULL,NULL,'posted','2026-10-18 19:42:36'),('3','1','1','1','out','9000','10000','2026-10-18',NULL,NULL,NULL,'posted','2026-10-18 19:42:36');
/*FBEND*/
DROP TABLE IF EXISTS `system_settings`;
/*FBEND*/
CREATE TABLE `system_settings` (
  `k` varchar(80) NOT NULL,
  `v` mediumtext DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
DROP TABLE IF EXISTS `tenants`;
/*FBEND*/
CREATE TABLE `tenants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `company_name` varchar(200) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `status` enum('active','suspended','archived') NOT NULL DEFAULT 'active',
  `settings` mediumtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tenants_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `tenants` VALUES ('1','Alfa Ltd','Alfa Ticaret',NULL,'active','{\"locale\":\"tr-TR\",\"theme\":\"dark\",\"date_format\":\"DD.MM.YYYY\",\"default_workspace_id\":null,\"default_account_id\":1,\"vat_rates\":[0,800,1000,2000],\"preferred_currency\":\"TRY\",\"notify\":{\"due\":true,\"overdue\":true,\"card\":true,\"bills\":false,\"email\":false},\"invoice\":{\"prefix\":\"\",\"default_due_days\":30,\"note\":\"\"}}','1','2026-10-18 19:42:31','2026-10-18 19:43:00',NULL),('2','Beta AŞ',NULL,NULL,'active','{\"locale\":\"tr-TR\",\"notify\":{\"due\":true,\"overdue\":true,\"card\":true,\"bills\":true,\"email\":false}}','1','2026-10-18 19:42:31','2026-10-18 19:42:33',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `transactions`;
/*FBEND*/
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `direction` enum('in','out') NOT NULL,
  `kind` enum('income','expense','collection','payment','transfer','fx','card_payment','loan_payment','loan_proceeds','adjustment') NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `interest_minor` bigint(20) NOT NULL DEFAULT 0,
  `currency` char(3) NOT NULL,
  `txn_date` date NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `entry_id` bigint(20) unsigned DEFAULT NULL,
  `card_id` bigint(20) unsigned DEFAULT NULL,
  `loan_id` bigint(20) unsigned DEFAULT NULL,
  `loan_installment_id` bigint(20) unsigned DEFAULT NULL,
  `transfer_group` varchar(26) DEFAULT NULL,
  `fx_rate` decimal(18,8) DEFAULT NULL,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `void_reason` varchar(300) DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `voided_by` bigint(20) unsigned DEFAULT NULL,
  `replaces_id` bigint(20) unsigned DEFAULT NULL,
  `statement_line_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tx_acc` (`tenant_id`,`account_id`,`status`),
  KEY `ix_tx_date` (`tenant_id`,`txn_date`),
  KEY `ix_tx_entry` (`entry_id`),
  KEY `ix_tx_group` (`transfer_group`),
  KEY `fk_tx_a` (`account_id`),
  CONSTRAINT `fk_tx_a` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `fk_tx_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `transactions` VALUES ('1','1','1','1','in','collection','6000000','0','TRY','2026-10-18','Tahsilat: Büyük satış',NULL,'1',NULL,'1',NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:34'),('2','1','1','1','in','collection','4000000','0','TRY','2026-10-18','Tahsilat: Büyük satış',NULL,'1',NULL,'1',NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:34'),('3','1','1','1','out','transfer','2000000','0','TRY','2026-10-18','Transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'cdb49f8568ef8432f531452186',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:34'),('4','1','1','2','in','transfer','2000000','0','TRY','2026-10-18','Transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'cdb49f8568ef8432f531452186',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:34'),('5','1','1','1','in','collection','120000','0','TRY','2026-10-18','Tahsilat: Satış faturası FB-2026-001 — Müşteri A',NULL,'1',NULL,'5',NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:34'),('6','1','1','1','out','fx','1000000','0','TRY','2026-10-18','Döviz: TRY→EUR kur 0.02500000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1229d0cf2ed6fb5ccd697deae8','0.02500000','0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:35'),('7','1','1','3','in','fx','25000','0','EUR','2026-10-18','Döviz: TRY→EUR kur 0.02500000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1229d0cf2ed6fb5ccd697deae8','0.02500000','0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:35'),('8','1','1','1','out','expense','1500','0','TRY','2026-10-18','Döviz işlem masrafı','14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:35'),('9','1','1','1','out','payment','300000','0','TRY','2026-10-18','Ödeme: Tedarikçi borcu',NULL,'2',NULL,'8',NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:35'),('10','1','1','1','out','card_payment','40000','0','TRY','2026-10-18','Kart ödemesi: Kurumsal Kart',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:35'),('11','1','1','1','in','loan_proceeds','12000000','0','TRY','2026-10-18','Kredi kullandırım: İşletme Kredisi',NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:35'),('12','1','1','1','out','loan_payment','1134715','240000','TRY','2026-10-18','Kredi taksiti 1/12: İşletme Kredisi',NULL,NULL,NULL,NULL,NULL,'1','1',NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:36'),('13','1','1','1','in','income','25000','0','TRY','2026-10-18','POS TAHSILAT','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,'1','2','2026-10-18 19:42:36'),('14','1','1','1','in','collection','1200000','0','TRY','2026-10-18','Tahsilat: Satış faturası PR-1 — Müşteri A',NULL,'1','1','10',NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:36'),('15','1','1','1','out','payment','480000','0','TRY','2026-10-18','Ödeme: Alış faturası ALIS-9 — Tedarikçi B',NULL,'2','1','11',NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:36'),('16','1','1','1','out','expense','50000','0','TRY','2026-10-18','Yakıt','6',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:36'),('17','1','1','1','in','income','100000','0','TRY','2026-10-18','Çift tık testi','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','Hatalı giriş','2026-10-18 19:42:37','2',NULL,NULL,'2','2026-10-18 19:42:36'),('18','1','1','1','out','expense','10000','0','TRY','2026-10-18','eski',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','Düzenleme ile yenisi oluşturuldu','2026-10-18 19:42:37','2',NULL,NULL,'2','2026-10-18 19:42:37'),('19','1','1','1','out','expense','12000','0','TRY','2026-10-18','düzeltilmiş',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,'18',NULL,'2','2026-10-18 19:42:37'),('20','1','1','1','out','expense','120000','0','TRY','2026-10-18','KDV dahil',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2000','20000','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:37'),('21','1','1','1','out','expense','120000','0','TRY','2026-10-18','KDV hariç',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2000','20000','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:37'),('22','1','1','2','out','adjustment','5000','0','TRY','2026-10-18','Bakiye düzeltme: Sayım farkı',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:37'),('23','1','1','1','out','expense','100','0','TRY','2026-10-18','=HYPERLINK(\"http://evil\",\"x\")',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-18 19:42:38'),('24','1','1','1','out','expense','7700','0','TRY','2026-10-18','admin düzeltilecek',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','[Yönetici düzeltmesi] Mükerrer giriş','2026-10-18 19:43:00','1',NULL,NULL,'2','2026-10-18 19:43:00');
/*FBEND*/
DROP TABLE IF EXISTS `users`;
/*FBEND*/
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `email` varchar(190) NOT NULL,
  `display_name` varchar(160) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL,
  `admin_flag` tinyint(4) DEFAULT NULL,
  `status` enum('active','suspended','archived') NOT NULL DEFAULT 'active',
  `must_change_password` tinyint(4) NOT NULL DEFAULT 0,
  `email_verified_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(64) DEFAULT NULL,
  `prev_login_at` datetime DEFAULT NULL,
  `prev_login_ip` varchar(64) DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `lock_level` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `totp_secret_enc` text DEFAULT NULL,
  `totp_enabled` tinyint(4) NOT NULL DEFAULT 0,
  `totp_last_step` bigint(20) DEFAULT NULL,
  `recovery_codes` text DEFAULT NULL,
  `session_epoch` int(11) NOT NULL DEFAULT 1,
  `password_changed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_users_email` (`email`),
  UNIQUE KEY `ux_users_admin` (`admin_flag`),
  KEY `ix_users_tenant` (`tenant_id`),
  CONSTRAINT `fk_users_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `users` VALUES ('1',NULL,'owner@test.local','Yönetici','$argon2id$v=19$m=19456,t=2,p=1$QnJaRXVwRXhCVmN2TUZ1MQ$GjS+645lcaJvf8vv6kcz3BURXDvWX5hQadmmic15qrw','admin','1','active','0','2026-10-18 19:40:16','2026-10-18 19:43:30','127.0.0.1','2026-10-18 19:43:00','127.0.0.1','0','0',NULL,'3+VxN3ofYj1TQKx65d+8JKFLUShzqaFQaJoT4znX06wdREfz8i8R1yBnRNbTS0+UTlzmEe4H7lL9f3K3','1','59745088','[\"42da8d5a32f2590aaa4d3a4b82371c0d0a75b37e9dabb9fb1041e18d0686240a\",\"315e3541a12e43206ec781f3741c0702c4e9475a7672a2de91fbe1e6f76c1cc9\",\"86ba647aeb59efa62ac6e518704fbc62a81d29e3c30b92b7ef59708bd29e6084\",\"77f30eada3a8e0834efe946bd47be0989acba7fad03b5e1b49762d70021ac5cc\",\"578304f22173a30fba3c8b5b18dab389c55c8159739dec2d9c2d08b667a14f8a\",\"b8a2cc644c4e0c0edbe4bf94831e1bf1055f7bb1ea0b4093c408740a6622cbc7\",\"c4b4f71deae52480aebeed213572cd4fa47f15d76cfd10cda9612fa47b60565c\",\"5e77f79308f7e8c72c03967efaf5c32937d67dcdcf59c8f9d32ad12de8400844\"]','2','2026-10-18 19:40:16','2026-10-18 19:40:16'),('2','1','alfa@test.local','Hile','$argon2id$v=19$m=19456,t=2,p=1$R0s4QmNON1RKNXdzL0dHOA$+Q0gkwgmiLDqWfX+c7lrsbV5UlMxsPlu3labDI3AMp0','customer',NULL,'active','0','2026-10-18 19:42:31','2026-10-18 19:43:00','127.0.0.1','2026-10-18 19:42:33','127.0.0.1','0','0',NULL,NULL,'0',NULL,NULL,'4','2026-10-18 19:42:33','2026-10-18 19:42:31'),('3','2','beta@test.local','Beta AŞ','$argon2id$v=19$m=19456,t=2,p=1$NzY4VjlXUlNFU3NOS2pHcw$MxH6W5HAp2nnX+z/iu83TBueN5npykWJNtw3b4DdrEE','customer',NULL,'active','0',NULL,'2026-10-18 19:42:33','127.0.0.1','2026-10-18 19:42:33','127.0.0.1','0','0',NULL,NULL,'0',NULL,NULL,'3','2026-10-18 19:42:31','2026-10-18 19:42:31');
/*FBEND*/
DROP TABLE IF EXISTS `warehouses`;
/*FBEND*/
CREATE TABLE `warehouses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_wh` (`tenant_id`,`name`),
  CONSTRAINT `fk_wh_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `warehouses` VALUES ('1','1','Ana Depo','0');
/*FBEND*/
DROP TABLE IF EXISTS `workspaces`;
/*FBEND*/
CREATE TABLE `workspaces` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `kind` enum('business','personal') NOT NULL DEFAULT 'business',
  `legal_name` varchar(200) DEFAULT NULL,
  `tax_no` varchar(30) DEFAULT NULL,
  `color` varchar(9) DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_ws_name` (`tenant_id`,`name`),
  CONSTRAINT `fk_ws_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `workspaces` VALUES ('1','1','Horizon','business',NULL,NULL,NULL,'0','2026-10-18 19:42:33'),('2','1','Şahsi','personal',NULL,NULL,NULL,'0','2026-10-18 19:42:33'),('3','2','Beta Ortak','business',NULL,NULL,NULL,'0','2026-10-18 19:42:38');
/*FBEND*/
SET FOREIGN_KEY_CHECKS=1;
/*FBEND*/
/*FBCOUNTS {"accounts":7,"audit_log":114,"budgets":1,"captchas":36,"card_installments":3,"card_purchases":1,"cards":1,"categories":34,"contacts":3,"documents":2,"entries":12,"fx_rates":2,"idempotency_keys":1,"invoice_lines":4,"invoices":4,"loan_installments":12,"loans":1,"login_tickets":10,"password_tokens":2,"project_milestones":1,"project_quotes":0,"projects":1,"rate_limits":21,"recurring_templates":1,"schema_migrations":2,"sessions":21,"statement_lines":3,"stock_items":1,"stock_movements":3,"system_settings":0,"tenants":2,"transactions":24,"users":3,"warehouses":1,"workspaces":3}*/
