/*FBMUH BACKUP 20261019-222332*/
SET NAMES utf8mb4;
/*FBEND*/
SET FOREIGN_KEY_CHECKS=0;
/*FBEND*/
DROP TABLE IF EXISTS `accounts`;
/*FBEND*/
CREATE TABLE `accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `kind` enum('bank','cash') NOT NULL DEFAULT 'bank',
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `iban` varchar(40) DEFAULT NULL,
  `opening_minor` bigint(20) NOT NULL DEFAULT 0,
  `opening_date` date NOT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT 0,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ac_t` (`tenant_id`),
  KEY `fk_ac_w` (`workspace_id`),
  CONSTRAINT `fk_ac_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`),
  CONSTRAINT `fk_ac_w` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `accounts` VALUES ('1','1','1',NULL,'Ana Banka TL','bank','Test Bank','TRY',NULL,'5000000','2026-01-01','0','0','2026-10-19 22:22:33'),('2','1','1',NULL,'Kasa TL','cash',NULL,'TRY',NULL,'0','2026-01-01','0','0','2026-10-19 22:22:33'),('3','1','1',NULL,'Banka EUR','bank',NULL,'EUR',NULL,'100000','2026-01-01','0','0','2026-10-19 22:22:33'),('4','1','1',NULL,'Banka USD','bank',NULL,'USD',NULL,'200000','2026-01-01','0','0','2026-10-19 22:22:33'),('5','1','2',NULL,'Şahsi Banka','bank',NULL,'TRY',NULL,'1000000','2026-01-01','0','0','2026-10-19 22:22:33'),('6','1','1',NULL,'IBANlı','bank',NULL,'TRY','TR330006100519786457841326','0','2026-01-01','0','0','2026-10-19 22:22:33'),('7','2','3',NULL,'Beta Banka','bank',NULL,'TRY',NULL,'100','2026-01-01','0','0','2026-10-19 22:22:38');
/*FBEND*/
DROP TABLE IF EXISTS `audit_log`;
/*FBEND*/
CREATE TABLE `audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ts` datetime NOT NULL,
  `actor_user_id` bigint(20) unsigned DEFAULT NULL,
  `actor_role` varchar(20) DEFAULT NULL,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `category` enum('security','admin','data','access','system') NOT NULL,
  `action` varchar(80) NOT NULL,
  `entity` varchar(60) DEFAULT NULL,
  `entity_id` varchar(40) DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `prev_hash` char(64) NOT NULL,
  `hash` char(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_audit_tenant` (`tenant_id`,`id`),
  KEY `ix_audit_cat` (`category`,`id`),
  KEY `ix_audit_actor` (`actor_user_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `audit_log` VALUES ('1','2026-10-19 22:20:15','1','admin',NULL,'admin','admin_created','user','1',NULL,'installer','0000000000000000000000000000000000000000000000000000000000000000','a0f97b24bcdf7566e3fca93813f63d2e0b53c4a2b267dac2f359a45387e54bbf'),('2','2026-10-19 22:20:16','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','a0f97b24bcdf7566e3fca93813f63d2e0b53c4a2b267dac2f359a45387e54bbf','e24fee58708f36aab5c6bedd427ee3a0552717fe50b3b2ed57920ee079113580'),('3','2026-10-19 22:20:16','1','admin',NULL,'security','2fa_enabled',NULL,NULL,NULL,'127.0.0.1','e24fee58708f36aab5c6bedd427ee3a0552717fe50b3b2ed57920ee079113580','a2d4c47161a6b6143bf2c422cffb7741ed92be785c1efb47bca49f6b39e06721'),('4','2026-10-19 22:20:16','1',NULL,NULL,'security','2fa_failed',NULL,NULL,NULL,'127.0.0.1','a2d4c47161a6b6143bf2c422cffb7741ed92be785c1efb47bca49f6b39e06721','d28a4b02bb14d6709cb2c9395b7bbb108b502d703fe94419aa99b77770277b81'),('5','2026-10-19 22:20:16','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','d28a4b02bb14d6709cb2c9395b7bbb108b502d703fe94419aa99b77770277b81','831d8a7590af2c0b7db2b91b921fc570985382bd500f648aef58bf99f68c735f'),('6','2026-10-19 22:20:32','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','831d8a7590af2c0b7db2b91b921fc570985382bd500f648aef58bf99f68c735f','70e1e0f1f71fd61236625a08bba6c20b73d96be6cb5961bd5d62a03d8daec451'),('7','2026-10-19 22:21:02','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','70e1e0f1f71fd61236625a08bba6c20b73d96be6cb5961bd5d62a03d8daec451','9616fe27f2bd5e3e7dd4e24cb6e097ea234543dd66977d9e94bbb5004a896032'),('8','2026-10-19 22:21:02','1','admin',NULL,'security','logout',NULL,NULL,NULL,'127.0.0.1','9616fe27f2bd5e3e7dd4e24cb6e097ea234543dd66977d9e94bbb5004a896032','6ca7a96b3b8f6aa04db9b7086adcaf5830e917fc174f20d15015c905bfc026b2'),('9','2026-10-19 22:21:32','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','6ca7a96b3b8f6aa04db9b7086adcaf5830e917fc174f20d15015c905bfc026b2','2e60f28a58746d97cab98ee7ba7e1ade41e36f89041e0b97b3dbe4730b285310'),('10','2026-10-19 22:22:02','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','2e60f28a58746d97cab98ee7ba7e1ade41e36f89041e0b97b3dbe4730b285310','99fc324e548f52240c1ba184eccd2173363ef398fb57f1b6eb7887f77bb365b5'),('11','2026-10-19 22:22:30','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','99fc324e548f52240c1ba184eccd2173363ef398fb57f1b6eb7887f77bb365b5','a3a5fbb12f569c1fb8fbe38e2c8fc96206ed511b18a50230b2d071e4bab76caf'),('12','2026-10-19 22:22:30',NULL,NULL,NULL,'security','login_failed',NULL,NULL,'{\"id\":\"bf7af0996800\",\"reason\":\"unknown\"}','127.0.0.1','a3a5fbb12f569c1fb8fbe38e2c8fc96206ed511b18a50230b2d071e4bab76caf','e0181dd1bb89afe0119a23e3ade30d57dabd827b3f0a9173ae24687231dec3c9'),('13','2026-10-19 22:22:30','1','admin','1','admin','tenant_created','tenant','1','{\"mode\":\"invite\",\"email\":\"alfa@test.local\"}','127.0.0.1','e0181dd1bb89afe0119a23e3ade30d57dabd827b3f0a9173ae24687231dec3c9','07b5411dc7b62b65b7b118934953092761501466c0373e07261ea11b4c6ae1d8'),('14','2026-10-19 22:22:30','1','admin','2','admin','tenant_created','tenant','2','{\"mode\":\"temp\",\"email\":\"beta@test.local\"}','127.0.0.1','07b5411dc7b62b65b7b118934953092761501466c0373e07261ea11b4c6ae1d8','53d55ae0d089f52a4ae7fba215fea416615888f4a5ab2b6147c289eeca7f43c8'),('15','2026-10-19 22:22:30','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','53d55ae0d089f52a4ae7fba215fea416615888f4a5ab2b6147c289eeca7f43c8','93018ed25276814f59d7433b295ba0431cb6d26e86b2b39e7f6917d159dda3b0'),('16','2026-10-19 22:22:31','3','customer','2','security','password_change_failed',NULL,NULL,NULL,'127.0.0.1','93018ed25276814f59d7433b295ba0431cb6d26e86b2b39e7f6917d159dda3b0','3c809d66882ad5d168e3bdc765fa892d81d57b2134bd84df6d709fd86a28324e'),('17','2026-10-19 22:22:31','3','customer','2','security','password_changed',NULL,NULL,NULL,'127.0.0.1','3c809d66882ad5d168e3bdc765fa892d81d57b2134bd84df6d709fd86a28324e','2e57123110ba702a5bf3075d7af141951bbd9e71784a0f3e2b4ce4b8de93f2bf'),('18','2026-10-19 22:22:31','2','customer','1','security','invite_accepted',NULL,NULL,NULL,'127.0.0.1','2e57123110ba702a5bf3075d7af141951bbd9e71784a0f3e2b4ce4b8de93f2bf','3c7bac6a3eef7949a3a16a379906e7002eee8424e46394da7a8799863d89838b'),('19','2026-10-19 22:22:31','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','3c7bac6a3eef7949a3a16a379906e7002eee8424e46394da7a8799863d89838b','c9496e825e31ddae6257d6def75ad1836fe656ab37fc7e8d5ae3bcd2de710d98'),('20','2026-10-19 22:22:31','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','c9496e825e31ddae6257d6def75ad1836fe656ab37fc7e8d5ae3bcd2de710d98','77e47c700c48a766385c010703f6565a2024d6bd42c3404253e816925a080480'),('21','2026-10-19 22:22:31','2','customer','1','security','admin_endpoint_denied','route','/admin/overview',NULL,'127.0.0.1','77e47c700c48a766385c010703f6565a2024d6bd42c3404253e816925a080480','1abb651e0f9337a04c6aa6e80290ee36fa40bfb4ccfa51d2c6a7f07770a4579f'),('22','2026-10-19 22:22:31','2','customer','1','security','admin_endpoint_denied','route','/admin/tenants',NULL,'127.0.0.1','1abb651e0f9337a04c6aa6e80290ee36fa40bfb4ccfa51d2c6a7f07770a4579f','fcff318bd88617981475ca9f1a2560b91ea42843a5d41eed738ecde6d4bd984f'),('23','2026-10-19 22:22:31','2','customer','1','security','admin_endpoint_denied','route','/admin/tenants',NULL,'127.0.0.1','fcff318bd88617981475ca9f1a2560b91ea42843a5d41eed738ecde6d4bd984f','9913a8090df1c3b515e59ffb5834deeef595c878a963e4fa54b52bc73aff86de'),('24','2026-10-19 22:22:31','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','9913a8090df1c3b515e59ffb5834deeef595c878a963e4fa54b52bc73aff86de','9a61958b371486ebba8a5b924f5786839b0b5cfed9183b74a1544634489b2ea5'),('25','2026-10-19 22:22:31','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','9a61958b371486ebba8a5b924f5786839b0b5cfed9183b74a1544634489b2ea5','10df57ad544647ed4cb8602aa3edd485989af00847ebc94c15efc1cd23dd160f'),('26','2026-10-19 22:22:31','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','10df57ad544647ed4cb8602aa3edd485989af00847ebc94c15efc1cd23dd160f','1e1709bedebeae1218524ed77f004566afbbf6b3eb651fb7897e9fcee6695c30'),('27','2026-10-19 22:22:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','1e1709bedebeae1218524ed77f004566afbbf6b3eb651fb7897e9fcee6695c30','283ee928ed71336d8fea327f2944e8201b86a2ec5c1abad5f33bf17b5996393c'),('28','2026-10-19 22:22:32','2',NULL,'1','security','account_locked',NULL,NULL,'{\"level\":1}','127.0.0.1','283ee928ed71336d8fea327f2944e8201b86a2ec5c1abad5f33bf17b5996393c','acb3e16876b9302c827a2397a6afe0fd85445d75f041acf8b33b046a8edc785b'),('29','2026-10-19 22:22:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','acb3e16876b9302c827a2397a6afe0fd85445d75f041acf8b33b046a8edc785b','660ebed8de3ff1a95a919b3103b641eebc2bbaa21a87def9152f01bb8362c79f'),('30','2026-10-19 22:22:32','2',NULL,'1','security','login_locked',NULL,NULL,NULL,'127.0.0.1','660ebed8de3ff1a95a919b3103b641eebc2bbaa21a87def9152f01bb8362c79f','17f55da0c7d135f29a7112cd065d025efee21b85b98c3db25ba603c0b1523d07'),('31','2026-10-19 22:22:32','1','admin','1','admin','tenant_unlocked',NULL,NULL,NULL,'127.0.0.1','17f55da0c7d135f29a7112cd065d025efee21b85b98c3db25ba603c0b1523d07','04336c27a47cef29ca3c17980c9c2fcfb9803a5596ae904fbf06d5dcb9abed01'),('32','2026-10-19 22:22:32','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','04336c27a47cef29ca3c17980c9c2fcfb9803a5596ae904fbf06d5dcb9abed01','a23fb4e2dc80f834eb8823b7c50574bfef9540528355e273aa8740d04beccdfc'),('33','2026-10-19 22:22:32','2',NULL,'1','security','password_reset_requested',NULL,NULL,NULL,'127.0.0.1','a23fb4e2dc80f834eb8823b7c50574bfef9540528355e273aa8740d04beccdfc','648a56af463fc0b9bcc157568c0c6ae143ca375cb531a0a61106e188554fb46c'),('34','2026-10-19 22:22:32','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','648a56af463fc0b9bcc157568c0c6ae143ca375cb531a0a61106e188554fb46c','299b578718bc800e9bd803c023b8af60906da0761aa04378151ffd0720d2fcfb'),('35','2026-10-19 22:22:32','2','customer','1','security','password_reset_done',NULL,NULL,NULL,'127.0.0.1','299b578718bc800e9bd803c023b8af60906da0761aa04378151ffd0720d2fcfb','f7eb826f0878cd5417728665de53ab6b0432a647094c4edd165a5fcc2b5b04e6'),('36','2026-10-19 22:22:32','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','f7eb826f0878cd5417728665de53ab6b0432a647094c4edd165a5fcc2b5b04e6','d55c82ac0ef6b07add25dfe9af309eeeb7460c55f911f88d3d0def8a907e33ad'),('37','2026-10-19 22:22:33','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','d55c82ac0ef6b07add25dfe9af309eeeb7460c55f911f88d3d0def8a907e33ad','d48332e69ff58e1d556bc12bb35fb00fe3612500aa9c7812d91a74dd3ef7b527'),('38','2026-10-19 22:22:33','1','admin','2','admin','tenant_status_suspended','tenant','2','{\"from\":\"active\"}','127.0.0.1','d48332e69ff58e1d556bc12bb35fb00fe3612500aa9c7812d91a74dd3ef7b527','0d94bb34b8987ba9ba91fd0100747e40e109c162cfb43f2e2f2df123c997d541'),('39','2026-10-19 22:22:33','3',NULL,'2','security','login_blocked_suspended',NULL,NULL,NULL,'127.0.0.1','0d94bb34b8987ba9ba91fd0100747e40e109c162cfb43f2e2f2df123c997d541','f6d75ebb927e7951a8e4c1b1b7fd4770c7d357a11264e2bf34fc2893670147d2'),('40','2026-10-19 22:22:33','1','admin','2','admin','tenant_status_active','tenant','2','{\"from\":\"suspended\"}','127.0.0.1','f6d75ebb927e7951a8e4c1b1b7fd4770c7d357a11264e2bf34fc2893670147d2','a6356ac8e0b9d3465656f1d4e017f4d94632be967646caa8e312a9c1039a1c5e'),('41','2026-10-19 22:22:33','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','a6356ac8e0b9d3465656f1d4e017f4d94632be967646caa8e312a9c1039a1c5e','e824bb79d6a5b05cf21497d88d02eb2eb0306d02e8b6c7dcbc64599c1a8e2d2a'),('42','2026-10-19 22:22:33','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','e824bb79d6a5b05cf21497d88d02eb2eb0306d02e8b6c7dcbc64599c1a8e2d2a','2b93938a7bc830cc72b0ea332ea3af166d4096754e7fb23de3906702646c8de0'),('43','2026-10-19 22:22:33','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','2b93938a7bc830cc72b0ea332ea3af166d4096754e7fb23de3906702646c8de0','b7cfb6bafe27a240955dab4c435f20e2a636a7b5e28d9e575f8c5856bd98f5bb'),('44','2026-10-19 22:22:33','2','customer','1','data','workspace_created','workspace','1',NULL,'127.0.0.1','b7cfb6bafe27a240955dab4c435f20e2a636a7b5e28d9e575f8c5856bd98f5bb','c8550d3177d24af9141645132daadd97cf462c2ebb35ea56950053d8b654aac2'),('45','2026-10-19 22:22:33','2','customer','1','data','workspace_created','workspace','2',NULL,'127.0.0.1','c8550d3177d24af9141645132daadd97cf462c2ebb35ea56950053d8b654aac2','eafc13f01bdc92ce51c5405ed0543819127ce40e348ee3f3b842929c399a94ae'),('46','2026-10-19 22:22:33','2','customer','1','data','account_created','account','1','{\"opening_minor\":5000000}','127.0.0.1','eafc13f01bdc92ce51c5405ed0543819127ce40e348ee3f3b842929c399a94ae','5b4dd0f2420e876d9259f947f9d38482184b99a174ee59e991875c109c09d7aa'),('47','2026-10-19 22:22:33','2','customer','1','data','account_created','account','2','{\"opening_minor\":0}','127.0.0.1','5b4dd0f2420e876d9259f947f9d38482184b99a174ee59e991875c109c09d7aa','dc9a655d3fbe1feaacc70b91daaabba238dc3abb30481605527ad5968354118e'),('48','2026-10-19 22:22:33','2','customer','1','data','account_created','account','3','{\"opening_minor\":100000}','127.0.0.1','dc9a655d3fbe1feaacc70b91daaabba238dc3abb30481605527ad5968354118e','5d800109d480ce8d1a070625be0d019f66815b77750073eabd3ef3a4ef2c8922'),('49','2026-10-19 22:22:33','2','customer','1','data','account_created','account','4','{\"opening_minor\":200000}','127.0.0.1','5d800109d480ce8d1a070625be0d019f66815b77750073eabd3ef3a4ef2c8922','8dee91fed36e448d93da201d2241753a150226f536640cefe012f13120725afb'),('50','2026-10-19 22:22:33','2','customer','1','data','account_created','account','5','{\"opening_minor\":1000000}','127.0.0.1','8dee91fed36e448d93da201d2241753a150226f536640cefe012f13120725afb','e962a02376f9d4f8e377fb5e09a23067b27f965b80bad652f9fd349de55c96c2'),('51','2026-10-19 22:22:33','2','customer','1','data','account_created','account','6','{\"opening_minor\":0}','127.0.0.1','e962a02376f9d4f8e377fb5e09a23067b27f965b80bad652f9fd349de55c96c2','6dd7cbf3cb4b645562fe2e98b675075808872efcf3f6e405a42d12a5ed9d333c'),('52','2026-10-19 22:22:33','2','customer','1','data','contact_created','contact','1',NULL,'127.0.0.1','6dd7cbf3cb4b645562fe2e98b675075808872efcf3f6e405a42d12a5ed9d333c','99f9be306915f0bae1e644e8d98f03c1e945e745773a1c4b336c143f9eba617a'),('53','2026-10-19 22:22:34','2','customer','1','data','contact_created','contact','2',NULL,'127.0.0.1','99f9be306915f0bae1e644e8d98f03c1e945e745773a1c4b336c143f9eba617a','86d814d7e8ef2645c77c0bec4461bd105e9fb8feadb0ba1cf4aca40eae42e4ff'),('54','2026-10-19 22:22:34','2','customer','1','data','entry_created','entry','1','{\"kind\":\"receivable\",\"amount_minor\":10000000,\"installments\":1}','127.0.0.1','86d814d7e8ef2645c77c0bec4461bd105e9fb8feadb0ba1cf4aca40eae42e4ff','d8d6406e002897c94550c11210d9192c88a3f9107db9d64a50db3cbc56e41038'),('55','2026-10-19 22:22:34','2','customer','1','data','collection_created','transaction','1','{\"amount_minor\":6000000,\"contact_id\":1,\"allocations\":{\"1\":6000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','d8d6406e002897c94550c11210d9192c88a3f9107db9d64a50db3cbc56e41038','5c74210b51d26da76541feb08f4c0e0aa7f1657ca6774df5678945998f1c8695'),('56','2026-10-19 22:22:34','2','customer','1','data','collection_created','transaction','2','{\"amount_minor\":4000000,\"contact_id\":1,\"allocations\":{\"1\":4000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','5c74210b51d26da76541feb08f4c0e0aa7f1657ca6774df5678945998f1c8695','1b52a0f9aa1dba12fa2f749c44f3340d824f810eb294f4caadffbf0ca98b6b19'),('57','2026-10-19 22:22:34','2','customer','1','data','transfer_created','transfer','fc4db87785aaa122ae7de91aae','{\"from\":1,\"to\":2,\"amount_minor\":2000000,\"kind\":\"transfer\"}','127.0.0.1','1b52a0f9aa1dba12fa2f749c44f3340d824f810eb294f4caadffbf0ca98b6b19','dc70f24732620eed759a4986f2bba9cb74f43f48eee816f7fa5a7454c5d38708'),('58','2026-10-19 22:22:34','2','customer','1','data','entry_created','entry','2','{\"kind\":\"payable\",\"amount_minor\":500000,\"installments\":1}','127.0.0.1','dc70f24732620eed759a4986f2bba9cb74f43f48eee816f7fa5a7454c5d38708','25897cc48bdcf1c2bab3276980f4cd275a92e4fd0415f675fd53daabab0471e7'),('59','2026-10-19 22:22:34','2','customer','1','data','invoice_created','invoice','1','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":120000,\"due_date\":\"2026-11-04\",\"new_items\":0}','127.0.0.1','25897cc48bdcf1c2bab3276980f4cd275a92e4fd0415f675fd53daabab0471e7','aa846f76eaad43977694995bf4ebd189b70be0968f1c6109b451d6344bac7388'),('60','2026-10-19 22:22:35','2','customer','1','data','collection_created','transaction','5','{\"amount_minor\":120000,\"contact_id\":1,\"allocations\":{\"5\":120000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','aa846f76eaad43977694995bf4ebd189b70be0968f1c6109b451d6344bac7388','ef777a468f15b0dbaee7dd39d1c8ea6e7e056a49695ec7a2a199c9e9b0d26c00'),('61','2026-10-19 22:22:35','2','customer','1','data','entry_created','entry','7','{\"kind\":\"receivable\",\"amount_minor\":50000,\"installments\":1}','127.0.0.1','ef777a468f15b0dbaee7dd39d1c8ea6e7e056a49695ec7a2a199c9e9b0d26c00','ed259dbb4f2da4c1beb93d5b3fcd98de4fa75713c97ac41c48086d11bd568594'),('62','2026-10-19 22:22:35','2','customer','1','data','fx_created','transfer','81a4299103ed4607f14baec8bf','{\"out\":1000000,\"in\":25000,\"rate\":\"0.02500000\",\"fee\":1500}','127.0.0.1','ed259dbb4f2da4c1beb93d5b3fcd98de4fa75713c97ac41c48086d11bd568594','e86933a25a45850c76ec10709f10c0e8a464880dbfb5622de3b69cb3ac794462'),('63','2026-10-19 22:22:35','2','customer','1','data','entry_created','entry','8','{\"kind\":\"payable\",\"amount_minor\":1000000,\"installments\":1}','127.0.0.1','e86933a25a45850c76ec10709f10c0e8a464880dbfb5622de3b69cb3ac794462','5a7e87f08042ddfc876ccbb88f5ad2311663098513dba0b96ad02760d743b1da'),('64','2026-10-19 22:22:35','2','customer','1','data','payment_created','transaction','9','{\"amount_minor\":300000,\"contact_id\":2,\"allocations\":{\"8\":300000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','5a7e87f08042ddfc876ccbb88f5ad2311663098513dba0b96ad02760d743b1da','a6a73c3243144e4c148680d1fb8495b0e9f1037e8cc490804197fbc89dd6917a'),('65','2026-10-19 22:22:35','2','customer','1','data','entry_rescheduled','entry','8','{\"before\":{\"due_date\":\"2026-10-17\"},\"after\":{\"due_date\":\"2026-10-30\"}}','127.0.0.1','a6a73c3243144e4c148680d1fb8495b0e9f1037e8cc490804197fbc89dd6917a','f26129451a3a12657ce3269e8b26178e087afd57895312035c509c2aab2d2f0f'),('66','2026-10-19 22:22:35','2','customer','1','data','card_created','card','1',NULL,'127.0.0.1','f26129451a3a12657ce3269e8b26178e087afd57895312035c509c2aab2d2f0f','e6aa24c9d7ee4e183ff5531ef626b8697390ac27128b290a21e9f414f57bd4ae'),('67','2026-10-19 22:22:35','2','customer','1','data','card_purchase','card_purchase','1','{\"amount_minor\":120000,\"installments\":3}','127.0.0.1','e6aa24c9d7ee4e183ff5531ef626b8697390ac27128b290a21e9f414f57bd4ae','bcd88d26c9af66f9ac23d8f061938100c1c7b3dcb1645ad1a88c3517e0c0c354'),('68','2026-10-19 22:22:35','2','customer','1','data','card_payment','card','1','{\"txn\":10,\"amount_minor\":40000}','127.0.0.1','bcd88d26c9af66f9ac23d8f061938100c1c7b3dcb1645ad1a88c3517e0c0c354','49483204affcda35219d784a4eb3a73a9fcd60968ee5993bf50ff1e2ee1369a5'),('69','2026-10-19 22:22:36','2','customer','1','data','loan_created','loan','1','{\"principal_minor\":12000000,\"term\":12}','127.0.0.1','49483204affcda35219d784a4eb3a73a9fcd60968ee5993bf50ff1e2ee1369a5','110f68f54e52bdfe679d0b653df4a1868a6782c7d080cdabbc0f67718b3a116a'),('70','2026-10-19 22:22:36','2','customer','1','data','loan_payment','loan','1','{\"txn\":12,\"seq\":1}','127.0.0.1','110f68f54e52bdfe679d0b653df4a1868a6782c7d080cdabbc0f67718b3a116a','75e6057407b493bc25ac84bc96c08fa41c06454184c5109f93d95938d62328a3'),('71','2026-10-19 22:22:36','2','customer','1','data','entry_created','entry','9','{\"kind\":\"payable\",\"amount_minor\":80000,\"installments\":1}','127.0.0.1','75e6057407b493bc25ac84bc96c08fa41c06454184c5109f93d95938d62328a3','a6d4d9fce8b334fbcc358a3b46fe22138d67bfe0cbdbf3cc375bbf29063beb4a'),('72','2026-10-19 22:22:36','2','customer','1','data','statement_imported','account','1','{\"added\":3,\"duplicates\":0}','127.0.0.1','a6d4d9fce8b334fbcc358a3b46fe22138d67bfe0cbdbf3cc375bbf29063beb4a','e190d7bfe3a4820e1a8762afefc74c11aca6c72cbda64ebb5658bd11e4b6a1c6'),('73','2026-10-19 22:22:36','2','customer','1','data','statement_imported','account','1','{\"added\":0,\"duplicates\":3}','127.0.0.1','e190d7bfe3a4820e1a8762afefc74c11aca6c72cbda64ebb5658bd11e4b6a1c6','0f597bd959851cf6af1d5884ecc09fb07e0fa58565c94cda5eae6912e7a513b6'),('74','2026-10-19 22:22:36','2','customer','1','data','statement_line_posted','statement_line','1','{\"txn\":13}','127.0.0.1','0f597bd959851cf6af1d5884ecc09fb07e0fa58565c94cda5eae6912e7a513b6','69e3d53415f2caa6f6550fc56cf80b7a9f3a796c848d1cc831924eed8787e0d7'),('75','2026-10-19 22:22:36','2','customer','1','data','project_created','project','1',NULL,'127.0.0.1','69e3d53415f2caa6f6550fc56cf80b7a9f3a796c848d1cc831924eed8787e0d7','7f8a54185b247281598f85d06f0fb2dad471f6584fe7cf7889ae09a3252ae46f'),('76','2026-10-19 22:22:36','2','customer','1','data','invoice_created','invoice','3','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":1200000,\"due_date\":null,\"new_items\":0}','127.0.0.1','7f8a54185b247281598f85d06f0fb2dad471f6584fe7cf7889ae09a3252ae46f','7e5ba375a49a91547c5f37c860b195af093f4390ad835c1970df4e27bab796fe'),('77','2026-10-19 22:22:36','2','customer','1','data','collection_created','transaction','14','{\"amount_minor\":1200000,\"contact_id\":1,\"allocations\":{\"10\":1200000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','7e5ba375a49a91547c5f37c860b195af093f4390ad835c1970df4e27bab796fe','b72a5a9f5b8c681114cb2a201eaecf554c91fc971c7c66332e65b8dd2dd59d38'),('78','2026-10-19 22:22:36','2','customer','1','data','invoice_created','invoice','4','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":480000,\"due_date\":null,\"new_items\":0}','127.0.0.1','b72a5a9f5b8c681114cb2a201eaecf554c91fc971c7c66332e65b8dd2dd59d38','eae9254cc13e04a45d186f376f1945f416c0b0c46bc30bafc43da936627f39a5'),('79','2026-10-19 22:22:37','2','customer','1','data','payment_created','transaction','15','{\"amount_minor\":480000,\"contact_id\":2,\"allocations\":{\"11\":480000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','eae9254cc13e04a45d186f376f1945f416c0b0c46bc30bafc43da936627f39a5','519b490f53aa2bfc97485c5276608574032391971d5f476f5285c012c5c238ee'),('80','2026-10-19 22:22:37','2','customer','1','data','transaction_created','transaction','16','{\"kind\":\"expense\",\"amount_minor\":50000,\"replaces\":null}','127.0.0.1','519b490f53aa2bfc97485c5276608574032391971d5f476f5285c012c5c238ee','45456625b9795d9d4ade8cef8148881852bde6da123368de838c7d35d21f82b1'),('81','2026-10-19 22:22:37','2','customer','1','data','invoice_created','invoice','5','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":120000,\"due_date\":null,\"new_items\":0}','127.0.0.1','45456625b9795d9d4ade8cef8148881852bde6da123368de838c7d35d21f82b1','18261c6a14cfae3dd191b067f0d4bc2e04027f06d076431aecd52d76c4c8d6c8'),('82','2026-10-19 22:22:37','2','customer','1','data','stock_movement','stock_movement','2','{\"kind\":\"out\",\"qty_milli\":2000}','127.0.0.1','18261c6a14cfae3dd191b067f0d4bc2e04027f06d076431aecd52d76c4c8d6c8','2e1dab797fa9464adc0641c8bb7e63a56d5d1a83bd4a75e0e8ef6da1ff062855'),('83','2026-10-19 22:22:37','2','customer','1','data','settings_changed',NULL,NULL,NULL,'127.0.0.1','2e1dab797fa9464adc0641c8bb7e63a56d5d1a83bd4a75e0e8ef6da1ff062855','2684e4dc1591b00fb4e882ae082df25a62a29620621f21d66fdfaf3dc38a930e'),('84','2026-10-19 22:22:37','2','customer','1','data','stock_movement','stock_movement','3','{\"kind\":\"out\",\"qty_milli\":9000}','127.0.0.1','2684e4dc1591b00fb4e882ae082df25a62a29620621f21d66fdfaf3dc38a930e','847d5c5d3c787c84b7ebf98833966d701974648fb5cdb7bb00f93e1b5fce6a87'),('85','2026-10-19 22:22:37','2','customer','1','data','settings_changed',NULL,NULL,NULL,'127.0.0.1','847d5c5d3c787c84b7ebf98833966d701974648fb5cdb7bb00f93e1b5fce6a87','337b627afd1d32ab756823820fcb92d01f107f353968f7dbe8cd39d41c01c10a'),('86','2026-10-19 22:22:37','2','customer','1','data','transaction_created','transaction','17','{\"kind\":\"income\",\"amount_minor\":100000,\"replaces\":null}','127.0.0.1','337b627afd1d32ab756823820fcb92d01f107f353968f7dbe8cd39d41c01c10a','6532761450145eaffb14891e15dcadb13fdc49438bf5b064e5ff4a91aeeb4cec'),('87','2026-10-19 22:22:37','2','customer','1','data','transaction_voided','transaction','17','{\"reason\":\"Hatalı giriş\",\"before\":{\"kind\":\"income\",\"amount_minor\":100000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[17]}','127.0.0.1','6532761450145eaffb14891e15dcadb13fdc49438bf5b064e5ff4a91aeeb4cec','baf2c6fae905da2c9bd66f7544ed9de6cd391a55986ea156d9018dcf6e7733f9'),('88','2026-10-19 22:22:37','2','customer','1','data','transaction_created','transaction','18','{\"kind\":\"expense\",\"amount_minor\":10000,\"replaces\":null}','127.0.0.1','baf2c6fae905da2c9bd66f7544ed9de6cd391a55986ea156d9018dcf6e7733f9','7a035812f83e9ac9ac09d545fd9d77e36098a7723d16a610d46c419df0ab5b4c'),('89','2026-10-19 22:22:37','2','customer','1','data','transaction_voided','transaction','18','{\"reason\":\"Düzenleme ile yenisi oluşturuldu\",\"before\":{\"kind\":\"expense\",\"amount_minor\":10000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[18]}','127.0.0.1','7a035812f83e9ac9ac09d545fd9d77e36098a7723d16a610d46c419df0ab5b4c','d6a7451cd3dcf0d1b6af2b766bb7d46f31dc7f3c977d0889b3dbfe4325f7d3ce'),('90','2026-10-19 22:22:37','2','customer','1','data','transaction_replaced','transaction','19','{\"kind\":\"expense\",\"amount_minor\":12000,\"replaces\":18}','127.0.0.1','d6a7451cd3dcf0d1b6af2b766bb7d46f31dc7f3c977d0889b3dbfe4325f7d3ce','789b402475eb8de0b0eb56a5d69e6f5109280b6e9c2e07e03c7632d3e20ea0a6'),('91','2026-10-19 22:22:37','2','customer','1','data','transaction_created','transaction','20','{\"kind\":\"expense\",\"amount_minor\":120000,\"replaces\":null}','127.0.0.1','789b402475eb8de0b0eb56a5d69e6f5109280b6e9c2e07e03c7632d3e20ea0a6','6a284c80afb14d4938e9aaff50790092b938eab402a5edc40da83d7bab926c31'),('92','2026-10-19 22:22:37','2','customer','1','data','transaction_created','transaction','21','{\"kind\":\"expense\",\"amount_minor\":120000,\"replaces\":null}','127.0.0.1','6a284c80afb14d4938e9aaff50790092b938eab402a5edc40da83d7bab926c31','a036baaf5d67f5a40dfea95acf7c6d38bc985500cc8b289c94e5d64c371009b9'),('93','2026-10-19 22:22:37','2','customer','1','data','balance_adjusted','account','2','{\"delta_minor\":-5000,\"reason\":\"Sayım farkı\"}','127.0.0.1','a036baaf5d67f5a40dfea95acf7c6d38bc985500cc8b289c94e5d64c371009b9','ddbabebc09ddcf0e0ca50a9c3351e1f13b67f37e1703ac833810623d8a60d279'),('94','2026-10-19 22:22:38','3','customer','2','data','workspace_created','workspace','3',NULL,'127.0.0.1','ddbabebc09ddcf0e0ca50a9c3351e1f13b67f37e1703ac833810623d8a60d279','7db153c02f54e094173ae3b4a5dab19aa2fd11947d443c4850c4a57dde933a7f'),('95','2026-10-19 22:22:38','3','customer','2','data','account_created','account','7','{\"opening_minor\":100}','127.0.0.1','7db153c02f54e094173ae3b4a5dab19aa2fd11947d443c4850c4a57dde933a7f','f055dd67c99254dbc4221e74dc0623b1afc5923e941a4281fd02834cee8bec5e'),('96','2026-10-19 22:22:39','2','customer','1','data','document_uploaded','transaction','18','{\"doc\":1,\"size\":70}','127.0.0.1','f055dd67c99254dbc4221e74dc0623b1afc5923e941a4281fd02834cee8bec5e','1ce32e26aa9407611c49eb3d51430cc5646460152795f49dd67f6fe6d47b09ff'),('97','2026-10-19 22:22:39','2','customer','1','data','export_transactions',NULL,NULL,'{\"format\":\"csv\",\"rows\":20}','127.0.0.1','1ce32e26aa9407611c49eb3d51430cc5646460152795f49dd67f6fe6d47b09ff','ad8ddaec3d190f04e272d8bb1bc7356337bce31252e1c5648dfa78db0ab68aae'),('98','2026-10-19 22:22:39','2','customer','1','data','transaction_created','transaction','23','{\"kind\":\"expense\",\"amount_minor\":100,\"replaces\":null}','127.0.0.1','ad8ddaec3d190f04e272d8bb1bc7356337bce31252e1c5648dfa78db0ab68aae','a2516b795161dc209574dcf7989db31136e93ceb9e69a8be9fd068e54d94e8eb'),('99','2026-10-19 22:22:39','2','customer','1','data','export_transactions',NULL,NULL,'{\"format\":\"csv\",\"rows\":21}','127.0.0.1','a2516b795161dc209574dcf7989db31136e93ceb9e69a8be9fd068e54d94e8eb','1e5fa8c7266448a6e32803533d9fbcbc1dd958b3eb90b354436b207e03297763'),('100','2026-10-19 22:22:39','2','customer','1','data','export_income-expense',NULL,NULL,'{\"format\":\"xlsx\",\"rows\":1}','127.0.0.1','1e5fa8c7266448a6e32803533d9fbcbc1dd958b3eb90b354436b207e03297763','35081f1dd7a674ca909d15c6a9fb9faa7fd3865287de5eee70d2af84fafcba1f'),('101','2026-10-19 22:22:39','2','customer','1','data','export_vat',NULL,NULL,'{\"format\":\"csv\",\"rows\":4}','127.0.0.1','35081f1dd7a674ca909d15c6a9fb9faa7fd3865287de5eee70d2af84fafcba1f','d3182074c42d302e309b29e15145d70a7e2b26d06b7866cb0e05cf1986f819c5'),('102','2026-10-19 22:22:39','2','customer','1','data','tenant_data_export',NULL,NULL,NULL,'127.0.0.1','d3182074c42d302e309b29e15145d70a7e2b26d06b7866cb0e05cf1986f819c5','d8cd4eae8f654317045db5de336d445c67e8a6ae3c1f6f283ad67c6b6356914f'),('103','2026-10-19 22:22:39','2','customer','1','data','settings_changed',NULL,NULL,NULL,'127.0.0.1','d8cd4eae8f654317045db5de336d445c67e8a6ae3c1f6f283ad67c6b6356914f','d225f644fb28e4eb70787e52671a4a14d24679d33e217b42873b228ea47bdde7'),('104','2026-10-19 22:23:00','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','d225f644fb28e4eb70787e52671a4a14d24679d33e217b42873b228ea47bdde7','764b70fae696dcf240f1fd720dd66133aeb503e498f052f585ad1645b597aa88'),('105','2026-10-19 22:23:00','1','admin','1','access','admin_view_tenant_data','accounts',NULL,NULL,'127.0.0.1','764b70fae696dcf240f1fd720dd66133aeb503e498f052f585ad1645b597aa88','e2da0c7b99f4c19548da0bb9e498d3b16699f385c6d66e72fbc931da73071f1e'),('106','2026-10-19 22:23:00','1','admin','1','access','admin_view_tenant_data','transactions',NULL,NULL,'127.0.0.1','e2da0c7b99f4c19548da0bb9e498d3b16699f385c6d66e72fbc931da73071f1e','7728478c5d9ef23fda25aa679fb2b26f1a1993205fd983c190e7905015d4fc9f'),('107','2026-10-19 22:23:00','1','admin','1','access','admin_view_tenant_data','reports',NULL,NULL,'127.0.0.1','7728478c5d9ef23fda25aa679fb2b26f1a1993205fd983c190e7905015d4fc9f','4a16423633d8e68a6eea0480393a492597f074e4cb9aea58d771fe32f1695b74'),('108','2026-10-19 22:23:00','2','customer','1','data','transaction_created','transaction','24','{\"kind\":\"expense\",\"amount_minor\":7700,\"replaces\":null}','127.0.0.1','4a16423633d8e68a6eea0480393a492597f074e4cb9aea58d771fe32f1695b74','b7d83faea55d5d33b3d0cc21db10c56c546a899af83af870abf3d7f027b81a62'),('109','2026-10-19 22:23:01','1','admin','1','data','transaction_voided','transaction','24','{\"reason\":\"[Yönetici düzeltmesi] Mükerrer giriş\",\"before\":{\"kind\":\"expense\",\"amount_minor\":7700,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[24]}','127.0.0.1','b7d83faea55d5d33b3d0cc21db10c56c546a899af83af870abf3d7f027b81a62','646155708fd1de0aa0400dca9182fee3473d9f081956266664cfcea91c9164b0'),('110','2026-10-19 22:23:01','1','admin','1','admin','admin_correction_void','transaction','24','{\"reason\":\"Mükerrer giriş\",\"legs\":[24]}','127.0.0.1','646155708fd1de0aa0400dca9182fee3473d9f081956266664cfcea91c9164b0','c33264582632845f5bcac00fe3f48abe1ec9945e107e12b84ff9938963ca0106'),('111','2026-10-19 22:23:01','1','admin','1','admin','tenant_status_archived','tenant','1','{\"from\":\"active\"}','127.0.0.1','c33264582632845f5bcac00fe3f48abe1ec9945e107e12b84ff9938963ca0106','f510db6f927ae79831e8660f6ae69ca9f77850ff10bc17ff3236d7d7b000fbe4'),('112','2026-10-19 22:23:01','1','admin','1','admin','tenant_status_active','tenant','1','{\"from\":\"archived\"}','127.0.0.1','f510db6f927ae79831e8660f6ae69ca9f77850ff10bc17ff3236d7d7b000fbe4','89ed498e0ac2db2ea1ada394c864d67f9612652531633c03d20b5a40c8bee494'),('113','2026-10-19 22:23:01','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','89ed498e0ac2db2ea1ada394c864d67f9612652531633c03d20b5a40c8bee494','8f4b07789f0ef193dad0a33aa6a6f0ff5f4f71a4acb608ad0ac48ca0c0387db6'),('114','2026-10-19 22:23:01','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','8f4b07789f0ef193dad0a33aa6a6f0ff5f4f71a4acb608ad0ac48ca0c0387db6','e3966f192d21421082ddc7a99caae7bfa711d99d57013d41159a23b46ea45cb4'),('115','2026-10-19 22:23:01','2','customer','1','data','invoice_created','invoice','6','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":100000,\"due_date\":null,\"new_items\":0}','127.0.0.1','e3966f192d21421082ddc7a99caae7bfa711d99d57013d41159a23b46ea45cb4','32c59c220a7b9db9ade5d71650e4341879444fe75c9db3483b63ca17ce21d43b'),('116','2026-10-19 22:23:01','2','customer','1','data','invoice_created','invoice','7','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"new_items\":0}','127.0.0.1','32c59c220a7b9db9ade5d71650e4341879444fe75c9db3483b63ca17ce21d43b','8fe31abc306e31995b8f647ce5b525d6e017d57362c7de8c807a0cd9f67206dc'),('117','2026-10-19 22:23:01','2','customer','1','data','invoice_created','invoice','8','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":50000,\"due_date\":\"2026-12-04\",\"new_items\":0}','127.0.0.1','8fe31abc306e31995b8f647ce5b525d6e017d57362c7de8c807a0cd9f67206dc','a6d1c1b9baaf116b4e1b40f5b9e53babc7098c13b55a3b0465b7c34caf26a1c9'),('118','2026-10-19 22:23:02','2','customer','1','data','invoice_updated','invoice','7','{\"before\":{\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"lines\":1},\"after\":{\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"lines\":1}}','127.0.0.1','a6d1c1b9baaf116b4e1b40f5b9e53babc7098c13b55a3b0465b7c34caf26a1c9','8bdecdde9458e0d6993fa1c936d820d54d85a3deb20d4d2faffe4e95b0a4af57'),('119','2026-10-19 22:23:02','2','customer','1','data','invoice_updated','invoice','7','{\"before\":{\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"lines\":1},\"after\":{\"total_minor\":50000,\"due_date\":null,\"lines\":1}}','127.0.0.1','8bdecdde9458e0d6993fa1c936d820d54d85a3deb20d4d2faffe4e95b0a4af57','e08cc163b9cf4003c15b107ecd0b33bcc65d927f6d9d09054f9b0ade90855ec0'),('120','2026-10-19 22:23:02','2','customer','1','data','entry_rescheduled','entry','15','{\"before\":{\"due_date\":null},\"after\":{\"due_date\":\"2026-10-30\"}}','127.0.0.1','e08cc163b9cf4003c15b107ecd0b33bcc65d927f6d9d09054f9b0ade90855ec0','77dd3be9230497572691c53c6249b5c7683f93e730428378699ceee19249632b'),('121','2026-10-19 22:23:02','2','customer','1','data','invoice_created','invoice','9','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','77dd3be9230497572691c53c6249b5c7683f93e730428378699ceee19249632b','2312ceaa53d69b1f77e3407d1d4a8697bca3cd9e29e3fd1d7ad913d6772797db'),('122','2026-10-19 22:23:02','2','customer','1','data','payment_created','transaction','25','{\"amount_minor\":400000,\"contact_id\":2,\"allocations\":{\"17\":400000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','2312ceaa53d69b1f77e3407d1d4a8697bca3cd9e29e3fd1d7ad913d6772797db','510506300dbff0f367727017cd12236f9f4437b205c7516a829a64b79899fbe6'),('123','2026-10-19 22:23:02','2','customer','1','data','payment_created','transaction','26','{\"amount_minor\":600000,\"contact_id\":2,\"allocations\":{\"17\":600000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','510506300dbff0f367727017cd12236f9f4437b205c7516a829a64b79899fbe6','2b967e30b96daead8cc26c929b684e7014b096bf19a2aef40de4febbd980d42d'),('124','2026-10-19 22:23:02','2','customer','1','data','invoice_created','invoice','10','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','2b967e30b96daead8cc26c929b684e7014b096bf19a2aef40de4febbd980d42d','e0ca058b1c200ee9602d19138526c11aa8b453a5345058e98c1c0ae817f55624'),('125','2026-10-19 22:23:02','2','customer','1','data','payment_created','transaction','27','{\"amount_minor\":3000000,\"contact_id\":2,\"allocations\":{\"18\":1000000},\"unallocated_minor\":2000000,\"for_workspace_id\":null}','127.0.0.1','e0ca058b1c200ee9602d19138526c11aa8b453a5345058e98c1c0ae817f55624','c5d3416edc7be4b7a86ed84c07290962d1f6bc7ec19b658d645509e81707aaea'),('126','2026-10-19 22:23:02','2','customer','1','data','invoice_created','invoice','11','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','c5d3416edc7be4b7a86ed84c07290962d1f6bc7ec19b658d645509e81707aaea','27921a78bae8de9f10ea20ba38d85f398d7343a772ceee87839bf40e5aaee613'),('127','2026-10-19 22:23:02','2','customer','1','data','invoice_created','invoice','12','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":6000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','27921a78bae8de9f10ea20ba38d85f398d7343a772ceee87839bf40e5aaee613','1f2c422a59024b9ebf5c15ba4dc80ba77786a0e730766edadd6795b04fd74b25'),('128','2026-10-19 22:23:03','2','customer','1','data','invoice_created','invoice','13','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":4500000,\"due_date\":null,\"new_items\":0}','127.0.0.1','1f2c422a59024b9ebf5c15ba4dc80ba77786a0e730766edadd6795b04fd74b25','923572c58d3661a4a09f941d5d75e113440048df52b53b03e08a3b0d3bdd5271'),('129','2026-10-19 22:23:03','2','customer','1','data','payment_created','transaction','28','{\"amount_minor\":5000000,\"contact_id\":2,\"allocations\":{\"19\":1000000,\"20\":4000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','923572c58d3661a4a09f941d5d75e113440048df52b53b03e08a3b0d3bdd5271','9f33ac7be879d17e319dc83937ddfb60ad37d84972c9dfcea36d3dd97690f76b'),('130','2026-10-19 22:23:03','2','customer','1','data','payment_allocated','transaction','27','{\"new_minor\":2000000,\"allocated_minor\":3000000,\"unallocated_minor\":0}','127.0.0.1','9f33ac7be879d17e319dc83937ddfb60ad37d84972c9dfcea36d3dd97690f76b','878221d305471296534e749662df431912fbd6c3e416b43fe3d7a8774c6fed2e'),('131','2026-10-19 22:23:03','2','customer','1','data','allocation_reversed','transaction','27','{\"entry_id\":21,\"amount_minor\":2000000}','127.0.0.1','878221d305471296534e749662df431912fbd6c3e416b43fe3d7a8774c6fed2e','0d03c442e1a60ff14f8608b5f0fa1f8ca2dc4e3383c02efa3ebffbb7cd2e6d5c'),('132','2026-10-19 22:23:03','2','customer','1','data','allocations_replaced','transaction','27','{\"new_minor\":2000000,\"allocated_minor\":2000000,\"unallocated_minor\":1000000}','127.0.0.1','0d03c442e1a60ff14f8608b5f0fa1f8ca2dc4e3383c02efa3ebffbb7cd2e6d5c','4bd0c31800c151d996f24b4e4144e420068ff6f6c937a94cd17c1385fcf8067d'),('133','2026-10-19 22:23:03','2','customer','1','data','payment_created','transaction','29','{\"amount_minor\":10000,\"contact_id\":2,\"allocations\":[],\"unallocated_minor\":10000,\"for_workspace_id\":null}','127.0.0.1','4bd0c31800c151d996f24b4e4144e420068ff6f6c937a94cd17c1385fcf8067d','50401c47241cc9479dc42245c9f4738842abcc454550d8b77388880ad0608c85'),('134','2026-10-19 22:23:03','2','customer','1','data','payment_created','transaction','30','{\"amount_minor\":7000,\"contact_id\":2,\"allocations\":[],\"unallocated_minor\":7000,\"for_workspace_id\":null}','127.0.0.1','50401c47241cc9479dc42245c9f4738842abcc454550d8b77388880ad0608c85','8059dbf92551f03f37ab36b4327867ae4bb175fa4ca601ca0f3e314a2db22529'),('135','2026-10-19 22:23:03','2','customer','1','data','payment_created','transaction','31','{\"amount_minor\":7000,\"contact_id\":2,\"allocations\":[],\"unallocated_minor\":7000,\"for_workspace_id\":null}','127.0.0.1','8059dbf92551f03f37ab36b4327867ae4bb175fa4ca601ca0f3e314a2db22529','a50bc1b38c9da28081541808ffedb3a8b278b0449ae9cdbd96fc8a2fde7a863d'),('136','2026-10-19 22:23:03','2','customer','1','data','invoice_created','invoice','14','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":500000,\"due_date\":null,\"new_items\":0}','127.0.0.1','a50bc1b38c9da28081541808ffedb3a8b278b0449ae9cdbd96fc8a2fde7a863d','ee7bdae96280bee857379c838fdefa8f46377ae47854482c7705f148c19dcc01'),('137','2026-10-19 22:23:03','2','customer','1','data','collection_created','transaction','32','{\"amount_minor\":800000,\"contact_id\":1,\"allocations\":{\"22\":500000},\"unallocated_minor\":300000,\"for_workspace_id\":null}','127.0.0.1','ee7bdae96280bee857379c838fdefa8f46377ae47854482c7705f148c19dcc01','36b91eceb05e055a822b7ebd3dbd01dc4735e5779f1d6f207ccd77061293b897'),('138','2026-10-19 22:23:04','2','customer','1','data','transaction_voided','transaction','28','{\"reason\":\"test iptal\",\"before\":{\"kind\":\"payment\",\"amount_minor\":5000000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[28]}','127.0.0.1','36b91eceb05e055a822b7ebd3dbd01dc4735e5779f1d6f207ccd77061293b897','8ab3282d96b3dba3c99aef01769f6db3654f3a0d3d24dc9a25f3f4a6f7f8d14a'),('139','2026-10-19 22:23:04','2','customer','1','data','stock_item_autocreated','stock_item','2','{\"name\":\"Buzdolabı T4\",\"kind\":\"product\"}','127.0.0.1','8ab3282d96b3dba3c99aef01769f6db3654f3a0d3d24dc9a25f3f4a6f7f8d14a','a963e6fcbb71d6e4a8fa6c7f8f39d5a5253be60f97876922ed50288169889f7f'),('140','2026-10-19 22:23:04','2','customer','1','data','stock_item_autocreated','stock_item','3','{\"name\":\"Televizyon T4\",\"kind\":\"product\"}','127.0.0.1','a963e6fcbb71d6e4a8fa6c7f8f39d5a5253be60f97876922ed50288169889f7f','ecc88f9be79d2bc485b3ab5811137fb3bbe07217aab35334f08b3a162c71b284'),('141','2026-10-19 22:23:04','2','customer','1','data','stock_item_autocreated','stock_item','4','{\"name\":\"Nakliye T4\",\"kind\":\"service\"}','127.0.0.1','ecc88f9be79d2bc485b3ab5811137fb3bbe07217aab35334f08b3a162c71b284','f3fea976ce0fe3c4cc4ea9543ea7ab05c98459da206953d8721c14bcef65462d'),('142','2026-10-19 22:23:04','2','customer','1','data','invoice_created','invoice','15','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":7990000,\"due_date\":null,\"new_items\":3}','127.0.0.1','f3fea976ce0fe3c4cc4ea9543ea7ab05c98459da206953d8721c14bcef65462d','84bfba0ec40bf1069ffcfed8c1af1ea24ef6fb5435d0929bbb4c8429ca6cbebc'),('143','2026-10-19 22:23:04','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":7990000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":7990000,\"due_date\":null,\"lines\":4}}','127.0.0.1','84bfba0ec40bf1069ffcfed8c1af1ea24ef6fb5435d0929bbb4c8429ca6cbebc','a7bcb25661ec48b4fbe6ae5f07d9dd649985a0d8ddf5cf78ea26fd2f07a2ee9e'),('144','2026-10-19 22:23:04','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":7990000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4}}','127.0.0.1','a7bcb25661ec48b4fbe6ae5f07d9dd649985a0d8ddf5cf78ea26fd2f07a2ee9e','960e094d8379ebab8d39a30501ba5e83bfd867c69c8b651bf14a3a1c24818b1c'),('145','2026-10-19 22:23:04','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4}}','127.0.0.1','960e094d8379ebab8d39a30501ba5e83bfd867c69c8b651bf14a3a1c24818b1c','b9c14863a6cc3e2c7a5f890bc057babfbf68636a1e50b9e01e6d5415983e4460'),('146','2026-10-19 22:23:04','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":5590000,\"due_date\":null,\"lines\":4}}','127.0.0.1','b9c14863a6cc3e2c7a5f890bc057babfbf68636a1e50b9e01e6d5415983e4460','4b26b7a84d9b95861c28cf4a067760dda6fad945404111c34fc5dd54803dc3f2'),('147','2026-10-19 22:23:05','2','customer','1','data','invoice_created','invoice','16','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','4b26b7a84d9b95861c28cf4a067760dda6fad945404111c34fc5dd54803dc3f2','ec69d0a2188d0cd5c0c9b721f8db0ee7e8b9f0975b9cf57f9c95392a03056cd8'),('148','2026-10-19 22:23:05','2','customer','1','data','stock_item_autocreated','stock_item','5','{\"name\":\"Stoksuz giriş\",\"kind\":\"product\"}','127.0.0.1','ec69d0a2188d0cd5c0c9b721f8db0ee7e8b9f0975b9cf57f9c95392a03056cd8','37d3cca8053226e1eceacca1fc4e4b903794dca231e7b750639a602733746e8b'),('149','2026-10-19 22:23:05','2','customer','1','data','invoice_created','invoice','17','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":4000,\"due_date\":null,\"new_items\":1}','127.0.0.1','37d3cca8053226e1eceacca1fc4e4b903794dca231e7b750639a602733746e8b','9007efbe85b4a3d3b33ded137098281decc98db74242bb283598028fdf022dd6'),('151','2026-10-19 22:23:05','2','customer','1','data','stock_item_autocreated','stock_item','7','{\"name\":\"Idem\",\"kind\":\"product\"}','127.0.0.1','9007efbe85b4a3d3b33ded137098281decc98db74242bb283598028fdf022dd6','575977520cb7173c36d277b070aa30aaedd7f1876fe3cf74ce0800b457dc7ff6'),('152','2026-10-19 22:23:05','2','customer','1','data','invoice_created','invoice','19','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":100,\"due_date\":null,\"new_items\":1}','127.0.0.1','575977520cb7173c36d277b070aa30aaedd7f1876fe3cf74ce0800b457dc7ff6','4c6d52f2a2c9d163a18ae87b5393b3261444f6aada0790bce4bbd16f98ca3246'),('153','2026-10-19 22:23:05','2','customer','1','data','invoice_created','invoice','20','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":4500000,\"due_date\":null,\"new_items\":0}','127.0.0.1','4c6d52f2a2c9d163a18ae87b5393b3261444f6aada0790bce4bbd16f98ca3246','414f28a9b32767ea28e2c98d279ca2bc44326d300c20b9b3dbefefcbad83599b'),('154','2026-10-19 22:23:05','2','customer','1','data','invoice_cancelled','invoice','20','{\"reason\":\"müşteri vazgeçti\",\"total_minor\":4500000,\"was\":\"issued\"}','127.0.0.1','414f28a9b32767ea28e2c98d279ca2bc44326d300c20b9b3dbefefcbad83599b','69c854c0734753d8d721392c0575cf910c0c06f24f8857c5c6e39b371c51b7cb'),('155','2026-10-19 22:23:05','2','customer','1','data','stock_item_autocreated','stock_item','8','{\"name\":\"Silinecek\",\"kind\":\"product\"}','127.0.0.1','69c854c0734753d8d721392c0575cf910c0c06f24f8857c5c6e39b371c51b7cb','c759944d09fae49f7f2cf31d6a61eb06db2bcc6242474df0ebd522b339675a19'),('156','2026-10-19 22:23:05','2','customer','1','data','invoice_created','invoice','21','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":200,\"due_date\":null,\"new_items\":1}','127.0.0.1','c759944d09fae49f7f2cf31d6a61eb06db2bcc6242474df0ebd522b339675a19','a28ed30276c8733b38d41ab5640a39b73351924dad6fb29d660cc41ba2f63f53'),('157','2026-10-19 22:23:05','2','customer','1','data','invoice_deleted','invoice','21','{\"snapshot\":{\"kind\":\"purchase\",\"number\":\"T4-DEL\",\"contact_id\":2,\"issue_date\":\"2026-10-20\",\"due_date\":null,\"currency\":\"TRY\",\"status\":\"issued\",\"total_minor\":200}}','127.0.0.1','a28ed30276c8733b38d41ab5640a39b73351924dad6fb29d660cc41ba2f63f53','0458a6ce42b0e1a4120ed1b5ddf47877fd6461226151a1994141f780f92af190'),('158','2026-10-19 22:23:05','2','customer','1','data','invoice_updated','invoice','9','{\"before\":{\"total_minor\":1000000,\"due_date\":null,\"lines\":1},\"after\":{\"total_minor\":1200000,\"due_date\":null,\"lines\":1}}','127.0.0.1','0458a6ce42b0e1a4120ed1b5ddf47877fd6461226151a1994141f780f92af190','099ec8b20e1a9ec24d5cb25a66b668db0e17ae9f525f5e4901637f20dfb7969c'),('159','2026-10-19 22:23:06','2','customer','1','data','invoice_created','invoice','22','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":50000,\"due_date\":null,\"new_items\":0}','127.0.0.1','099ec8b20e1a9ec24d5cb25a66b668db0e17ae9f525f5e4901637f20dfb7969c','c72c1ee462eb2af690f0a18fca6419d4face33a8e64c9f026d64e9515f9269f0'),('160','2026-10-19 22:23:06','2','customer','1','data','collection_created','transaction','33','{\"amount_minor\":50000,\"contact_id\":1,\"allocations\":{\"29\":50000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','c72c1ee462eb2af690f0a18fca6419d4face33a8e64c9f026d64e9515f9269f0','e01a765c128cc651e033c640d3ec53b9997bb0f9107796a0cd56c8a510789f5a'),('161','2026-10-19 22:23:06','2','customer','1','data','invoice_created','invoice','23','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":30000,\"due_date\":null,\"new_items\":0}','127.0.0.1','e01a765c128cc651e033c640d3ec53b9997bb0f9107796a0cd56c8a510789f5a','60575e723c046e40db6ddea43db79cae2d0cf5461d785fa270b5586e09b22158'),('162','2026-10-19 22:23:06','2','customer','1','data','invoice_delivery','invoice','22','{\"lines\":1,\"date\":\"2026-10-20\"}','127.0.0.1','60575e723c046e40db6ddea43db79cae2d0cf5461d785fa270b5586e09b22158','72a6463129f9d1c00a65c036d160d8505834db4d6e36e1139031e79411a92d21'),('163','2026-10-19 22:23:06','2','customer','1','data','invoice_created','invoice','24','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":2000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','72a6463129f9d1c00a65c036d160d8505834db4d6e36e1139031e79411a92d21','9cafda303217c3c803267a8bbcc028e491c3011368de9b3db69e111eb1eefb75'),('164','2026-10-19 22:23:06','2','customer','1','data','payment_created','transaction','34','{\"amount_minor\":2000000,\"contact_id\":2,\"allocations\":{\"31\":2000000},\"unallocated_minor\":0,\"for_workspace_id\":1}','127.0.0.1','9cafda303217c3c803267a8bbcc028e491c3011368de9b3db69e111eb1eefb75','5be4690d3a61a22a7ba2a907a7076f46469aa8c821e590a4c9b4c2a1985585d1'),('165','2026-10-19 22:23:06','2','customer','1','data','transaction_meta_updated','transaction','34','{\"before\":{\"description\":\"Şahsi hesaptan ödendi, dekont sonra eklenecek\",\"reason\":\"ABC müşterisi siparişi malzeme alımı\"},\"after\":{\"description\":\"dekont eklendi\",\"reason\":\"Güncel neden\"}}','127.0.0.1','5be4690d3a61a22a7ba2a907a7076f46469aa8c821e590a4c9b4c2a1985585d1','c24de90aac83c9f66c8fee78b4220ffdd745b33b0a32f8e15d637efb36ca40f1'),('166','2026-10-19 22:23:07','2','customer','1','data','transfer_created','transfer','e6c060bba463fa0421f9296b3b','{\"from\":5,\"to\":1,\"amount_minor\":700000,\"kind\":\"owner_in\"}','127.0.0.1','c24de90aac83c9f66c8fee78b4220ffdd745b33b0a32f8e15d637efb36ca40f1','5e9635f42e0c863df1af0abc1fca57c243da09a5b9e4ba72669412c79abcc93c'),('167','2026-10-19 22:23:07','2','customer','1','data','transfer_created','transfer','123630423ae1e1d446e588a76f','{\"from\":1,\"to\":5,\"amount_minor\":2700000,\"kind\":\"owner_out\"}','127.0.0.1','5e9635f42e0c863df1af0abc1fca57c243da09a5b9e4ba72669412c79abcc93c','1d732820ee398fb438e9382bb48c77f3c474d46866e67cac49b5b7a6ef6486e8'),('168','2026-10-19 22:23:07','2','customer','1','data','transfer_created','transfer','d4bea0e83fc8af8e5a8944ff4d','{\"from\":1,\"to\":2,\"amount_minor\":1000,\"kind\":\"transfer\"}','127.0.0.1','1d732820ee398fb438e9382bb48c77f3c474d46866e67cac49b5b7a6ef6486e8','a168b7e11510663ada8a1242053572a8bd451d07de1e46b0925fd1bfcd6a87e8'),('169','2026-10-19 22:23:07','2','customer','1','data','account_created','account','8','{\"opening_minor\":0}','127.0.0.1','a168b7e11510663ada8a1242053572a8bd451d07de1e46b0925fd1bfcd6a87e8','a4374b5f76c1fd7fcbdaad93627b5d25ba879824f3d64d88c41c6c390e8f9e6c'),('170','2026-10-19 22:23:07','2','customer','1','data','account_updated','account','8','{\"before\":{\"name\":\"Yanlış Kasa\",\"kind\":\"cash\",\"currency\":\"TRY\"},\"after\":{\"name\":\"Yanlış Kasa 2\",\"kind\":\"bank\",\"currency\":\"EUR\"}}','127.0.0.1','a4374b5f76c1fd7fcbdaad93627b5d25ba879824f3d64d88c41c6c390e8f9e6c','8833a62094ab94a999e4943fbfcb359678da54860868d898fe9ada11aeb1b51d'),('171','2026-10-19 22:23:07','2','customer','1','data','account_deleted','account','8','{\"name\":\"Yanlış Kasa 2\",\"opening_minor\":0}','127.0.0.1','8833a62094ab94a999e4943fbfcb359678da54860868d898fe9ada11aeb1b51d','ac39b6a6dcd713d77f842a71aa4b7e562e22383aa6ec7808c57b10a718b41826'),('172','2026-10-19 22:23:07','2','customer','1','data','contact_created','contact','3',NULL,'127.0.0.1','ac39b6a6dcd713d77f842a71aa4b7e562e22383aa6ec7808c57b10a718b41826','dd76311f3f40c98ed3608bb4326c6e293d56f2627e77609a58b4fbc69963be17'),('173','2026-10-19 22:23:07','2','customer','1','data','contacts_deleted','contacts','3','{\"name\":\"Silinecek Cari\"}','127.0.0.1','dd76311f3f40c98ed3608bb4326c6e293d56f2627e77609a58b4fbc69963be17','03678183b94dea2601be21c94cf778425b046f29335436e6f709853f20b0e8ff'),('174','2026-10-19 22:23:07','2','customer','1','data','categories_deleted','categories','35','{\"name\":\"Silinecek Kat\"}','127.0.0.1','03678183b94dea2601be21c94cf778425b046f29335436e6f709853f20b0e8ff','78ef6319195519d6594d246e987dedc5a1ebd03c1e63b2d32d69baf1e7407760'),('175','2026-10-19 22:23:07','2','customer','1','data','project_created','project','2',NULL,'127.0.0.1','78ef6319195519d6594d246e987dedc5a1ebd03c1e63b2d32d69baf1e7407760','caba23b2a3611721995e76eaf4c5fa437455660ca17ad1615ec4da5d1b9983ac'),('176','2026-10-19 22:23:07','2','customer','1','data','projects_deleted','projects','2','{\"name\":\"Silinecek Proje\"}','127.0.0.1','caba23b2a3611721995e76eaf4c5fa437455660ca17ad1615ec4da5d1b9983ac','35c2fb56ef2e955602628a229921d4bee37d83a8da2f22f5e9c34de505201289'),('177','2026-10-19 22:23:07','2','customer','1','data','stock_items_deleted','stock_items','10','{\"name\":\"Boş Kart\"}','127.0.0.1','35c2fb56ef2e955602628a229921d4bee37d83a8da2f22f5e9c34de505201289','ba1387d9bec88f0225c914d33f4585cdfdad507024a65afbed898992ef45428a'),('178','2026-10-19 22:23:07','2','customer','1','data','warehouses_deleted','warehouses','2','{\"name\":\"Boş Depo\"}','127.0.0.1','ba1387d9bec88f0225c914d33f4585cdfdad507024a65afbed898992ef45428a','9bf9a662ce8e2b54729fdf69405b0987540c5764ba778b2ab770b64d65a59ddc'),('179','2026-10-19 22:23:07','2','customer','1','data','entry_created','entry','32','{\"kind\":\"payable\",\"amount_minor\":80000,\"installments\":1}','127.0.0.1','9bf9a662ce8e2b54729fdf69405b0987540c5764ba778b2ab770b64d65a59ddc','ab1c5e4143e62daf507891c605634fd25cb86bce7a65f2a917c1ec276068b8cf'),('180','2026-10-19 22:23:07','2','customer','1','data','entry_rescheduled','entry','32','{\"before\":{\"title\":\"Elektrik\",\"provider\":\"Enerjisa\",\"period\":null,\"amount_minor\":80000,\"due_date\":\"2026-10-25\"},\"after\":{\"title\":\"Elektrik (düzeltildi)\",\"provider\":\"Başka\",\"period\":\"2026-10\",\"due_date\":null,\"amount_minor\":85000}}','127.0.0.1','ab1c5e4143e62daf507891c605634fd25cb86bce7a65f2a917c1ec276068b8cf','cb30cb38d1ffa845d040dfd955c326f85b4241e1f625272e8287a627be51f329'),('181','2026-10-19 22:23:07','2','customer','1','data','entry_deleted','entry','32','{\"snapshot\":{\"workspace_id\":2,\"kind\":\"payable\",\"source\":\"personal_bill\",\"contact_id\":null,\"title\":\"Elektrik (düzeltildi)\",\"currency\":\"TRY\",\"amount_minor\":85000,\"due_date\":null}}','127.0.0.1','cb30cb38d1ffa845d040dfd955c326f85b4241e1f625272e8287a627be51f329','7adeb285cb50c4d83e733552f3551ee16809132b74042cda9830f43158467417'),('182','2026-10-19 22:23:07','2','customer','1','data','entry_created','entry','33','{\"kind\":\"payable\",\"amount_minor\":10000,\"installments\":1}','127.0.0.1','7adeb285cb50c4d83e733552f3551ee16809132b74042cda9830f43158467417','f82c50c6d9d38c6abdc3202f0df650a4f76636423ea267dc2a112dee8644ca83'),('183','2026-10-19 22:23:08','2','customer','1','data','payment_created','transaction','41','{\"amount_minor\":4000,\"contact_id\":null,\"allocations\":{\"33\":4000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','f82c50c6d9d38c6abdc3202f0df650a4f76636423ea267dc2a112dee8644ca83','fbe651d08dd4231685191410080a180cbe208da9dac0a71afaa4b275320bee5e'),('184','2026-10-19 22:23:08','2','customer','1','data','document_uploaded','invoice','9','{\"doc\":2,\"size\":70}','127.0.0.1','fbe651d08dd4231685191410080a180cbe208da9dac0a71afaa4b275320bee5e','13303f0897bdc852a2d1c2952f62985610690c72be1d06ffa6fb87198f119604'),('185','2026-10-19 22:23:08','2','customer','1','data','document_deleted','document','2',NULL,'127.0.0.1','13303f0897bdc852a2d1c2952f62985610690c72be1d06ffa6fb87198f119604','d2a9978c89f490b08c940415b7b72645a6b99714ffe79ab3effc99ebce1f6857'),('186','2026-10-19 22:23:08','2','customer','1','data','document_uploaded','transaction','34','{\"doc\":3,\"size\":70}','127.0.0.1','d2a9978c89f490b08c940415b7b72645a6b99714ffe79ab3effc99ebce1f6857','4d20d27e86b0bfc8e45f582459172ea8d615117f3d6ceb8c59e1eea655330a40'),('187','2026-10-19 22:23:08','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','4d20d27e86b0bfc8e45f582459172ea8d615117f3d6ceb8c59e1eea655330a40','4ff3a3f32094c487e1fbfe3cc1514ea8f6df38bb57e25a4a878b1f75f553d17c'),('188','2026-10-19 22:23:08','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','4ff3a3f32094c487e1fbfe3cc1514ea8f6df38bb57e25a4a878b1f75f553d17c','ba375de86434cc70db77f26f961fe4f165fc37cb2d64bd7fc757d8caf877f83d'),('189','2026-10-19 22:23:09','2','customer','1','data','contact_created','contact','4',NULL,'127.0.0.1','ba375de86434cc70db77f26f961fe4f165fc37cb2d64bd7fc757d8caf877f83d','b76a04180ef2d9fbb3779b832bb0ff77349ff69e8d5757a69c399a78fb29090d'),('190','2026-10-19 22:23:09','2','customer','1','data','invoice_created','invoice','25','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":10000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','b76a04180ef2d9fbb3779b832bb0ff77349ff69e8d5757a69c399a78fb29090d','013f365a38841c33f1fd169be2d56cca4a529dfa4a1a8ac8c3b2c5816eed3c5f'),('191','2026-10-19 22:23:09','2','customer','1','data','collection_created','transaction','42','{\"amount_minor\":3000000,\"contact_id\":4,\"allocations\":{\"34\":3000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','013f365a38841c33f1fd169be2d56cca4a529dfa4a1a8ac8c3b2c5816eed3c5f','2e20821461e1a85d9722784a4da1968fdb6519e8e03ea9886aa73ef24ae00d2b'),('192','2026-10-19 22:23:09','2','customer','1','data','contact_created','contact','5',NULL,'127.0.0.1','2e20821461e1a85d9722784a4da1968fdb6519e8e03ea9886aa73ef24ae00d2b','1410ee3a48e4ec7f1a39b4e6313c4560801fec70c192388dc91514feb790c1d3'),('193','2026-10-19 22:23:09','2','customer','1','data','collection_created','transaction','43','{\"amount_minor\":3000000,\"contact_id\":5,\"allocations\":[],\"unallocated_minor\":3000000,\"for_workspace_id\":null}','127.0.0.1','1410ee3a48e4ec7f1a39b4e6313c4560801fec70c192388dc91514feb790c1d3','dff5f1992314a59398d8f85e3c360c8e3acff1bd13e30a8d046f9028726fa68a'),('194','2026-10-19 22:23:09','2','customer','1','data','transaction_created','transaction','44','{\"kind\":\"income\",\"amount_minor\":7700,\"replaces\":null}','127.0.0.1','dff5f1992314a59398d8f85e3c360c8e3acff1bd13e30a8d046f9028726fa68a','f00e9d0b8cd84b87dc7e71e0675ef550553fee5728f7777486a11a354dd0916b'),('195','2026-10-19 22:23:09','2','customer','1','data','transaction_voided','transaction','44','{\"reason\":\"test\",\"before\":{\"kind\":\"income\",\"amount_minor\":7700,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[44]}','127.0.0.1','f00e9d0b8cd84b87dc7e71e0675ef550553fee5728f7777486a11a354dd0916b','78a84a63018a25c15057126479bad0dc85a74cbc45c061a6025aefcfcb8ee4b7'),('196','2026-10-19 22:23:09','2','customer','1','data','transaction_created','transaction','45','{\"kind\":\"income\",\"amount_minor\":50000,\"replaces\":null}','127.0.0.1','78a84a63018a25c15057126479bad0dc85a74cbc45c061a6025aefcfcb8ee4b7','46b2832304c14601d6677d991e8996b99187f4b2193c210298f791f396d29174'),('197','2026-10-19 22:23:09','2','customer','1','data','income_converted_to_collection','transaction','45','{\"amount_minor\":50000,\"contact_id\":5,\"was_vat_minor\":0}','127.0.0.1','46b2832304c14601d6677d991e8996b99187f4b2193c210298f791f396d29174','dcf961879521681c57cc94309dc4a12c7994c014929b569a1d573c27833fbcd2'),('198','2026-10-19 22:23:09','2','customer','1','data','transaction_voided','transaction','45','{\"reason\":\"test temizliği\",\"before\":{\"kind\":\"collection\",\"amount_minor\":50000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[45]}','127.0.0.1','dcf961879521681c57cc94309dc4a12c7994c014929b569a1d573c27833fbcd2','011fdd45e2496aeaca3e80f740a04a263847ba365da1a9f8dbcc0d99cf20abb5'),('199','2026-10-19 22:23:09','2','customer','1','data','invoice_created','invoice','26','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":10000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','011fdd45e2496aeaca3e80f740a04a263847ba365da1a9f8dbcc0d99cf20abb5','df7c19c75ca953ca8458fd1849f50b7a4827cd4de7fe5288827c8d4ff3bd15d2'),('200','2026-10-19 22:23:09','2','customer','1','data','payment_allocated','transaction','43','{\"new_minor\":3000000,\"allocated_minor\":3000000,\"unallocated_minor\":0}','127.0.0.1','df7c19c75ca953ca8458fd1849f50b7a4827cd4de7fe5288827c8d4ff3bd15d2','8245aaa8124b83ff6702023affade4f801044221824d2486195520039db1db77'),('201','2026-10-19 22:23:09','2','customer','1','data','entry_updated','entry','35','{\"before\":{\"planned_date\":null},\"after\":{\"planned_date\":\"2026-10-18\"}}','127.0.0.1','8245aaa8124b83ff6702023affade4f801044221824d2486195520039db1db77','f209162e0fdad75b61581e1deb717da4ec9e3959291d174792e51da37148c4c9');
/*FBEND*/
INSERT INTO `audit_log` VALUES ('202','2026-10-19 22:23:10','2','customer','1','data','entry_updated','entry','35','{\"before\":{\"planned_date\":\"2026-10-18\"},\"after\":{\"planned_date\":\"2026-10-20\"}}','127.0.0.1','f209162e0fdad75b61581e1deb717da4ec9e3959291d174792e51da37148c4c9','865d5b34acb49945350515d9c04be22470861b692c009ccffce68b2f34364400'),('203','2026-10-19 22:23:10','2','customer','1','data','collection_created','transaction','46','{\"amount_minor\":7000000,\"contact_id\":5,\"allocations\":{\"35\":7000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','865d5b34acb49945350515d9c04be22470861b692c009ccffce68b2f34364400','558519126e9c63fa42a7abc4515388d8b37eba167a48fe223f15fdbdd789273a'),('204','2026-10-19 22:23:10','2','customer','1','data','invoice_created','invoice','27','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":100000,\"due_date\":\"2026-10-25\",\"new_items\":0}','127.0.0.1','558519126e9c63fa42a7abc4515388d8b37eba167a48fe223f15fdbdd789273a','47fbc1701bedb900459a94976e14a20ccbfc1df270e8ad99368201595c62ce38'),('205','2026-10-19 22:23:10','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','47fbc1701bedb900459a94976e14a20ccbfc1df270e8ad99368201595c62ce38','4ab9183c1dc95f57f205b3f459fdb1d3af22ceb7759e685a28f158dba1f94953'),('206','2026-10-19 22:23:31','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','4ab9183c1dc95f57f205b3f459fdb1d3af22ceb7759e685a28f158dba1f94953','baba7c0e04b38cb59c8f9724ce107c16d2e38cdffc2daf8ee448115bfb11df72'),('207','2026-10-19 22:23:32','2','customer','1','data','contact_created','contact','6',NULL,'127.0.0.1','baba7c0e04b38cb59c8f9724ce107c16d2e38cdffc2daf8ee448115bfb11df72','8c0e26950417f117654c23b88b803be011c8b1bf463bf53c8eaebac15095262b'),('208','2026-10-19 22:23:32','2','customer','1','data','document_uploaded','transaction','46','{\"doc\":4,\"size\":70}','127.0.0.1','8c0e26950417f117654c23b88b803be011c8b1bf463bf53c8eaebac15095262b','1717cd2efe8d51e64efbba2257f85743f61b97732107d86334615651fb8c1465');
/*FBEND*/
DROP TABLE IF EXISTS `budgets`;
/*FBEND*/
CREATE TABLE `budgets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `month` char(7) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `amount_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_bud` (`tenant_id`,`category_id`,`month`,`currency`),
  CONSTRAINT `fk_bu_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `budgets` VALUES ('1','1','9','2026-10','TRY','200000');
/*FBEND*/
DROP TABLE IF EXISTS `captchas`;
/*FBEND*/
CREATE TABLE `captchas` (
  `id` char(32) NOT NULL,
  `answer_hash` char(64) NOT NULL,
  `pow_seed` char(32) NOT NULL,
  `pow_bits` tinyint(4) NOT NULL,
  `ip_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_captcha_exp` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `captchas` VALUES ('20a005a79d8eb0e63f24479627ea9b50','f645b9be7e09d3b8f253a43e5a6f25f5109a7b1eda41d0c1bd2edc30be347a62','f47d3460254627f1','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:26:01','2026-10-19 22:23:01'),('2416678a37360588ee6b17f496a7a5c0','b1d73b47f4714dcc37570e9ae9db5e0d08b91c21876fcd25694a49cd3856fef5','95b8a274a724a54d','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:30',NULL),('2fe51a4d7341b712f8c46e9e9b0ffb57','56531b590773ace5a2b87237abf2bd8f25ccb8ddcf4befde75940521ca1fcc5b','33972757fbcc6967','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:31','2026-10-19 22:22:31'),('3bedbc47d3c154098ffe670a1820ff85','eafbe9482751fbc215c4e693e65f0963bd4506c025d5bf131d59051b2be80aee','c0bf2d30bf1b0ad7','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:26:10','2026-10-19 22:23:10'),('4bda80118c2652ff54d6bd4e9817e02c','066be5248dca2d92c468e944e2b816a82ada994d1c40b2bd45cd7914880051ab','bdd4a8347681e6b5','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:24:02','2026-10-19 22:21:02'),('51f0be66f30f887681aff451c2566d60','aa8566a7c61db149d8bb487c9830483b0b1989999a4715a0d0c99662ae774ac4','7274b8ffb997643e','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:39','2026-10-19 22:22:39'),('52bf27ec5201767c99a41c070e44f066','1ee1c09ccc81dba2ac370b9c0dbac2dd51180a762f66dff58672aa94956c1d2f','e84574e4f422ded8','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:30','2026-10-19 22:22:30'),('5b1c956bb946e13870784e3469bec347','c679512f28b770ed7473b81f7ccf5e4a4035eff3dbf4c7e0472c930dfc14a794','cf259932564c72b1','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:23:16','2026-10-19 22:20:16'),('5b990bb4d29691e41676694215e7db6e','d4b853567a8ad48e721172a6b040b0d8db1699b14363b4bc837b5072e1d7a53f','da69dd24af1fd72d','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:32','2026-10-19 22:22:32'),('5d1689836d3eec1217ac7954ae9d9f6c','d3d9868b48f612f98ab78af252375e2de77bbeeb45cc28e6f6ac7c337a1f9881','dffbb25aa1ceec69','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:31','2026-10-19 22:22:31'),('6063ff63d6bfc743b1c2ab30828665cb','f4b114bb7b3d833e2b5caac874a01ef0a01c6b0ba75c6d92009a52e5984c4e85','d9393a6c1b7df3a6','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:31','2026-10-19 22:22:31'),('640991c572b5c7ee3c5c2f8fb857578e','ec2dbc32cb20e01bd84cabad8fda70ae40a777254709cd2f77ccfb219f7dabef','7827de1dd32404a4','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:33','2026-10-19 22:22:33'),('67b7f4705f5a8387af316266b6ce7624','21a1501b8bb45ad60a5a332faa4325486e0167d7e0a9ffe81a3fd55c5e5285ca','bd4b3c21fa96f49b','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:23:32','2026-10-19 22:20:32'),('693f6e86791509a0e4fa3b8eac969cfb','7db1c0d47ad34e3b36cf761180aeb2916175a9b1694b305f0b16d7c2c1669b14','036858f1c2df7bec','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:30','2026-10-19 22:22:30'),('6eee4bc70533e97c864a8e811fc1071b','233a25800f5874e95afb9a5c4dad114dbe97157b0ed8a025eace7e45e9c640df','f443815842252d2b','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:31','2026-10-19 22:22:31'),('84d58791a4371baa11d38950a8dbd59c','4e8fe100f80d5b4c10d71e683b7bb8637ba6bba52fced319313fcf859d756304','77a11c7ac918d9af','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:23:16','2026-10-19 22:20:16'),('8ae348a1dc602463865653ca9b6be65e','5d50e4947a4f447b33846bec0cb4caee95827637777ac6375ba3dc906a5d07ea','2ff7425b58e04a4e','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:26:10','2026-10-19 22:23:10'),('8c0fb8839e692500a61b2d4c1eb26161','ceb67f69e8b65e7a3be2905cd927fb8d11d581184ec78954d9b2227839d3368d','6091dca33fc19d8d','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:32','2026-10-19 22:22:32'),('8d56bb94cd0b8dee7eaf03b37c929872','89c9ba49d4e77ff62c0e65e90ee9a418a2447c8ecab7b6366bafb27c24e80bf7','a7dccd4edf6c457c','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:32','2026-10-19 22:22:32'),('8dc34205ae228ef3a3a2b8407a937b3e','1fb5100f5281e4f99d917ad0e3e37c4a7f267446929e6ca9d88a08ef33938ad7','1ddfe4823cd34d00','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:32','2026-10-19 22:22:32'),('8f62fba073c368f3f64e2d71847fde86','85baac9be66337bffef001eafcd8874923f86d1441b2d04071db211d6835b8a9','9b26f98a36c0b103','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:24:32','2026-10-19 22:21:32'),('90b33087409e00643f6f265c335578e5','9e69f2cefcfd18c6f3524eee985d91b5b96ab20739c849b5178e15b726571a8c','ad3520c4772a31cd','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:26:01','2026-10-19 22:23:01'),('919941f1094f9a6e03da2e1b2514f1f8','bbe94bc2507bc7870581ce2361fe1617a52866778120508a00e0fccdc2d22152','dec8c818b04362b3','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:31','2026-10-19 22:22:31'),('93b17c07c426a720d50e014ecfae3c09','8b0d7561a5190e5f1fb1b7267df2a96ed4f3087897bdd410147dbb32c4adebc6','08649e1909490517','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:33','2026-10-19 22:22:33'),('94103ff88133122131c98592edcaf493','dbe451e2ce8b2404c39c45e2796cb180af52fb881ac4ffad9d944d0ffb9ed7ab','4da003a7f95e96fd','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:24:02',NULL),('9a2e5d0be9402e164708881dc4cab106','cca48802ec4b3762169c919423638df3b15bc32143c62803633f948a5ab2afd1','531888652ae9ce8f','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:31','2026-10-19 22:22:31'),('9adece25cfbd04406d66ce3222914941','73f5c229a77e8223dd2e2fc9367d3b242d47d9e255c563cb8bca0a27bb57a21a','d51212303ff56f18','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:32','2026-10-19 22:22:32'),('b3c1d8b101f27f10f92f668b32feb877','e0e66244cdd57c4d3afe6ee45df915bc612e14b4aed7d1b17633e4d525e53e55','ee2f1480e5eb1f04','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:02','2026-10-19 22:22:03'),('bbe33cdb716212da53803ce3b4fddd60','0a19cbbbf4cad526a0621ce3e8fdfdeee3130d83158970fce51fc4a95f63d3ae','078491f714196285','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:26:08','2026-10-19 22:23:08'),('bee4512aaf4c20f226531c3dddaf3b7e','bf276a6e18702b9eaa33b8c706e7dff30cf230544ecd9fe794eca092a55520a0','bceb0281a53678cd','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:32','2026-10-19 22:22:32'),('c32bd38a2aa207fd3bbd373b776d1f5c','c282370d80682195ee0c8579a83a731d0e4548b2dcaf5dde1144a798c3a2d46a','509e7cd3e7f79ea7','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:23:16','2026-10-19 22:20:16'),('cfa35d10a13e65331d01c91856546c31','38ae313183a9e008519498351b43aad0d9dacebca9de73ac29a1b2ea327b34ae','7db068ccf54bf96b','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:24:02','2026-10-19 22:21:02'),('d13fc446f5f4d6fc5fd9e63041c5aa25','cb73a1baa1cc30c8af705327a2fc6968bbf456ead724ceb3e16c0ea2e33e2650','f1dc3368d992884e','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:32','2026-10-19 22:22:32'),('d708c9ebdfba158007da1bfc29be1ce8','b7b110da127888e0872e8cb06e5fd5a6ff35217ebf32736606ed2148f9d38b68','91f496daf3087bf6','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:32','2026-10-19 22:22:32'),('ddf1f2aa58d633b00e6925c804d45cb8','18c69ee88c5c6d774a80e73b8d577e629e03928ec6ade24ddf85cc1a9f6f660a','a72e91bbf909e4a4','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:26:08','2026-10-19 22:23:08'),('e717ccf5cad954cd651c4c96440efec8','8bf46fa2b619189e634c2f75fae55a16c08119cb4a6b8a52a04439556d5a7db3','90a49b850936b7b8','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:33','2026-10-19 22:22:33'),('eafd14a8756f16bd24ac1169dd71730a','ed69dda2e2a6261261a8871b2422790ed2eacfd855d5332e758f3df820aabd55','eb8a31cdc739d142','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:23:19','2026-10-19 22:20:19'),('ed53a0512a0e252b38bbc04997a93bc4','7c6862b4afbb21d30832b310615e163731c8ae15c3242d1faa60b293bba373e4','db227dc6e82427fb','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:30','2026-10-19 22:22:30'),('fda71cccde050a45429a12968c0f548f','8d36457ed93cd78a5bdcfe97a482e71993edd47db7d74776839204ee40642e5a','144f4d0364065906','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:30','2026-10-19 22:22:30'),('ffa77c3b14c51e6cd109d4277647fbe4','c025a0f6ab6c91bb20c2af1695b2c5670b383ec80df140d45a8f14e8a7bfabda','eb99fb3ac0364527','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:25:33','2026-10-19 22:22:33');
/*FBEND*/
DROP TABLE IF EXISTS `card_installments`;
/*FBEND*/
CREATE TABLE `card_installments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `card_id` bigint(20) unsigned NOT NULL,
  `purchase_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ci_t` (`tenant_id`,`card_id`,`due_date`),
  KEY `fk_ci_p` (`purchase_id`),
  CONSTRAINT `fk_ci_p` FOREIGN KEY (`purchase_id`) REFERENCES `card_purchases` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `card_installments` VALUES ('1','1','1','1','1','2026-11-15','40000'),('2','1','1','1','2','2026-12-15','40000'),('3','1','1','1','3','2027-01-15','40000');
/*FBEND*/
DROP TABLE IF EXISTS `card_purchases`;
/*FBEND*/
CREATE TABLE `card_purchases` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `card_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `txn_date` date NOT NULL,
  `description` varchar(250) NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `installments` int(11) NOT NULL DEFAULT 1,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_cp_t` (`tenant_id`,`card_id`),
  CONSTRAINT `fk_cp_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `card_purchases` VALUES ('1','1','1','1','2026-10-20','Ofis malzemesi','120000','2000','20000','3','9',NULL,NULL,'posted','2026-10-19 22:22:35');
/*FBEND*/
DROP TABLE IF EXISTS `cards`;
/*FBEND*/
CREATE TABLE `cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `limit_minor` bigint(20) NOT NULL DEFAULT 0,
  `statement_day` tinyint(4) NOT NULL DEFAULT 1,
  `due_day` tinyint(4) NOT NULL DEFAULT 10,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cd_t` (`tenant_id`),
  CONSTRAINT `fk_cd_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `cards` VALUES ('1','1','1','Kurumsal Kart',NULL,'TRY','5000000','5','15','0','2026-10-19 22:22:35');
/*FBEND*/
DROP TABLE IF EXISTS `categories`;
/*FBEND*/
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('income','expense') NOT NULL,
  `name` varchar(100) NOT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_cat` (`tenant_id`,`kind`,`name`),
  CONSTRAINT `fk_cat_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `categories` VALUES ('1','1','income','Satış Geliri','0'),('2','1','income','Hizmet Geliri','0'),('3','1','income','Kira Geliri','0'),('4','1','income','Faiz Geliri','0'),('5','1','income','Diğer Gelirler','0'),('6','1','expense','Yakıt','0'),('7','1','expense','Ulaşım','0'),('8','1','expense','Yemek','0'),('9','1','expense','Malzeme','0'),('10','1','expense','İşçilik','0'),('11','1','expense','Taşeron','0'),('12','1','expense','Kira','0'),('13','1','expense','Abonelik','0'),('14','1','expense','Banka Masrafı','0'),('15','1','expense','Vergi','0'),('16','1','expense','Sigorta','0'),('17','1','expense','Diğer Giderler','0'),('18','2','income','Satış Geliri','0'),('19','2','income','Hizmet Geliri','0'),('20','2','income','Kira Geliri','0'),('21','2','income','Faiz Geliri','0'),('22','2','income','Diğer Gelirler','0'),('23','2','expense','Yakıt','0'),('24','2','expense','Ulaşım','0'),('25','2','expense','Yemek','0'),('26','2','expense','Malzeme','0'),('27','2','expense','İşçilik','0'),('28','2','expense','Taşeron','0'),('29','2','expense','Kira','0'),('30','2','expense','Abonelik','0'),('31','2','expense','Banka Masrafı','0'),('32','2','expense','Vergi','0'),('33','2','expense','Sigorta','0'),('34','2','expense','Diğer Giderler','0');
/*FBEND*/
DROP TABLE IF EXISTS `contacts`;
/*FBEND*/
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('customer','supplier','both') NOT NULL DEFAULT 'customer',
  `name` varchar(200) NOT NULL,
  `tax_no` varchar(30) DEFAULT NULL,
  `tax_office` varchar(100) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `address` varchar(400) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ct_t` (`tenant_id`),
  CONSTRAINT `fk_ct_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `contacts` VALUES ('1','1','customer','Müşteri A',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 22:22:33'),('2','1','supplier','Tedarikçi B',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 22:22:34'),('4','1','customer','Avans Müşterisi',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 22:23:09'),('5','1','customer','Avans Müşterisi 2',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 22:23:09'),('6','1','customer','<script>alert(1)</script>',NULL,NULL,NULL,NULL,NULL,'\"><img src=x onerror=alert(1)>','0','2026-10-19 22:23:32');
/*FBEND*/
DROP TABLE IF EXISTS `documents`;
/*FBEND*/
CREATE TABLE `documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `entity` varchar(30) NOT NULL,
  `entity_id` bigint(20) unsigned NOT NULL,
  `orig_name` varchar(200) NOT NULL,
  `stored_name` char(64) NOT NULL,
  `mime` varchar(100) NOT NULL,
  `size_bytes` bigint(20) NOT NULL,
  `sha256` char(64) NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_doc_ent` (`tenant_id`,`entity`,`entity_id`),
  CONSTRAINT `fk_doc_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `documents` VALUES ('1','1','transaction','18','fis.png','3d9a3f397b8fd227003bf47e3e439339136dea3ecfa7b0dfab6186e1d40ce30e','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 22:22:39',NULL),('2','1','invoice','9','fatura.png','f28943de1a124466b4735a01e157482009efe8271bb534ea742256b6a049e0e3','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 22:23:08','2026-10-19 22:23:08'),('3','1','transaction','34','dekont.png','a7fbdf19b24e5f8282e84fe027b81b9191df50a2e0e8af8abf875dbc9694a5a3','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 22:23:08',NULL),('4','1','transaction','46','fis2.png','af714461531f52d3440dd1983f56c604203d9b41a9bb975c95694ca725bf0c84','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 22:23:32',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `entries`;
/*FBEND*/
CREATE TABLE `entries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `kind` enum('receivable','payable') NOT NULL,
  `source` enum('manual','invoice','personal_bill','recurring','milestone') NOT NULL DEFAULT 'manual',
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `recurring_id` bigint(20) unsigned DEFAULT NULL,
  `group_id` varchar(26) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  `seq_total` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `provider` varchar(120) DEFAULT NULL,
  `period` varchar(20) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `amount_minor` bigint(20) NOT NULL,
  `due_date` date DEFAULT NULL,
  `original_due_date` date DEFAULT NULL,
  `priority` tinyint(4) NOT NULL DEFAULT 2,
  `affects_pl` tinyint(4) NOT NULL DEFAULT 0,
  `status` enum('open','cancelled') NOT NULL DEFAULT 'open',
  `note` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `invoice_key` varchar(40) DEFAULT NULL,
  `planned_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_entry_invoice` (`tenant_id`,`invoice_key`),
  UNIQUE KEY `ux_entry_recur` (`tenant_id`,`recurring_id`,`due_date`),
  KEY `ix_en_t` (`tenant_id`,`status`,`due_date`),
  KEY `ix_en_planned` (`tenant_id`,`status`,`planned_date`),
  CONSTRAINT `fk_en_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `entries` VALUES ('1','1','1','receivable','manual','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Büyük satış',NULL,NULL,'TRY','10000000','2026-10-30','2026-10-30','2','0','open',NULL,'2026-10-19 22:22:34',NULL,NULL,NULL),('2','1','1','payable','manual','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Plan: kira',NULL,NULL,'TRY','500000','2026-11-09','2026-11-09','2','1','open',NULL,'2026-10-19 22:22:34',NULL,NULL,NULL),('3','1','1','payable','recurring',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'Aylık abonelik',NULL,NULL,'TRY','30000','2026-10-23','2026-10-23','2','1','open',NULL,'2026-10-19 22:22:34',NULL,NULL,NULL),('4','1','1','payable','recurring',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'Aylık abonelik',NULL,NULL,'TRY','30000','2026-11-23','2026-11-23','2','1','open',NULL,'2026-10-19 22:22:34',NULL,NULL,NULL),('5','1','1','receivable','invoice','1',NULL,NULL,'1',NULL,NULL,NULL,NULL,'Satış faturası FB-2026-001 — Müşteri A',NULL,NULL,'TRY','120000','2026-11-04','2026-11-04','2','0','open',NULL,'2026-10-19 22:22:34',NULL,'1',NULL),('7','1','1','receivable','manual','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'EUR alacak',NULL,NULL,'EUR','50000','2026-10-25','2026-10-25','2','0','open',NULL,'2026-10-19 22:22:35',NULL,NULL,NULL),('8','1','1','payable','manual','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tedarikçi borcu',NULL,NULL,'TRY','1000000','2026-10-30','2026-10-17','2','0','open',NULL,'2026-10-19 22:22:35',NULL,NULL,NULL),('9','1','2','payable','personal_bill',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Elektrik','Enerjisa','2026-10','TRY','80000','2026-10-20','2026-10-20','2','1','open',NULL,'2026-10-19 22:22:36',NULL,NULL,NULL),('10','1','1','receivable','invoice','1','1',NULL,'3',NULL,NULL,NULL,NULL,'Satış faturası PR-1 — Müşteri A',NULL,NULL,'TRY','1200000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:22:36',NULL,'3',NULL),('11','1','1','payable','invoice','2','1',NULL,'4',NULL,NULL,NULL,NULL,'Alış faturası ALIS-9 — Tedarikçi B',NULL,NULL,'TRY','480000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:22:36',NULL,'4',NULL),('12','1','1','receivable','milestone','1','1',NULL,NULL,NULL,NULL,NULL,NULL,'Santral Kurulumu — Hakediş 2',NULL,NULL,'TRY','2000000','2026-11-19','2026-11-19','2','1','open',NULL,'2026-10-19 22:22:37',NULL,NULL,NULL),('13','1','1','payable','invoice','2',NULL,NULL,'5',NULL,NULL,NULL,NULL,'Alış faturası STK-1 — Tedarikçi B',NULL,NULL,'TRY','120000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:22:37',NULL,'5',NULL),('14','1','1','payable','invoice','2',NULL,NULL,'6',NULL,NULL,NULL,NULL,'Alış faturası T4-1-8ad9 — Tedarikçi B',NULL,NULL,'TRY','100000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:01',NULL,'6',NULL),('15','1','1','payable','invoice','2',NULL,NULL,'7',NULL,NULL,NULL,NULL,'Alış faturası T4-2-6e7b — Tedarikçi B',NULL,NULL,'TRY','50000','2026-10-30','2026-10-27','2','0','open',NULL,'2026-10-19 22:23:01',NULL,'7',NULL),('16','1','1','payable','invoice','2',NULL,NULL,'8',NULL,NULL,NULL,NULL,'Alış faturası T4-3-45c7 — Tedarikçi B',NULL,NULL,'TRY','50000','2026-12-04','2026-12-04','2','0','open',NULL,'2026-10-19 22:23:01',NULL,'8',NULL),('17','1','1','payable','invoice','2',NULL,NULL,'9',NULL,NULL,NULL,NULL,'Alış faturası T4-5-8732 — Tedarikçi B',NULL,NULL,'TRY','1200000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:02',NULL,'9',NULL),('18','1','1','payable','invoice','2',NULL,NULL,'10',NULL,NULL,NULL,NULL,'Alış faturası T4-6-cf30 — Tedarikçi B',NULL,NULL,'TRY','1000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:02',NULL,'10',NULL),('19','1','1','payable','invoice','2',NULL,NULL,'11',NULL,NULL,NULL,NULL,'Alış faturası T4-7-b6c0 — Tedarikçi B',NULL,NULL,'TRY','1000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:02',NULL,'11',NULL),('20','1','1','payable','invoice','2',NULL,NULL,'12',NULL,NULL,NULL,NULL,'Alış faturası T4-8-0b08 — Tedarikçi B',NULL,NULL,'TRY','6000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:02',NULL,'12',NULL),('21','1','1','payable','invoice','2',NULL,NULL,'13',NULL,NULL,NULL,NULL,'Alış faturası T4-9-ff87 — Tedarikçi B',NULL,NULL,'TRY','4500000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:03',NULL,'13',NULL),('22','1','1','receivable','invoice','1',NULL,NULL,'14',NULL,NULL,NULL,NULL,'Satış faturası T4-10-db8b — Müşteri A',NULL,NULL,'TRY','500000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:03',NULL,'14',NULL),('23','1','1','payable','invoice','2',NULL,NULL,'15',NULL,NULL,NULL,NULL,'Alış faturası T4-STK-1 — Tedarikçi B',NULL,NULL,'TRY','5590000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:04',NULL,'15',NULL),('24','1','1','payable','invoice','2',NULL,NULL,'16',NULL,NULL,NULL,NULL,'Alış faturası T4-STK-2 — Tedarikçi B',NULL,NULL,'TRY','1000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:05',NULL,'16',NULL),('25','1','1','payable','invoice','2',NULL,NULL,'17',NULL,NULL,NULL,NULL,'Alış faturası T4-STK-3 — Tedarikçi B',NULL,NULL,'TRY','4000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:05',NULL,'17',NULL),('26','1','1','payable','invoice','2',NULL,NULL,'19',NULL,NULL,NULL,NULL,'Alış faturası T4-IDEM — Tedarikçi B',NULL,NULL,'TRY','100',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:05',NULL,'19',NULL),('27','1','1','receivable','invoice','1',NULL,NULL,'20',NULL,NULL,NULL,NULL,'Satış faturası T4-S-BZ — Müşteri A',NULL,NULL,'TRY','4500000',NULL,NULL,'2','0','cancelled',NULL,'2026-10-19 22:23:05','2026-10-19 22:23:05','20',NULL),('29','1','1','receivable','invoice','1',NULL,NULL,'22',NULL,NULL,NULL,NULL,'Satış faturası T4-S-NO — Müşteri A',NULL,NULL,'TRY','50000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:06',NULL,'22',NULL),('30','1','1','payable','invoice','2',NULL,NULL,'23',NULL,NULL,NULL,NULL,'Alış faturası T4-SUP-NO — Tedarikçi B',NULL,NULL,'TRY','30000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:06',NULL,'23',NULL),('31','1','1','payable','invoice','2',NULL,NULL,'24',NULL,NULL,NULL,NULL,'Alış faturası T4-11-ac23 — Tedarikçi B',NULL,NULL,'TRY','2000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:06',NULL,'24',NULL),('33','1','2','payable','personal_bill',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Su',NULL,NULL,'TRY','10000','2026-10-25','2026-10-25','2','1','open',NULL,'2026-10-19 22:23:07',NULL,NULL,NULL),('34','1','1','receivable','invoice','4',NULL,NULL,'25',NULL,NULL,NULL,NULL,'Satış faturası HOME-1 — Avans Müşterisi',NULL,NULL,'TRY','10000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:09',NULL,'25',NULL),('35','1','1','receivable','invoice','5',NULL,NULL,'26',NULL,NULL,NULL,NULL,'Satış faturası HOME-2 — Avans Müşterisi 2',NULL,NULL,'TRY','10000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:23:09',NULL,'26','2026-10-20'),('36','1','1','payable','invoice','2',NULL,NULL,'27',NULL,NULL,NULL,NULL,'Alış faturası HOME-P1 — Tedarikçi B',NULL,NULL,'TRY','100000','2026-10-25','2026-10-25','2','0','open',NULL,'2026-10-19 22:23:10',NULL,'27',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `fx_rates`;
/*FBEND*/
CREATE TABLE `fx_rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `currency` char(3) NOT NULL,
  `rate_date` date NOT NULL,
  `rate` decimal(18,8) NOT NULL,
  `source` varchar(30) NOT NULL DEFAULT 'manual',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_fx` (`tenant_id`,`currency`,`rate_date`),
  CONSTRAINT `fk_fx_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `fx_rates` VALUES ('1','1','EUR','2026-10-20','40.50000000','manual'),('2','1','USD','2026-10-20','35.25000000','manual');
/*FBEND*/
DROP TABLE IF EXISTS `idempotency_keys`;
/*FBEND*/
CREATE TABLE `idempotency_keys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `ikey` char(64) NOT NULL,
  `route` varchar(160) NOT NULL,
  `status_code` smallint(6) DEFAULT NULL,
  `response` mediumtext DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_idem` (`tenant_id`,`ikey`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `idempotency_keys` VALUES ('1','1','c1156d6092d24faa267aadb5a08a80c620ca9ef5fe89f2c413a931b441954fbc','POST /transactions','201','{\"ok\":true,\"id\":17,\"warning\":null}','2026-10-19 22:22:37'),('3','1','ed6e404f2df65cefde907ae741c7da209cd5f7740516d63439523d8d1eed35ae','POST /payments','201','{\"ok\":true,\"id\":25,\"allocated_minor\":400000,\"unallocated_minor\":0}','2026-10-19 22:23:02'),('4','1','6acb28868c90f9c81ec1d62a03c716fb5f7f12ee3250e37adb94529d46dc77cd','POST /payments','201','{\"ok\":true,\"id\":26,\"allocated_minor\":600000,\"unallocated_minor\":0}','2026-10-19 22:23:02'),('6','1','5d99e78fe66130af67501b7c08829e9857af83b942ae9332551fcf3de117d26e','POST /payments','201','{\"ok\":true,\"id\":27,\"allocated_minor\":1000000,\"unallocated_minor\":2000000}','2026-10-19 22:23:02'),('8','1','fe03ede868e5246f40e697513d2d81ae62b1a2be0027c5bf389aeac73251bb5c','POST /payments','201','{\"ok\":true,\"id\":28,\"allocated_minor\":5000000,\"unallocated_minor\":0}','2026-10-19 22:23:03'),('9','1','f056f09ef37b9246661b20b4f52a74c977c8c74dad77dc355c55a38ecb7d8bc1','POST /payments/27/allocate','200','{\"ok\":true,\"allocated_minor\":3000000,\"unallocated_minor\":0}','2026-10-19 22:23:03'),('10','1','b712ec8a084ae946f25a35c1ace92cfebae374c2566fc93ae270fd8e614ec77b','POST /payments','201','{\"ok\":true,\"id\":29,\"allocated_minor\":0,\"unallocated_minor\":10000}','2026-10-19 22:23:03'),('12','1','60188e2df2da4dda2de7b5293d227cf460fc80f5142d2e9caa637da64f82ac9e','POST /payments','201','{\"ok\":true,\"id\":30,\"allocated_minor\":0,\"unallocated_minor\":7000}','2026-10-19 22:23:03'),('14','1','fa9f67febf0a5d9785f8fad4b99e20d23b348b09dcc8c4ebf2fd797d1c0bdeba','POST /payments','201','{\"ok\":true,\"id\":31,\"allocated_minor\":0,\"unallocated_minor\":7000}','2026-10-19 22:23:03'),('15','1','b2f1e6a5d5da279ff63edd538d7b26f45379140552e480866202d3d75d269060','POST /payments','201','{\"ok\":true,\"id\":32,\"allocated_minor\":500000,\"unallocated_minor\":300000}','2026-10-19 22:23:03'),('22','1','05f7ec7ec95e30131561ea2f4086bea517a03a77fc81ea6c5ed0387e5667f2bc','POST /invoices','201','{\"ok\":true,\"id\":15,\"warnings\":[],\"new_items\":3}','2026-10-19 22:23:04'),('23','1','680898a2a465e4c7922db03f0b1e0db0f8e57474a1efef32700a8590735e0506','POST /invoices','201','{\"ok\":true,\"id\":19,\"warnings\":[],\"new_items\":1}','2026-10-19 22:23:05'),('25','1','6051952f5934733554cdd3d70ff868aa83447683aa6300448c0342e729f60b61','POST /payments','201','{\"ok\":true,\"id\":33,\"allocated_minor\":50000,\"unallocated_minor\":0}','2026-10-19 22:23:06'),('26','1','738515f0514e65b1dfce55ba2c5333b8b302d059be7f322f2b4529f3ad0124c1','POST /invoices/22/deliver','200','{\"ok\":true,\"delivery\":{\"state\":\"partial\",\"tracked_milli\":5000,\"fulfilled_milli\":2000,\"pending_milli\":3000}}','2026-10-19 22:23:06'),('28','1','21e586b18ad26b683d9c248a834b1c22f51157c64d442f3c6090c13dee33fffb','POST /payments','201','{\"ok\":true,\"id\":34,\"allocated_minor\":2000000,\"unallocated_minor\":0}','2026-10-19 22:23:06'),('29','1','93fb3b304246b5319521cc643611fc7d3ffbc81a3587ef3234459f69c56c1038','POST /transfers','201','{\"ok\":true,\"group\":\"e6c060bba463fa0421f9296b3b\",\"ids\":[35,36]}','2026-10-19 22:23:07'),('31','1','b416bfea49a8c1120446a34ca6802e6e1f4633466c83e05ab7c38680ebcafa58','POST /transfers','201','{\"ok\":true,\"group\":\"123630423ae1e1d446e588a76f\",\"ids\":[37,38]}','2026-10-19 22:23:07'),('32','1','172a5abfd8f3fb7d9376e678040d02b3c243871175b324f2ba25f0c0a2f9e1da','POST /transfers','201','{\"ok\":true,\"group\":\"d4bea0e83fc8af8e5a8944ff4d\",\"ids\":[39,40]}','2026-10-19 22:23:07'),('33','1','2c2a33e010bf7d33a4811365ae2e097e7b6b3ae8dfdf194281b30cd37e360bf7','POST /entries/33/settle','201','{\"ok\":true,\"id\":41,\"remaining_minor\":6000}','2026-10-19 22:23:08'),('37','1','4ec5ed839b995bf0bdfa8901ae552dce21b93edc156fd7e0432efa66fb250bd3','POST /payments','201','{\"ok\":true,\"id\":42,\"allocated_minor\":3000000,\"unallocated_minor\":0}','2026-10-19 22:23:09'),('38','1','b8236f30398f3b6c849bb41472e7bd1f66053eb3ef13dbe3603e394868261c71','POST /transactions','201','{\"ok\":true,\"id\":43,\"warning\":\"Tutar müşteri avansı olarak cari hesaba işlendi (gelir sayılmadı; fatura ile eşleştirebilirsiniz).\"}','2026-10-19 22:23:09'),('39','1','fd0bb2b39209263818bd105352ea65e5b729093f8d988040f47378cb3c841276','POST /transactions','201','{\"ok\":true,\"id\":44,\"warning\":null}','2026-10-19 22:23:09'),('40','1','e4a27890618a833529491b9388c043c17db754dc3c4b39f57297af7a8ca0df99','POST /transactions','201','{\"ok\":true,\"id\":45,\"warning\":null}','2026-10-19 22:23:09'),('41','1','c32c46a2af2db509eb0ab8a5f551ee052ace5996b0f564e9d188696ac6e3e3c8','POST /payments/43/allocate','200','{\"ok\":true,\"allocated_minor\":3000000,\"unallocated_minor\":0}','2026-10-19 22:23:09'),('42','1','09b2bb697a381379c22f42d82c5fce73a48aa3f1d0e2dbc78af74a80ad914639','POST /payments','201','{\"ok\":true,\"id\":46,\"allocated_minor\":7000000,\"unallocated_minor\":0}','2026-10-19 22:23:10');
/*FBEND*/
DROP TABLE IF EXISTS `invoice_lines`;
/*FBEND*/
CREATE TABLE `invoice_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `invoice_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `description` varchar(300) NOT NULL,
  `item_id` bigint(20) unsigned DEFAULT NULL,
  `warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `qty_milli` bigint(20) NOT NULL,
  `unit` varchar(20) NOT NULL DEFAULT 'adet',
  `unit_price_minor` bigint(20) NOT NULL,
  `discount_bp` int(11) NOT NULL DEFAULT 0,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `net_minor` bigint(20) NOT NULL,
  `vat_minor` bigint(20) NOT NULL,
  `total_minor` bigint(20) NOT NULL,
  `fulfilled_milli` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_il_inv` (`invoice_id`),
  CONSTRAINT `fk_il_inv` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `invoice_lines` VALUES ('1','1','1','1','Danışmanlık',NULL,NULL,'1000','adet','100000','0','2000','100000','20000','120000','0'),('2','1','3','1','Hakediş 1',NULL,NULL,'1000','adet','1000000','0','2000','1000000','200000','1200000','0'),('3','1','4','1','Malzeme',NULL,NULL,'1000','adet','400000','0','2000','400000','80000','480000','0'),('4','1','5','1','Kablo','1','1','10000','adet','10000','0','2000','100000','20000','120000','10000'),('5','1','6','1','Kalem',NULL,NULL,'1000','adet','100000','0','0','100000','0','100000','0'),('6','1','7','1','Kalem',NULL,NULL,'1000','adet','50000','0','0','50000','0','50000','0'),('7','1','8','1','Kalem',NULL,NULL,'1000','adet','50000','0','0','50000','0','50000','0'),('8','1','9','1','Kalem (düzeltilmiş)',NULL,NULL,'1000','adet','1200000','0','0','1200000','0','1200000','0'),('9','1','10','1','Kalem',NULL,NULL,'1000','adet','1000000','0','0','1000000','0','1000000','0'),('10','1','11','1','Kalem',NULL,NULL,'1000','adet','1000000','0','0','1000000','0','1000000','0'),('11','1','12','1','Kalem',NULL,NULL,'1000','adet','6000000','0','0','6000000','0','6000000','0'),('12','1','13','1','Kalem',NULL,NULL,'1000','adet','4500000','0','0','4500000','0','4500000','0'),('13','1','14','1','Kalem',NULL,NULL,'1000','adet','500000','0','0','500000','0','500000','0'),('14','1','15','1','Buzdolabı T4','2','1','3000','adet','1000000','0','2000','3000000','600000','3600000','3000'),('15','1','15','2','Televizyon T4','3','1','2000','adet','800000','0','2000','1600000','320000','1920000','2000'),('16','1','15','3','Nakliye T4','4',NULL,'1000','adet','50000','0','2000','50000','10000','60000','0'),('17','1','15','4','Serbest not satırı',NULL,NULL,'1000','adet','10000','0','0','10000','0','10000','0'),('18','1','16','1','buzdolabı t4','2','1','1000','adet','1000000','0','0','1000000','0','1000000','1000'),('19','1','17','1','Stoksuz giriş','5',NULL,'4000','adet','1000','0','0','4000','0','4000','0'),('20','1','19','1','Idem','7','1','1000','adet','100','0','0','100','0','100','1000'),('21','1','20','1','Buzdolabı satış','2','1','3000','adet','1500000','0','0','4500000','0','4500000','3000'),('23','1','22','1','Stoksuz','9','1','5000','adet','10000','0','0','50000','0','50000','2000'),('24','1','23','1','Stoksuz tedarik','9','1','5000','adet','6000','0','0','30000','0','30000','5000'),('25','1','24','1','Kalem',NULL,NULL,'1000','adet','2000000','0','0','2000000','0','2000000','0'),('26','1','25','1','İş',NULL,NULL,'1000','adet','10000000','0','0','10000000','0','10000000','0'),('27','1','26','1','İş',NULL,NULL,'1000','adet','10000000','0','0','10000000','0','10000000','0'),('28','1','27','1','Mal',NULL,NULL,'1000','adet','100000','0','0','100000','0','100000','0');
/*FBEND*/
DROP TABLE IF EXISTS `invoices`;
/*FBEND*/
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `kind` enum('sales','purchase') NOT NULL,
  `number` varchar(60) DEFAULT NULL,
  `contact_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `issue_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `status` enum('planned','issued','cancelled') NOT NULL DEFAULT 'issued',
  `subtotal_minor` bigint(20) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `total_minor` bigint(20) NOT NULL DEFAULT 0,
  `note` text DEFAULT NULL,
  `cancel_reason` varchar(300) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `dedupe_key` varchar(300) DEFAULT NULL,
  `defer_delivery` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_inv_dedupe` (`tenant_id`,`dedupe_key`),
  KEY `ix_inv_t` (`tenant_id`,`issue_date`),
  CONSTRAINT `fk_inv_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `invoices` VALUES ('1','1','1','sales','FB-2026-001','1',NULL,'2026-10-20','2026-11-04','TRY','issued','100000','20000','120000',NULL,NULL,NULL,'2','2026-10-19 22:22:34','a754d2aa8eeed97efccef5a323ae68f9e6c145b8a336eb2712976e6d4c2d2240','0'),('3','1','1','sales','PR-1','1','1','2026-10-20',NULL,'TRY','issued','1000000','200000','1200000',NULL,NULL,NULL,'2','2026-10-19 22:22:36','b8bc46e741c40ec3b74a4651c8dd1fa976d82fbcf0a1be20c7c81f4972a509ad','0'),('4','1','1','purchase','ALIS-9','2','1','2026-10-20',NULL,'TRY','issued','400000','80000','480000',NULL,NULL,NULL,'2','2026-10-19 22:22:36','7e15c3cdf198254634085553a61d00d96f61631d5e3c9d5ebf1177cfcda79456','0'),('5','1','1','purchase','STK-1','2',NULL,'2026-10-20',NULL,'TRY','issued','100000','20000','120000',NULL,NULL,NULL,'2','2026-10-19 22:22:37','f9a2c7eab1de39765fe12024afa7c15639f12f15ebebef3f0f3282fa95242c94','0'),('6','1','1','purchase','T4-1-8ad9','2',NULL,'2026-08-21',NULL,'TRY','issued','100000','0','100000',NULL,NULL,NULL,'2','2026-10-19 22:23:01','26ebd3bdcd5f782d12e50631d369e5267e1aba9b9db93c7ea3355b8dd0131bd8','0'),('7','1','1','purchase','T4-2-6e7b','2',NULL,'2026-10-20',NULL,'TRY','issued','50000','0','50000','sadece not',NULL,NULL,'2','2026-10-19 22:23:01','dc7eddf5adfbe5f6c679d597b60e9e4dcc2bf3ab3a526aae4c2f1457c7fd70ee','0'),('8','1','1','purchase','T4-3-45c7','2',NULL,'2026-10-20','2026-12-04','TRY','issued','50000','0','50000',NULL,NULL,NULL,'2','2026-10-19 22:23:01','60fece1dda013aa01b812b6d1e3d5c4e397d6b1a1f4cba3aff53b9fe502a7c3f','0'),('9','1','1','purchase','T4-5-8732','2',NULL,'2026-10-20',NULL,'TRY','issued','1200000','0','1200000',NULL,NULL,NULL,'2','2026-10-19 22:23:02','e03d18a84ef267703b0898932155dc39ddd90b8f4bda06b14c92bb8bf2786407','0'),('10','1','1','purchase','T4-6-cf30','2',NULL,'2026-10-20',NULL,'TRY','issued','1000000','0','1000000',NULL,NULL,NULL,'2','2026-10-19 22:23:02','2cea1844f81c27853c52e67e619b1fcb5eb15b7a15813fc598c5bd874ad13c2b','0'),('11','1','1','purchase','T4-7-b6c0','2',NULL,'2026-10-20',NULL,'TRY','issued','1000000','0','1000000',NULL,NULL,NULL,'2','2026-10-19 22:23:02','51cd2e9704d1cfa0d325d1ce6031d638b5a7565fae286d486d7565a169570625','0'),('12','1','1','purchase','T4-8-0b08','2',NULL,'2026-10-20',NULL,'TRY','issued','6000000','0','6000000',NULL,NULL,NULL,'2','2026-10-19 22:23:02','3d897d753388b9106f322065d344198d684348a6925cd236958badc047095b7e','0'),('13','1','1','purchase','T4-9-ff87','2',NULL,'2026-10-20',NULL,'TRY','issued','4500000','0','4500000',NULL,NULL,NULL,'2','2026-10-19 22:23:03','6f4660cee2c32cddac81494686703501ff49aaf6cd1a53bb983f7bd37fa7457c','0'),('14','1','1','sales','T4-10-db8b','1',NULL,'2026-10-20',NULL,'TRY','issued','500000','0','500000',NULL,NULL,NULL,'2','2026-10-19 22:23:03','8b380b1b61af6223c8df5e1c7262dbf94c849d394f0cadce595f5d45ad76e7f7','0'),('15','1','1','purchase','T4-STK-1','2',NULL,'2026-10-20',NULL,'TRY','issued','4660000','930000','5590000',NULL,NULL,NULL,'2','2026-10-19 22:23:04','e1ac5254b542481ebc8036b673ec23d57ec477cd765925e8a5581e79aa80aa51','0'),('16','1','1','purchase','T4-STK-2','2',NULL,'2026-10-20',NULL,'TRY','issued','1000000','0','1000000',NULL,NULL,NULL,'2','2026-10-19 22:23:05','c6744dea9981945fc0f907bffe09b2086d250fc7ef48f1c5ee7e3109e50ea926','0'),('17','1','1','purchase','T4-STK-3','2',NULL,'2026-10-20',NULL,'TRY','issued','4000','0','4000',NULL,NULL,NULL,'2','2026-10-19 22:23:05','ce05d1a80529a7c8550e2e6e342f17d7f3106eaeff60605ab0dc05c37537db37','0'),('19','1','1','purchase','T4-IDEM','2',NULL,'2026-10-20',NULL,'TRY','issued','100','0','100',NULL,NULL,NULL,'2','2026-10-19 22:23:05','a14dbf3ccf5544863fd18803b9b6543230df5f719b52e2ad5d546e37c2668f53','0'),('20','1','1','sales','T4-S-BZ','1',NULL,'2026-10-20',NULL,'TRY','cancelled','4500000','0','4500000',NULL,'müşteri vazgeçti','2026-10-19 22:23:05','2','2026-10-19 22:23:05','b846f7f8969fec18addb81f07e3380439c716b190f0c93696bced8118bbd4026','0'),('22','1','1','sales','T4-S-NO','1',NULL,'2026-10-20',NULL,'TRY','issued','50000','0','50000',NULL,NULL,NULL,'2','2026-10-19 22:23:06','bdf6d8bde42d0bde5010b566f66755e61b64925556c291ec3a003d471838c04f','0'),('23','1','1','purchase','T4-SUP-NO','2',NULL,'2026-10-20',NULL,'TRY','issued','30000','0','30000',NULL,NULL,NULL,'2','2026-10-19 22:23:06','f37b2b06e1d61b54548261d81dc7b53d8f379fc6cd554fd54ffb2a94cb67e5f1','0'),('24','1','1','purchase','T4-11-ac23','2',NULL,'2026-10-20',NULL,'TRY','issued','2000000','0','2000000',NULL,NULL,NULL,'2','2026-10-19 22:23:06','6488bef59a23e5571079de0b40111f21c791f606d9bc83f4984ef1bf68eb8991','0'),('25','1','1','sales','HOME-1','4',NULL,'2026-10-20',NULL,'TRY','issued','10000000','0','10000000',NULL,NULL,NULL,'2','2026-10-19 22:23:09','802eaa9e5dec5bf3741d41a35f84fffb8c6fbf524c2d54c7e56482152f9fb06c','0'),('26','1','1','sales','HOME-2','5',NULL,'2026-10-20',NULL,'TRY','issued','10000000','0','10000000',NULL,NULL,NULL,'2','2026-10-19 22:23:09','2db1d2e1d0f25daa74f8343e8ab5fda6a283cf10c7081cea0187863d9aaf59fb','0'),('27','1','1','purchase','HOME-P1','2',NULL,'2026-10-20','2026-10-25','TRY','issued','100000','0','100000',NULL,NULL,NULL,'2','2026-10-19 22:23:10','eecb2094c884fea81c14757a257954083fcd315a0df08288073dc5e2af4e1253','0');
/*FBEND*/
DROP TABLE IF EXISTS `loan_installments`;
/*FBEND*/
CREATE TABLE `loan_installments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `loan_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `principal_minor` bigint(20) NOT NULL,
  `interest_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_li_t` (`tenant_id`,`loan_id`),
  KEY `fk_li_l` (`loan_id`),
  CONSTRAINT `fk_li_l` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `loan_installments` VALUES ('1','1','1','1','2026-11-20','894715','240000'),('2','1','1','2','2026-12-20','912609','222106'),('3','1','1','3','2027-01-20','930861','203854'),('4','1','1','4','2027-02-20','949479','185236'),('5','1','1','5','2027-03-20','968468','166247'),('6','1','1','6','2027-04-20','987838','146877'),('7','1','1','7','2027-05-20','1007594','127121'),('8','1','1','8','2027-06-20','1027746','106969'),('9','1','1','9','2027-07-20','1048301','86414'),('10','1','1','10','2027-08-20','1069267','65448'),('11','1','1','11','2027-09-20','1090653','44062'),('12','1','1','12','2027-10-20','1112469','22249');
/*FBEND*/
DROP TABLE IF EXISTS `loans`;
/*FBEND*/
CREATE TABLE `loans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `principal_minor` bigint(20) NOT NULL,
  `monthly_rate_bp` int(11) NOT NULL DEFAULT 0,
  `term_months` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `status` enum('active','closed','cancelled') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ln_t` (`tenant_id`),
  CONSTRAINT `fk_ln_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `loans` VALUES ('1','1','1','İşletme Kredisi',NULL,'TRY','12000000','200','12','2026-10-20','active','2026-10-19 22:22:36');
/*FBEND*/
DROP TABLE IF EXISTS `login_tickets`;
/*FBEND*/
CREATE TABLE `login_tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `token_hash` char(64) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `ip` varchar(64) NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_tickets_token` (`token_hash`),
  KEY `fk_tickets_user` (`user_id`),
  CONSTRAINT `fk_tickets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `login_tickets` VALUES ('1','fb086bfcab767cca5a4252884a7e7dfc99e878d83045c3e40c2bdbab015f0f3c','1','127.0.0.1','1','2026-10-19 22:25:16',NULL),('2','8a6086bcb43e37e533a21bbb73b14e6afd025cf55d6b9c2a7381077c9404d60e','1','127.0.0.1','1','2026-10-19 22:25:16','2026-10-19 22:20:16'),('3','5132f69608e0d25a094de43ae0391dee41c617f1555fa0af4390921137830a43','1','127.0.0.1','1','2026-10-19 22:25:19','2026-10-19 22:20:32'),('4','1ab519decf9addae208bb688d4ac091c9ed61ac285f3718e718eab79cbd2a3ec','1','127.0.0.1','1','2026-10-19 22:25:32','2026-10-19 22:21:02'),('5','7f613d33cba37138dae8393e411959789376189372d57bd15e49fd0e384bf488','1','127.0.0.1','0','2026-10-19 22:26:02',NULL),('6','9db91c81b7152273c2ff0374edf175722592e7773c768461f528687604c3cee0','1','127.0.0.1','1','2026-10-19 22:26:02','2026-10-19 22:21:32'),('7','53f47823c1453126ffa4c536b43c6f7cb8122a1acca3ddaef13fcf7092ad7ef3','1','127.0.0.1','1','2026-10-19 22:26:32','2026-10-19 22:22:02'),('8','41bc2ea296530519d4140ca2da9cc466b277cf99deb1654b838145db7708af63','1','127.0.0.1','1','2026-10-19 22:27:03','2026-10-19 22:22:30'),('9','54fb709d4a58a347e60792b426a4d01820f774a1a2d7e71a583f4b3703cdd893','1','127.0.0.1','1','2026-10-19 22:27:39','2026-10-19 22:23:00'),('10','60054ea5124abc5b4eb24229c9209150bd0d49617cbea7208bb8f7db12ebb105','1','127.0.0.1','1','2026-10-19 22:28:10','2026-10-19 22:23:31');
/*FBEND*/
DROP TABLE IF EXISTS `password_tokens`;
/*FBEND*/
CREATE TABLE `password_tokens` (
  `token_hash` char(64) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `purpose` enum('reset','invite') NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`token_hash`),
  KEY `ix_pt_user` (`user_id`),
  CONSTRAINT `fk_pt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `password_tokens` VALUES ('a136b2797c0212bda19bf2d3c758bbad547675dd23744d69cfc6399072e4c843','2','invite','2026-10-22 22:22:30','2026-10-19 22:22:31','1','2026-10-19 22:22:30'),('a81b2119dceaa322227315adae18536ae804c9f49b14999e0c960c2ed6d7c557','2','reset','2026-10-19 22:52:32','2026-10-19 22:22:32',NULL,'2026-10-19 22:22:32');
/*FBEND*/
DROP TABLE IF EXISTS `payment_allocations`;
/*FBEND*/
CREATE TABLE `payment_allocations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `txn_id` bigint(20) unsigned NOT NULL,
  `entry_id` bigint(20) unsigned NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `status` enum('active','reversed') NOT NULL DEFAULT 'active',
  `note` varchar(300) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `reversed_at` datetime DEFAULT NULL,
  `reversed_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_pa_txn` (`tenant_id`,`txn_id`,`status`),
  KEY `ix_pa_entry` (`tenant_id`,`entry_id`,`status`),
  KEY `fk_pa_txn` (`txn_id`),
  KEY `fk_pa_entry` (`entry_id`),
  CONSTRAINT `fk_pa_entry` FOREIGN KEY (`entry_id`) REFERENCES `entries` (`id`),
  CONSTRAINT `fk_pa_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`),
  CONSTRAINT `fk_pa_txn` FOREIGN KEY (`txn_id`) REFERENCES `transactions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `payment_allocations` VALUES ('1','1','1','1','6000000','active',NULL,'2','2026-10-19 22:22:34',NULL,NULL),('2','1','2','1','4000000','active',NULL,'2','2026-10-19 22:22:34',NULL,NULL),('3','1','5','5','120000','active',NULL,'2','2026-10-19 22:22:34',NULL,NULL),('4','1','9','8','300000','active',NULL,'2','2026-10-19 22:22:35',NULL,NULL),('5','1','14','10','1200000','active',NULL,'2','2026-10-19 22:22:36',NULL,NULL),('6','1','15','11','480000','active',NULL,'2','2026-10-19 22:22:37',NULL,NULL),('7','1','25','17','400000','active',NULL,'2','2026-10-19 22:23:02',NULL,NULL),('8','1','26','17','600000','active',NULL,'2','2026-10-19 22:23:02',NULL,NULL),('9','1','27','18','1000000','reversed',NULL,'2','2026-10-19 22:23:02','2026-10-19 22:23:03','2'),('10','1','28','19','1000000','active',NULL,'2','2026-10-19 22:23:03',NULL,NULL),('11','1','28','20','4000000','active',NULL,'2','2026-10-19 22:23:03',NULL,NULL),('12','1','27','21','2000000','reversed',NULL,'2','2026-10-19 22:23:03','2026-10-19 22:23:03','2'),('13','1','27','20','1500000','active',NULL,'2','2026-10-19 22:23:03',NULL,NULL),('14','1','27','21','500000','active',NULL,'2','2026-10-19 22:23:03',NULL,NULL),('15','1','32','22','500000','active',NULL,'2','2026-10-19 22:23:03',NULL,NULL),('16','1','33','29','50000','active',NULL,'2','2026-10-19 22:23:06',NULL,NULL),('17','1','34','31','2000000','active',NULL,'2','2026-10-19 22:23:06',NULL,NULL),('18','1','41','33','4000','active',NULL,'2','2026-10-19 22:23:08',NULL,NULL),('19','1','42','34','3000000','active',NULL,'2','2026-10-19 22:23:09',NULL,NULL),('20','1','43','35','3000000','active',NULL,'2','2026-10-19 22:23:09',NULL,NULL),('21','1','46','35','7000000','active',NULL,'2','2026-10-19 22:23:10',NULL,NULL);
/*FBEND*/
DROP TABLE IF EXISTS `project_milestones`;
/*FBEND*/
CREATE TABLE `project_milestones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `due_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `entry_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pm_t` (`tenant_id`),
  CONSTRAINT `fk_pm_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `project_milestones` VALUES ('1','1','1','Hakediş 2','2026-11-19','2000000','12','2026-10-19 22:22:37');
/*FBEND*/
DROP TABLE IF EXISTS `project_quotes`;
/*FBEND*/
CREATE TABLE `project_quotes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned NOT NULL,
  `kind` enum('quote','order') NOT NULL DEFAULT 'quote',
  `number` varchar(60) DEFAULT NULL,
  `quote_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `status` enum('draft','sent','accepted','rejected') NOT NULL DEFAULT 'draft',
  `note` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pq_t` (`tenant_id`),
  CONSTRAINT `fk_pq_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
DROP TABLE IF EXISTS `projects`;
/*FBEND*/
CREATE TABLE `projects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(160) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `contract_minor` bigint(20) NOT NULL DEFAULT 0,
  `est_cost_minor` bigint(20) NOT NULL DEFAULT 0,
  `status` enum('planned','active','done','cancelled') NOT NULL DEFAULT 'active',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_pr_t` (`tenant_id`),
  CONSTRAINT `fk_pr_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `projects` VALUES ('1','1','1','1','Santral Kurulumu','TRY','5000000','3000000','active',NULL,NULL,NULL,'0','2026-10-19 22:22:36');
/*FBEND*/
DROP TABLE IF EXISTS `rate_limits`;
/*FBEND*/
CREATE TABLE `rate_limits` (
  `k` varchar(120) NOT NULL,
  `hits` int(11) NOT NULL,
  `window_start` datetime NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `rate_limits` VALUES ('2fa_enable:1','2','2026-10-19 22:20:16'),('2fa_ip:127.0.0.1','9','2026-10-19 22:20:16'),('adm_acc:1:1:accounts','1','2026-10-19 22:23:00'),('adm_acc:1:1:reports','1','2026-10-19 22:23:00'),('adm_acc:1:1:transactions','1','2026-10-19 22:23:00'),('api_ip:127.0.0.1','546','2026-10-19 22:22:33'),('api_user:1','4','2026-10-19 22:23:32'),('api_user:2','19','2026-10-19 22:23:32'),('api_user:3','38','2026-10-19 22:22:30'),('captcha_ip:127.0.0.1','40','2026-10-19 22:20:16'),('forgot_id:10b002daf7d0d7bb6ce4ddb1eace6e6ea8797dc2ae8eac370896018434fdc32b','1','2026-10-19 22:22:32'),('forgot_id:9d158211d6d187975b6ea8731d701836746c45264805fb516c4b825d77575a12','1','2026-10-19 22:22:32'),('forgot_ip:127.0.0.1','2','2026-10-19 22:22:32'),('honeypot:127.0.0.1','1','2026-10-19 22:22:30'),('login_id:2adbc0b959b6cefa8a28619eba9556a8b3e989948da312fdc252299441054066','11','2026-10-19 22:20:16'),('login_id:9d158211d6d187975b6ea8731d701836746c45264805fb516c4b825d77575a12','15','2026-10-19 22:22:31'),('login_id:bf7af099680062112c03af6bf21788199efd3be7eb5577030428c546327e2d13','1','2026-10-19 22:22:30'),('login_id:d3206c76a6d95265cea4f2b55e315c420f7dadad3198cdfba7831a080179d026','7','2026-10-19 22:22:30'),('login_ip:127.0.0.1','40','2026-10-19 22:20:16'),('pwchange:3','4','2026-10-19 22:22:30'),('reset_ip:127.0.0.1','4','2026-10-19 22:22:31');
/*FBEND*/
DROP TABLE IF EXISTS `recurring_templates`;
/*FBEND*/
CREATE TABLE `recurring_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `entry_kind` enum('receivable','payable') NOT NULL,
  `title` varchar(200) NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `frequency` enum('weekly','monthly','yearly') NOT NULL DEFAULT 'monthly',
  `next_date` date NOT NULL,
  `anchor_day` tinyint(4) NOT NULL DEFAULT 1,
  `end_date` date DEFAULT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `last_generated` date DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_rt_t` (`tenant_id`),
  CONSTRAINT `fk_rt_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `recurring_templates` VALUES ('1','1','1','payable','Aylık abonelik','30000','TRY',NULL,NULL,'monthly','2026-12-23','23',NULL,'1','2026-10-20','2026-10-19 22:22:34');
/*FBEND*/
DROP TABLE IF EXISTS `schema_migrations`;
/*FBEND*/
CREATE TABLE `schema_migrations` (
  `version` varchar(100) NOT NULL,
  `checksum` char(64) NOT NULL,
  `applied_at` datetime NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*FBEND*/
INSERT INTO `schema_migrations` VALUES ('001_core','2d7a0f529b8d465b588d781044a60d9cb4baf28da2486cf3fea7a419c77b2087','2026-10-19 22:20:15'),('002_finance','280896f0df01ee75f67ba9f9195332cffca21c8e6a49a5c4c3626a6abd726ced','2026-10-19 22:20:15'),('003_payments_allocations','64f57c10b2fca0825123cf9bfe36db39250c1789b8cf7b2c1a1c8eef9a37b87c','2026-10-19 22:20:15'),('004_planned_dates','d7b59bc0ce7bd1a5010ac728fe803eb2ad31bf0d17355987959945fbfdf62ccb','2026-10-19 22:20:15');
/*FBEND*/
DROP TABLE IF EXISTS `sessions`;
/*FBEND*/
CREATE TABLE `sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `token_hash` char(64) NOT NULL,
  `prev_token_hash` char(64) DEFAULT NULL,
  `prev_valid_until` datetime DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `epoch` int(11) NOT NULL,
  `csrf_secret` char(64) NOT NULL,
  `ip` varchar(64) NOT NULL,
  `ua_hash` char(64) NOT NULL,
  `label` varchar(160) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `last_seen_at` datetime NOT NULL,
  `rotated_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `revoked_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sessions_token` (`token_hash`),
  KEY `ix_sessions_prev` (`prev_token_hash`),
  KEY `ix_sessions_user` (`user_id`),
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `sessions` VALUES ('1','9ff15bd3967895face616b9b5744a0eac25365ebcc11adb91394a1a58f74fe57',NULL,'2026-10-19 22:20:14','1','2','4478a7bc2873f36901bb8c041e5f3118a5a938eadc755bde966026ea4b78ce55','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:20:16','2026-10-19 22:20:16','2026-10-19 22:20:16','2026-10-20 10:20:16',NULL),('2','16b7b33de36987dec9a6159ad788306e3e39307c04bf4f3d1e4f8e36f2b89674','d073165eb026466a70899b9c7fb7904ed3c1877a52d110ba67e233a79d1c395f','2026-10-19 22:20:14','1','2','969101ef7ef513f2dc7f4a7eae2c963de6d6aa4d6cf175f4018c342db129f191','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:20:16','2026-10-19 22:20:19','2026-10-19 22:20:19','2026-10-20 10:20:16',NULL),('3','4d43f68dc11ef226e84b5c9d8db3bd3662ad96e25fce35fae1727a7f0a22ec21',NULL,NULL,'1','2','ca842d625af8e52b332add0f0ba5842bcc63d3e75e85075b3cb5f3d7a9dda4ed','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:20:32','2026-10-19 22:20:32','2026-10-19 22:20:32','2026-10-20 10:20:32',NULL),('4','bafdd420ce0e2e0f3c30d37ee46d11cec3f50201e5401e9ed87aaf8ae2871015',NULL,NULL,'1','2','7aed55a6141d16be14bbf3e4107226d2d8f377382cb871b15a7587beb51a5999','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:21:02','2026-10-19 22:21:02','2026-10-19 22:21:02','2026-10-20 10:21:02','2026-10-19 22:21:02'),('5','004fee250f0f5a3fba64aa44c9ad1db7f2a830b7fb659717e9952ab4977c8f73',NULL,NULL,'1','2','7c4004b4e60e0ae081580d4af1145d3d5056233f527d3cf9b1c94b16ecc6d4e5','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:21:32','2026-10-19 22:21:32','2026-10-19 22:21:32','2026-10-20 10:21:32',NULL),('6','9fc669d2f6909d9b3ee6ac3fd8ab603a26297c500bc74719d9a9496b5274f2af',NULL,NULL,'1','2','e9991c1709d91908d4428a1be105cdcfddb1550f872447fef1c320f48979de2f','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:02','2026-10-19 22:22:02','2026-10-19 22:22:02','2026-10-20 10:22:02',NULL),('7','bc0806679c7a647aff0286eb1ac9f6a9a58f32eda6f82e7604eb6483fe4bc191','cf53d191d9de7b1c124746b974816db86bb17a0c41cb07197782e979a466dec4','2026-10-19 22:23:33','1','2','a6c87926bf85ea35e32f5c971d9bbf604c9b89c0f16ab0dcd6be50923668e4a9','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:30','2026-10-19 22:22:33','2026-10-19 22:22:33','2026-10-20 10:22:30',NULL),('8','8c2bd4985ec6517463d36ad57278963440053ac8ad303990c711c3640346cb13',NULL,NULL,'3','1','bd4f872c06444fe4e37be8d1c045d2571c9d4a78ae81e16705a8db8a08a67f9c','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:30','2026-10-19 22:22:30','2026-10-19 22:22:30','2026-10-20 10:22:30','2026-10-19 22:22:31'),('9','595bf383757e42a0e630dbda1fa7401a93efd7c37d55fc30f74298ae8fcb21f9',NULL,NULL,'3','2','4a8b520f4c637b47a55db9f867e7dcd4467dffd96a43b4ecdc0ba4e807b030ae','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:31','2026-10-19 22:22:31','2026-10-19 22:22:31','2026-10-20 10:22:31','2026-10-19 22:22:33'),('10','4ad907313a8cda273c92b0753766d48c58d33149ded4651f85b51b09a38e6f40',NULL,NULL,'2','2','91a39a76bd2345a65a8120b6fd4bc4da18217a3f0279e5ca96039013826b8527','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:31','2026-10-19 22:22:31','2026-10-19 22:22:31','2026-10-20 10:22:31','2026-10-19 22:22:31'),('11','8dd67d9178f766da58bc78e4a79471e0b6624c587f9cc6a3faa4e802254a1eed',NULL,NULL,'2','2','749f9dab04fbaf215e9159004dae965fb62f22bd4503d34c361030ff451e37ab','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:31','2026-10-19 22:22:31','2026-10-19 22:22:31','2026-10-20 10:22:31','2026-10-19 22:22:32'),('12','d4bbeb77799e2722a2cfb51e7208c6fca70b8a3f78306c685647b80e2899c6a6',NULL,NULL,'2','2','8a44e6b8ed29f60d332a2475c9a00f767eac05715e6ffe9631d9f48a152a7ade','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:32','2026-10-19 22:22:32','2026-10-19 22:22:32','2026-10-20 10:22:32','2026-10-19 22:22:32'),('13','9f326adfabe6daa09382676cf08e77e8d03a2e640e8b339f5de5576b4d10d26a',NULL,NULL,'2','2','d0c8c32fe0580dfb2e922531985eb3e4c66a85da69555a5d7180c66e1fc8e427','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:32','2026-10-19 22:22:32','2026-10-19 22:22:32','2026-10-20 10:22:32','2026-10-19 22:22:32'),('14','4cde55402e398f81b594026d63db6ba6f48c72be3ffbe1a3552d9047e7383199',NULL,NULL,'2','3','25104df7afbf562ee60549ab265264164c2f89bcc9e5c3a40eded56dbb4a6e4d','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:32','2026-10-19 22:22:32','2026-10-19 22:22:32','2026-10-20 10:22:32','2026-10-19 22:23:01'),('15','8160cb58a17f0b3b509672c214771dd8ecfbc751cbbd5df8daaf14ed4d94a1cc',NULL,NULL,'3','2','4b5b013a408bc44369e3a1562a0de3c51c6ba0e6c63b008308eae2d03fc6bee4','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:33','2026-10-19 22:22:33','2026-10-19 22:22:33','2026-10-20 10:22:33','2026-10-19 22:22:33'),('16','15d80278d798a23bef6a1cbfd96a710db7e997e19751c1a34054e8355a42872a',NULL,NULL,'3','3','acf20585984232ad1ca15aec380ba915b3aefb268c96b31d29a3b29fbba0bb14','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:33','2026-10-19 22:22:33','2026-10-19 22:22:33','2026-10-20 10:22:33',NULL),('17','b9a0ef515dd9d00c7c075bff601bfadf8fbc8c77b2aca96abcaba26d000ab0a0','19d984c1e0f9a45e959c523280bef1651f9a36e048e8a2f6a019be65a636fd43','2026-10-19 22:24:00','2','3','d33b4af4099a01b855397c71a969e72100cff9eb993d3bf37811b8e4d7acfc61','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:33','2026-10-19 22:23:00','2026-10-19 22:23:00','2026-10-20 10:22:33','2026-10-19 22:23:01'),('18','3ef4705c2cc3c367feae8e2b727e9ca2a96077f7e79d922b2c4853fa554479f2','4c3576b2764008ce3a0917fa1163277fe1d57cbf047152d1c86ade97da5f13cd','2026-10-19 22:23:38','3','3','e2f91548045c285da5b27e2d8eb1a8a9857f7adbc215c4a35e14cc769ecaa1ba','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:22:33','2026-10-19 22:22:38','2026-10-19 22:22:38','2026-10-20 10:22:33',NULL),('19','58cf388d8390e5dc956ad2dabe529b43a1e23d8b2092769ebb131b9ffa7b6802',NULL,NULL,'1','2','e5194ab5a5409f27ea154c333e5009017925e6e11783d4a75091d4209314eb5a','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:23:00','2026-10-19 22:23:00','2026-10-19 22:23:00','2026-10-20 10:23:00',NULL),('20','c43b05aa18e36fef07f164e6efe6a9097023ce4330464d0df70f17ae8cc629ae','8322f77cbbec707441f9545f31388af0bee479b9625b52f9e88506037651e220','2026-10-19 22:24:07','2','4','95765d38d5bc220894e586b4ab91867bfea835e92055bc8dc996bb25106d926e','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:23:01','2026-10-19 22:23:07','2026-10-19 22:23:07','2026-10-20 10:23:01',NULL),('21','15d347b9d57b41ad573645a1bd293fc4b8c309a92c8275fb96eb981cd5c78933','de856a30ec78cd60cfb9b8473407ea20a2ecd6cffd6e7fb2b5a91b525fdad972','2026-10-19 22:24:08','3','3','035434ed1d0e1196cea5a7879f785820beacad846003619f75ddd200d45eaa32','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:23:01','2026-10-19 22:23:08','2026-10-19 22:23:08','2026-10-20 10:23:01',NULL),('22','919d9be5916c336ef99f0bea5b33c7493fc71670a29ff5b8928cf145c336829d',NULL,NULL,'2','4','76b5bdac324fe83d8547521d7fcdf32be0b27233770125bc96753524314668fc','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:23:08','2026-10-19 22:23:08','2026-10-19 22:23:08','2026-10-20 10:23:08',NULL),('23','6e23114b810e06d91044e356cbab49b1a066321753ab7ef57ca0c237df2927e0',NULL,NULL,'3','3','9f0470e222ecb8dab513356a1214a90ffce609c738296befaaf8ca9b04f949b3','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:23:08','2026-10-19 22:23:08','2026-10-19 22:23:08','2026-10-20 10:23:08',NULL),('24','10c61507f5f8a76fe6c230b60ff9bdbb9b27b252ab1911f1755d141e52618b60','0da4d270a8fea1bbf9b14f9164d2ad55bc171fc4e75199caa836777cd4ee9527','2026-10-19 22:24:31','2','4','1cb367ac8cedab34a5a909915b01da0def3a10cd84f5049038f2bc9fee713b47','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:23:10','2026-10-19 22:23:31','2026-10-19 22:23:31','2026-10-20 10:23:10',NULL),('25','224941e3aa8cc907594ab5c6a53699caa41f43c3bbc2beee97c3f38beb03c9fb',NULL,NULL,'1','2','033bb16e30add8b6bf9fcfe2169e342d5d70735281b1c9f18784bc2fd9b37235','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:23:31','2026-10-19 22:23:31','2026-10-19 22:23:31','2026-10-20 10:23:31',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `statement_lines`;
/*FBEND*/
CREATE TABLE `statement_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `line_date` date NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `line_hash` char(64) NOT NULL,
  `matched_txn_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('unmatched','matched','ignored') NOT NULL DEFAULT 'unmatched',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sl_hash` (`tenant_id`,`account_id`,`line_hash`),
  CONSTRAINT `fk_sl_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `statement_lines` VALUES ('1','1','1','2026-10-20','POS TAHSILAT','25000','2dd70cd3ad2358a7943c0e8cac8c05d73ae6b21e9d93ef0e63fb60ee1c70cd29','13','matched','2026-10-19 22:22:36'),('2','1','1','2026-10-20','KOMISYON','-500','6ab4bf50d5e6e6224b07dfaa833e7336a0a25f2c620a77c0244f5807239ae01d',NULL,'unmatched','2026-10-19 22:22:36'),('3','1','1','2026-10-20','KOMISYON','-500','982e8957d68f530fe63e2ee3fadbda5c9c4640deb1e8a5a1e1faae6365fca202',NULL,'unmatched','2026-10-19 22:22:36');
/*FBEND*/
DROP TABLE IF EXISTS `stock_items`;
/*FBEND*/
CREATE TABLE `stock_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('product','service') NOT NULL DEFAULT 'product',
  `code` varchar(60) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `unit` varchar(20) NOT NULL DEFAULT 'adet',
  `barcode` varchar(60) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `sale_price_minor` bigint(20) NOT NULL DEFAULT 0,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 2000,
  `min_qty_milli` bigint(20) NOT NULL DEFAULT 0,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_si_code` (`tenant_id`,`code`),
  CONSTRAINT `fk_si_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `stock_items` VALUES ('1','1','product','KBL-1','Kablo 10m','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:22:37'),('2','1','product','BZD-T4','Buzdolabı T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:23:04'),('3','1','product',NULL,'Televizyon T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:23:04'),('4','1','service',NULL,'Nakliye T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:23:04'),('5','1','product',NULL,'Stoksuz giriş','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:23:05'),('7','1','product','IDM-1','Idem','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:23:05'),('8','1','product','DEL-1','Silinecek','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:23:05'),('9','1','product','NOSTK','Stoksuz Ürün T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:23:05');
/*FBEND*/
DROP TABLE IF EXISTS `stock_movements`;
/*FBEND*/
CREATE TABLE `stock_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `warehouse_id` bigint(20) unsigned NOT NULL,
  `kind` enum('in','out','return_in','return_out') NOT NULL,
  `qty_milli` bigint(20) NOT NULL,
  `unit_cost_minor` bigint(20) NOT NULL DEFAULT 0,
  `move_date` date NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_sm_t` (`tenant_id`,`item_id`),
  KEY `ix_sm_inv` (`invoice_id`),
  CONSTRAINT `fk_sm_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `stock_movements` VALUES ('1','1','1','1','in','10000','10000','2026-10-20',NULL,'5','Alış faturası','posted','2026-10-19 22:22:37'),('2','1','1','1','out','2000','10000','2026-10-20','1',NULL,NULL,'posted','2026-10-19 22:22:37'),('3','1','1','1','out','9000','10000','2026-10-20',NULL,NULL,NULL,'posted','2026-10-19 22:22:37'),('4','1','2','1','in','5000','1000000','2026-10-20',NULL,'15','Alış faturası','posted','2026-10-19 22:23:04'),('5','1','3','1','in','2000','800000','2026-10-20',NULL,'15','Alış faturası','posted','2026-10-19 22:23:04'),('6','1','2','1','in','2000','1000000','2026-10-20',NULL,'15','Alış faturası','posted','2026-10-19 22:23:04'),('7','1','2','1','return_out','4000','1000000','2026-10-20',NULL,'15','Alış faturası (düzeltme)','posted','2026-10-19 22:23:04'),('8','1','2','1','in','1000','1000000','2026-10-20',NULL,'16','Alış faturası','posted','2026-10-19 22:23:05'),('9','1','7','1','in','1000','100','2026-10-20',NULL,'19','Alış faturası','posted','2026-10-19 22:23:05'),('10','1','2','1','out','3000','1000000','2026-10-20',NULL,'20','Satış faturası','voided','2026-10-19 22:23:05'),('12','1','9','1','in','5000','6000','2026-10-20',NULL,'23','Alış faturası','posted','2026-10-19 22:23:06'),('13','1','9','1','out','2000','6000','2026-10-20',NULL,'22','Satış faturası','posted','2026-10-19 22:23:06');
/*FBEND*/
DROP TABLE IF EXISTS `system_settings`;
/*FBEND*/
CREATE TABLE `system_settings` (
  `k` varchar(80) NOT NULL,
  `v` mediumtext DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
DROP TABLE IF EXISTS `tenants`;
/*FBEND*/
CREATE TABLE `tenants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `company_name` varchar(200) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `status` enum('active','suspended','archived') NOT NULL DEFAULT 'active',
  `settings` mediumtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tenants_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `tenants` VALUES ('1','Alfa Ltd','Alfa Ticaret',NULL,'active','{\"locale\":\"tr-TR\",\"theme\":\"dark\",\"date_format\":\"DD.MM.YYYY\",\"default_workspace_id\":null,\"default_account_id\":1,\"vat_rates\":[0,800,1000,2000],\"preferred_currency\":\"TRY\",\"notify\":{\"due\":true,\"overdue\":true,\"card\":true,\"bills\":false,\"email\":false},\"invoice\":{\"prefix\":\"\",\"default_due_days\":30,\"note\":\"\"},\"stock\":{\"allow_negative\":false}}','1','2026-10-19 22:22:30','2026-10-19 22:23:10',NULL),('2','Beta AŞ',NULL,NULL,'active','{\"locale\":\"tr-TR\",\"notify\":{\"due\":true,\"overdue\":true,\"card\":true,\"bills\":true,\"email\":false}}','1','2026-10-19 22:22:30','2026-10-19 22:23:08',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `transactions`;
/*FBEND*/
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `direction` enum('in','out') NOT NULL,
  `kind` enum('income','expense','collection','payment','transfer','fx','card_payment','loan_payment','loan_proceeds','adjustment','owner_in','owner_out') NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `interest_minor` bigint(20) NOT NULL DEFAULT 0,
  `currency` char(3) NOT NULL,
  `txn_date` date NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `entry_id` bigint(20) unsigned DEFAULT NULL,
  `card_id` bigint(20) unsigned DEFAULT NULL,
  `loan_id` bigint(20) unsigned DEFAULT NULL,
  `loan_installment_id` bigint(20) unsigned DEFAULT NULL,
  `transfer_group` varchar(26) DEFAULT NULL,
  `fx_rate` decimal(18,8) DEFAULT NULL,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `void_reason` varchar(300) DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `voided_by` bigint(20) unsigned DEFAULT NULL,
  `replaces_id` bigint(20) unsigned DEFAULT NULL,
  `statement_line_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `reason` varchar(300) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `method` varchar(30) DEFAULT NULL,
  `for_workspace_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tx_acc` (`tenant_id`,`account_id`,`status`),
  KEY `ix_tx_date` (`tenant_id`,`txn_date`),
  KEY `ix_tx_entry` (`entry_id`),
  KEY `ix_tx_group` (`transfer_group`),
  KEY `fk_tx_a` (`account_id`),
  KEY `ix_tx_contact` (`tenant_id`,`contact_id`),
  KEY `ix_tx_forws` (`tenant_id`,`for_workspace_id`),
  CONSTRAINT `fk_tx_a` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `fk_tx_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `transactions` VALUES ('1','1','1','1','in','collection','6000000','0','TRY','2026-10-20','Tahsilat: Büyük satış',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:34',NULL,NULL,NULL,NULL),('2','1','1','1','in','collection','4000000','0','TRY','2026-10-20','Tahsilat: Büyük satış',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:34',NULL,NULL,NULL,NULL),('3','1','1','1','out','transfer','2000000','0','TRY','2026-10-20','Transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fc4db87785aaa122ae7de91aae',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:34',NULL,NULL,NULL,NULL),('4','1','1','2','in','transfer','2000000','0','TRY','2026-10-20','Transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fc4db87785aaa122ae7de91aae',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:34',NULL,NULL,NULL,NULL),('5','1','1','1','in','collection','120000','0','TRY','2026-10-20','Tahsilat: Satış faturası FB-2026-001 — Müşteri A',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:34',NULL,NULL,NULL,NULL),('6','1','1','1','out','fx','1000000','0','TRY','2026-10-20','Döviz: TRY→EUR kur 0.02500000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'81a4299103ed4607f14baec8bf','0.02500000','0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:35',NULL,NULL,NULL,NULL),('7','1','1','3','in','fx','25000','0','EUR','2026-10-20','Döviz: TRY→EUR kur 0.02500000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'81a4299103ed4607f14baec8bf','0.02500000','0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:35',NULL,NULL,NULL,NULL),('8','1','1','1','out','expense','1500','0','TRY','2026-10-20','Döviz işlem masrafı','14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:35',NULL,NULL,NULL,NULL),('9','1','1','1','out','payment','300000','0','TRY','2026-10-20','Ödeme: Tedarikçi borcu',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:35',NULL,NULL,NULL,NULL),('10','1','1','1','out','card_payment','40000','0','TRY','2026-10-20','Kart ödemesi: Kurumsal Kart',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:35',NULL,NULL,NULL,NULL),('11','1','1','1','in','loan_proceeds','12000000','0','TRY','2026-10-20','Kredi kullandırım: İşletme Kredisi',NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:36',NULL,NULL,NULL,NULL),('12','1','1','1','out','loan_payment','1134715','240000','TRY','2026-10-20','Kredi taksiti 1/12: İşletme Kredisi',NULL,NULL,NULL,NULL,NULL,'1','1',NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:36',NULL,NULL,NULL,NULL),('13','1','1','1','in','income','25000','0','TRY','2026-10-20','POS TAHSILAT','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,'1','2','2026-10-19 22:22:36',NULL,NULL,NULL,NULL),('14','1','1','1','in','collection','1200000','0','TRY','2026-10-20','Tahsilat: Satış faturası PR-1 — Müşteri A',NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:36',NULL,NULL,NULL,NULL),('15','1','1','1','out','payment','480000','0','TRY','2026-10-20','Ödeme: Alış faturası ALIS-9 — Tedarikçi B',NULL,'2','1',NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:37',NULL,NULL,NULL,NULL),('16','1','1','1','out','expense','50000','0','TRY','2026-10-20','Yakıt','6',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:37',NULL,NULL,NULL,NULL),('17','1','1','1','in','income','100000','0','TRY','2026-10-20','Çift tık testi','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','Hatalı giriş','2026-10-19 22:22:37','2',NULL,NULL,'2','2026-10-19 22:22:37',NULL,NULL,NULL,NULL),('18','1','1','1','out','expense','10000','0','TRY','2026-10-20','eski',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','Düzenleme ile yenisi oluşturuldu','2026-10-19 22:22:37','2',NULL,NULL,'2','2026-10-19 22:22:37',NULL,NULL,NULL,NULL),('19','1','1','1','out','expense','12000','0','TRY','2026-10-20','düzeltilmiş',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,'18',NULL,'2','2026-10-19 22:22:37',NULL,NULL,NULL,NULL),('20','1','1','1','out','expense','120000','0','TRY','2026-10-20','KDV dahil',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2000','20000','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:37',NULL,NULL,NULL,NULL),('21','1','1','1','out','expense','120000','0','TRY','2026-10-20','KDV hariç',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2000','20000','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:37',NULL,NULL,NULL,NULL),('22','1','1','2','out','adjustment','5000','0','TRY','2026-10-20','Bakiye düzeltme: Sayım farkı',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:37',NULL,NULL,NULL,NULL),('23','1','1','1','out','expense','100','0','TRY','2026-10-20','=HYPERLINK(\"http://evil\",\"x\")',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:22:39',NULL,NULL,NULL,NULL),('24','1','1','1','out','expense','7700','0','TRY','2026-10-20','admin düzeltilecek',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','[Yönetici düzeltmesi] Mükerrer giriş','2026-10-19 22:23:01','1',NULL,NULL,'2','2026-10-19 22:23:00',NULL,NULL,NULL,NULL),('25','1','1','1','out','payment','400000','0','TRY','2026-10-20','Ödeme: Alış faturası T4-5-8732 — Tedarikçi B',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:02','Kısmi ödeme',NULL,NULL,NULL),('26','1','1','1','out','payment','600000','0','TRY','2026-10-20','Ödeme: Alış faturası T4-5-8732 — Tedarikçi B',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:02',NULL,NULL,NULL,NULL),('27','1','1','1','out','payment','3000000','0','TRY','2026-10-20','Toplu gönderim',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:02',NULL,NULL,NULL,NULL),('28','1','1','1','out','payment','5000000','0','TRY','2026-10-20','Ödeme: Alış faturası T4-7-b6c0 — Tedarikçi B',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','test iptal','2026-10-19 22:23:04','2',NULL,NULL,'2','2026-10-19 22:23:03',NULL,NULL,NULL,NULL),('29','1','1','2','out','payment','10000','0','TRY','2026-10-20','çift tık',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:03',NULL,NULL,NULL,NULL),('30','1','1','1','out','payment','7000','0','TRY','2026-10-20','Ödeme',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:03',NULL,'DKN-77',NULL,NULL),('31','1','1','1','out','payment','7000','0','TRY','2026-10-20','Ödeme',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:03',NULL,'DKN-77',NULL,NULL),('32','1','1','1','in','collection','800000','0','TRY','2026-10-20','Tahsilat: Satış faturası T4-10-db8b — Müşteri A',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:03',NULL,NULL,NULL,NULL),('33','1','1','1','in','collection','50000','0','TRY','2026-10-20','Tahsilat: Satış faturası T4-S-NO — Müşteri A',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:06',NULL,NULL,NULL,NULL),('34','1','2','5','out','payment','2000000','0','TRY','2026-10-20','dekont eklendi',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:06','Güncel neden','SAHSI-1','transfer','1'),('35','1','2','5','out','owner_in','700000','0','TRY','2026-10-20','Sermaye',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'e6c060bba463fa0421f9296b3b',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:07',NULL,NULL,NULL,NULL),('36','1','1','1','in','owner_in','700000','0','TRY','2026-10-20','Sermaye',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'e6c060bba463fa0421f9296b3b',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:07',NULL,NULL,NULL,NULL),('37','1','1','1','out','owner_out','2700000','0','TRY','2026-10-20','Geri ödeme',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'123630423ae1e1d446e588a76f',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:07',NULL,NULL,NULL,NULL),('38','1','2','5','in','owner_out','2700000','0','TRY','2026-10-20','Geri ödeme',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'123630423ae1e1d446e588a76f',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:07',NULL,NULL,NULL,NULL),('39','1','1','1','out','transfer','1000','0','TRY','2026-10-20','iç transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'d4bea0e83fc8af8e5a8944ff4d',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:07',NULL,NULL,NULL,NULL),('40','1','1','2','in','transfer','1000','0','TRY','2026-10-20','iç transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'d4bea0e83fc8af8e5a8944ff4d',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:07',NULL,NULL,NULL,NULL),('41','1','2','5','out','payment','4000','0','TRY','2026-10-20','Ödeme: Su',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:08',NULL,NULL,NULL,NULL),('42','1','1','1','in','collection','3000000','0','TRY','2026-10-20','Tahsilat: Satış faturası HOME-1 — Avans Müşterisi',NULL,'4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:09',NULL,NULL,NULL,NULL),('43','1','1','1','in','collection','3000000','0','TRY','2026-10-20','Avans',NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:09',NULL,NULL,NULL,NULL),('44','1','1','1','in','income','7700','0','TRY','2026-10-20',NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','test','2026-10-19 22:23:09','2',NULL,NULL,'2','2026-10-19 22:23:09',NULL,NULL,NULL,NULL),('45','1','1','1','in','collection','50000','0','TRY','2026-10-20',NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','test temizliği','2026-10-19 22:23:09','2',NULL,NULL,'2','2026-10-19 22:23:09',NULL,NULL,NULL,NULL),('46','1','1','1','in','collection','7000000','0','TRY','2026-10-20','Tahsilat: Satış faturası HOME-2 — Avans Müşterisi 2',NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:23:10',NULL,NULL,NULL,NULL);
/*FBEND*/
DROP TABLE IF EXISTS `users`;
/*FBEND*/
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `email` varchar(190) NOT NULL,
  `display_name` varchar(160) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL,
  `admin_flag` tinyint(4) DEFAULT NULL,
  `status` enum('active','suspended','archived') NOT NULL DEFAULT 'active',
  `must_change_password` tinyint(4) NOT NULL DEFAULT 0,
  `email_verified_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(64) DEFAULT NULL,
  `prev_login_at` datetime DEFAULT NULL,
  `prev_login_ip` varchar(64) DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `lock_level` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `totp_secret_enc` text DEFAULT NULL,
  `totp_enabled` tinyint(4) NOT NULL DEFAULT 0,
  `totp_last_step` bigint(20) DEFAULT NULL,
  `recovery_codes` text DEFAULT NULL,
  `session_epoch` int(11) NOT NULL DEFAULT 1,
  `password_changed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_users_email` (`email`),
  UNIQUE KEY `ux_users_admin` (`admin_flag`),
  KEY `ix_users_tenant` (`tenant_id`),
  CONSTRAINT `fk_users_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `users` VALUES ('1',NULL,'owner@test.local','Yönetici','$argon2id$v=19$m=19456,t=2,p=1$emptOEZTY1lMLjVCaEdwQg$SMLOonwnXoM7fMOjqDt/4fR/sYb85iLRa0INCrXndc8','admin','1','active','0','2026-10-19 22:20:15','2026-10-19 22:23:31','127.0.0.1','2026-10-19 22:23:00','127.0.0.1','0','0',NULL,'0rB6jwxdhGrMte2nu/U/QDvk4b+/23ILxQepC0ywb9K6kxNkTES6BClEJROwsqmZeY1sdxHlZHho+ndI','1','59748288','[\"3a6e04c21bdbaaebde9dd73b3705059aa491c7eaf80f216a49958f3baa9c908d\",\"260144e7cb319169ae1eb33907dd225da5c6bcced1a8ecf4f96c378ef1fa0856\",\"1fbc01000c6288c5960bdbd84a853cc78cacf35d1e1834c42a2a4a7b150efb96\",\"98d7c498c7a3a01a085b8e8b2ef3800cb02f658503c2fdcbff25103aea65b83f\",\"60206cad84c2e8ec11663f188ced6d379ac02924951b42f41194510cab8dce2d\",\"4cd6a58ecd711be11093c7e628075521494e5432ad02595d24c78ed54e2a2782\",\"5b3ee2b67d7f2420b6e1d8481d910de5b3da165602a3244504997b67d67f5f41\",\"cb2ac1e4bac587b165afae4b6678ba2a9de5f55c3ae50eac822425b8f533348c\"]','2','2026-10-19 22:20:15','2026-10-19 22:20:15'),('2','1','alfa@test.local','Hile','$argon2id$v=19$m=19456,t=2,p=1$TWhNNDZ3eWgyLzBMd2dqRA$Qv5JkxVvv5KxsXNidwgwKq7Q0wRPoKqMvXLBBpg5vmI','customer',NULL,'active','0','2026-10-19 22:22:31','2026-10-19 22:23:10','127.0.0.1','2026-10-19 22:23:08','127.0.0.1','0','0',NULL,NULL,'0',NULL,NULL,'4','2026-10-19 22:22:32','2026-10-19 22:22:30'),('3','2','beta@test.local','Beta AŞ','$argon2id$v=19$m=19456,t=2,p=1$SHZWQ1dTamhCN1N0b1ZISw$UPDNMehO32LnGMIPm6XUJZfycTSrWhw8KEr3GpD0Zy0','customer',NULL,'active','0',NULL,'2026-10-19 22:23:08','127.0.0.1','2026-10-19 22:23:01','127.0.0.1','0','0',NULL,NULL,'0',NULL,NULL,'3','2026-10-19 22:22:31','2026-10-19 22:22:30');
/*FBEND*/
DROP TABLE IF EXISTS `warehouses`;
/*FBEND*/
CREATE TABLE `warehouses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_wh` (`tenant_id`,`name`),
  CONSTRAINT `fk_wh_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `warehouses` VALUES ('1','1','Ana Depo','0');
/*FBEND*/
DROP TABLE IF EXISTS `workspaces`;
/*FBEND*/
CREATE TABLE `workspaces` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `kind` enum('business','personal') NOT NULL DEFAULT 'business',
  `legal_name` varchar(200) DEFAULT NULL,
  `tax_no` varchar(30) DEFAULT NULL,
  `color` varchar(9) DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_ws_name` (`tenant_id`,`name`),
  CONSTRAINT `fk_ws_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `workspaces` VALUES ('1','1','Horizon','business',NULL,NULL,NULL,'0','2026-10-19 22:22:33'),('2','1','Şahsi','personal',NULL,NULL,NULL,'0','2026-10-19 22:22:33'),('3','2','Beta Ortak','business',NULL,NULL,NULL,'0','2026-10-19 22:22:38');
/*FBEND*/
SET FOREIGN_KEY_CHECKS=1;
/*FBEND*/
/*FBCOUNTS {"accounts":7,"audit_log":207,"budgets":1,"captchas":40,"card_installments":3,"card_purchases":1,"cards":1,"categories":34,"contacts":5,"documents":4,"entries":33,"fx_rates":2,"idempotency_keys":25,"invoice_lines":27,"invoices":24,"loan_installments":12,"loans":1,"login_tickets":10,"password_tokens":2,"payment_allocations":21,"project_milestones":1,"project_quotes":0,"projects":1,"rate_limits":21,"recurring_templates":1,"schema_migrations":4,"sessions":25,"statement_lines":3,"stock_items":8,"stock_movements":12,"system_settings":0,"tenants":2,"transactions":46,"users":3,"warehouses":1,"workspaces":3}*/
