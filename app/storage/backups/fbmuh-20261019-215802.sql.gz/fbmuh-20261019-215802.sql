/*FBMUH BACKUP 20261019-215802*/
SET NAMES utf8mb4;
/*FBEND*/
SET FOREIGN_KEY_CHECKS=0;
/*FBEND*/
DROP TABLE IF EXISTS `accounts`;
/*FBEND*/
CREATE TABLE `accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `kind` enum('bank','cash') NOT NULL DEFAULT 'bank',
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `iban` varchar(40) DEFAULT NULL,
  `opening_minor` bigint(20) NOT NULL DEFAULT 0,
  `opening_date` date NOT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT 0,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ac_t` (`tenant_id`),
  KEY `fk_ac_w` (`workspace_id`),
  CONSTRAINT `fk_ac_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`),
  CONSTRAINT `fk_ac_w` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `accounts` VALUES ('1','1','1',NULL,'Ana Banka TL','bank','Test Bank','TRY',NULL,'5000000','2026-01-01','0','0','2026-10-19 21:57:06'),('2','1','1',NULL,'Kasa TL','cash',NULL,'TRY',NULL,'0','2026-01-01','0','0','2026-10-19 21:57:06'),('3','1','1',NULL,'Banka EUR','bank',NULL,'EUR',NULL,'100000','2026-01-01','0','0','2026-10-19 21:57:06'),('4','1','1',NULL,'Banka USD','bank',NULL,'USD',NULL,'200000','2026-01-01','0','0','2026-10-19 21:57:06'),('5','1','2',NULL,'Şahsi Banka','bank',NULL,'TRY',NULL,'1000000','2026-01-01','0','0','2026-10-19 21:57:06'),('6','1','1',NULL,'IBANlı','bank',NULL,'TRY','TR330006100519786457841326','0','2026-01-01','0','0','2026-10-19 21:57:06'),('7','2','3',NULL,'Beta Banka','bank',NULL,'TRY',NULL,'100','2026-01-01','0','0','2026-10-19 21:57:11');
/*FBEND*/
DROP TABLE IF EXISTS `audit_log`;
/*FBEND*/
CREATE TABLE `audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ts` datetime NOT NULL,
  `actor_user_id` bigint(20) unsigned DEFAULT NULL,
  `actor_role` varchar(20) DEFAULT NULL,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `category` enum('security','admin','data','access','system') NOT NULL,
  `action` varchar(80) NOT NULL,
  `entity` varchar(60) DEFAULT NULL,
  `entity_id` varchar(40) DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `prev_hash` char(64) NOT NULL,
  `hash` char(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_audit_tenant` (`tenant_id`,`id`),
  KEY `ix_audit_cat` (`category`,`id`),
  KEY `ix_audit_actor` (`actor_user_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `audit_log` VALUES ('1','2026-10-19 21:54:33','1','admin',NULL,'admin','admin_created','user','1',NULL,'installer','0000000000000000000000000000000000000000000000000000000000000000','75731172405f67d9018cdb777ed3232a3a11d393853dc460896db57b7425334f'),('2','2026-10-19 21:54:34','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','75731172405f67d9018cdb777ed3232a3a11d393853dc460896db57b7425334f','1af3e7e7a9eaa5b65726c1cf2ab5d4aa2450f2966a9cec65e5cb3d9bd9cd7b3d'),('3','2026-10-19 21:54:34','1','admin',NULL,'security','2fa_enabled',NULL,NULL,NULL,'127.0.0.1','1af3e7e7a9eaa5b65726c1cf2ab5d4aa2450f2966a9cec65e5cb3d9bd9cd7b3d','4c876da69bedf1055603e3a7da74d8c2cb26f58235d162feaf401804b789116f'),('4','2026-10-19 21:54:34','1',NULL,NULL,'security','2fa_failed',NULL,NULL,NULL,'127.0.0.1','4c876da69bedf1055603e3a7da74d8c2cb26f58235d162feaf401804b789116f','032683accd4ee026904ca1093d79764108f9e1e8203b8cb3f39859ed6575949f'),('5','2026-10-19 21:54:34','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','032683accd4ee026904ca1093d79764108f9e1e8203b8cb3f39859ed6575949f','9ac69e25444c3270c4b48fdd20a0a789159fadd9240cff8675d23e2e745ac75d'),('6','2026-10-19 21:55:01','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','9ac69e25444c3270c4b48fdd20a0a789159fadd9240cff8675d23e2e745ac75d','f7483e8d3cd5ba0fbf061df36e50527da7ed88dda2e2f8a46c0c0b9d3bc489c3'),('7','2026-10-19 21:55:32','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','f7483e8d3cd5ba0fbf061df36e50527da7ed88dda2e2f8a46c0c0b9d3bc489c3','16be3acf6aff00ec01999d98d37e4df26bdf10f9dc04dd1e08c097b3f4b20202'),('8','2026-10-19 21:55:32','1','admin',NULL,'security','logout',NULL,NULL,NULL,'127.0.0.1','16be3acf6aff00ec01999d98d37e4df26bdf10f9dc04dd1e08c097b3f4b20202','839cef31b17d87affc49309c7492d40997b081f8d77cf7908bae0936a626538f'),('9','2026-10-19 21:56:02','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','839cef31b17d87affc49309c7492d40997b081f8d77cf7908bae0936a626538f','b89af2b42fb6127ada7bd9675120e560f90a03c13b979773999db9aeb606fc7f'),('10','2026-10-19 21:56:32','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','b89af2b42fb6127ada7bd9675120e560f90a03c13b979773999db9aeb606fc7f','b06c33d8a2445180bd7ed40707981dfc9321ce99f664aac52302e1da63a49409'),('11','2026-10-19 21:57:02','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','b06c33d8a2445180bd7ed40707981dfc9321ce99f664aac52302e1da63a49409','14ae10d1e691719d7a9484dde394403ad0e205dd67b51708de107aefd83c8b2e'),('12','2026-10-19 21:57:03',NULL,NULL,NULL,'security','login_failed',NULL,NULL,'{\"id\":\"bf7af0996800\",\"reason\":\"unknown\"}','127.0.0.1','14ae10d1e691719d7a9484dde394403ad0e205dd67b51708de107aefd83c8b2e','11055e59edfe1e3b29fbaec654643de58304c13e7de719f9471c682654bbe763'),('13','2026-10-19 21:57:03','1','admin','1','admin','tenant_created','tenant','1','{\"mode\":\"invite\",\"email\":\"alfa@test.local\"}','127.0.0.1','11055e59edfe1e3b29fbaec654643de58304c13e7de719f9471c682654bbe763','b734ec42c6f8d531e337e8966c9e6330731f5c0f6c80365d782bcdf0797bb427'),('14','2026-10-19 21:57:03','1','admin','2','admin','tenant_created','tenant','2','{\"mode\":\"temp\",\"email\":\"beta@test.local\"}','127.0.0.1','b734ec42c6f8d531e337e8966c9e6330731f5c0f6c80365d782bcdf0797bb427','a56b2243da9c218dede220024189180cd1600d3ebd7ce3fa2716593d1e38cffb'),('15','2026-10-19 21:57:03','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','a56b2243da9c218dede220024189180cd1600d3ebd7ce3fa2716593d1e38cffb','b18fc3eff1111e1d511eb5e2cb7c5bc77937cf8e7f19ad364d9064eb4ac8da1c'),('16','2026-10-19 21:57:03','3','customer','2','security','password_change_failed',NULL,NULL,NULL,'127.0.0.1','b18fc3eff1111e1d511eb5e2cb7c5bc77937cf8e7f19ad364d9064eb4ac8da1c','53120dfa89c721ea2b98d601787b3f9f34b9d15a67413fa325efa17f6e6551fd'),('17','2026-10-19 21:57:03','3','customer','2','security','password_changed',NULL,NULL,NULL,'127.0.0.1','53120dfa89c721ea2b98d601787b3f9f34b9d15a67413fa325efa17f6e6551fd','9207084309a20a19112770796b6b53422c60e4df0331d91f3d5a5206d8dfe67b'),('18','2026-10-19 21:57:04','2','customer','1','security','invite_accepted',NULL,NULL,NULL,'127.0.0.1','9207084309a20a19112770796b6b53422c60e4df0331d91f3d5a5206d8dfe67b','c99d98d11265003b42b4e0413c73ec3c05b309cc1416de2390555a026680d5dd'),('19','2026-10-19 21:57:04','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','c99d98d11265003b42b4e0413c73ec3c05b309cc1416de2390555a026680d5dd','3474be41df5ef975c8d1c0d94b17178ddba59ed600b03f3526be8f0b112ef7a5'),('20','2026-10-19 21:57:04','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','3474be41df5ef975c8d1c0d94b17178ddba59ed600b03f3526be8f0b112ef7a5','8f22b9e21f27f0b288cc61d616a9232a2ba932ada9d53c13bada03d8887705dd'),('21','2026-10-19 21:57:04','2','customer','1','security','admin_endpoint_denied','route','/admin/overview',NULL,'127.0.0.1','8f22b9e21f27f0b288cc61d616a9232a2ba932ada9d53c13bada03d8887705dd','cefff39285c11eb6f2e31cec84699d8a00ccc7fb113ac151a7ed7ca5f75480fe'),('22','2026-10-19 21:57:04','2','customer','1','security','admin_endpoint_denied','route','/admin/tenants',NULL,'127.0.0.1','cefff39285c11eb6f2e31cec84699d8a00ccc7fb113ac151a7ed7ca5f75480fe','89f9f74ae4d399b3a40992b01ae5d5304f227ca7792201d7db25d85f29a483a7'),('23','2026-10-19 21:57:04','2','customer','1','security','admin_endpoint_denied','route','/admin/tenants',NULL,'127.0.0.1','89f9f74ae4d399b3a40992b01ae5d5304f227ca7792201d7db25d85f29a483a7','137b092a4861d247f60f2c4cb644914ecf3e9467e913b1f4ce335b1d3656c343'),('24','2026-10-19 21:57:04','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','137b092a4861d247f60f2c4cb644914ecf3e9467e913b1f4ce335b1d3656c343','d452b47e971730d5fccbbe2040f720ee1602804a9f23dee3b23bbfadb75760c0'),('25','2026-10-19 21:57:04','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','d452b47e971730d5fccbbe2040f720ee1602804a9f23dee3b23bbfadb75760c0','afc72ce425652de04094b45b292fe4e035e809ced06a2b67ff216a892590a0e9'),('26','2026-10-19 21:57:04','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','afc72ce425652de04094b45b292fe4e035e809ced06a2b67ff216a892590a0e9','c7fb9993694a2884bfc53a6b1bb73006cf5ab46ba7e0e922eaf18cab38c03064'),('27','2026-10-19 21:57:04','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','c7fb9993694a2884bfc53a6b1bb73006cf5ab46ba7e0e922eaf18cab38c03064','c07cf5ac5a16c566d1e443d3cc22eda1d710b779d1ba41809f8cf63acc6af1d7'),('28','2026-10-19 21:57:04','2',NULL,'1','security','account_locked',NULL,NULL,'{\"level\":1}','127.0.0.1','c07cf5ac5a16c566d1e443d3cc22eda1d710b779d1ba41809f8cf63acc6af1d7','0ad7fc76e62c3d2319673447148aee618f39dd61779c998eb33dbf7867fc6c15'),('29','2026-10-19 21:57:04','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','0ad7fc76e62c3d2319673447148aee618f39dd61779c998eb33dbf7867fc6c15','febd1dd52bc4b560e7c84d1945e30595f1f574bc8562e8860b402e79ea0f85d3'),('30','2026-10-19 21:57:04','2',NULL,'1','security','login_locked',NULL,NULL,NULL,'127.0.0.1','febd1dd52bc4b560e7c84d1945e30595f1f574bc8562e8860b402e79ea0f85d3','ba20fc1d7df837f1954a08147748565b98e56674473fccd409b31f2339e7c0f0'),('31','2026-10-19 21:57:04','1','admin','1','admin','tenant_unlocked',NULL,NULL,NULL,'127.0.0.1','ba20fc1d7df837f1954a08147748565b98e56674473fccd409b31f2339e7c0f0','923fcec6a67ad77fb21ea50cf70d64336bb431446bb8c2ab1468a68b979e17a7'),('32','2026-10-19 21:57:05','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','923fcec6a67ad77fb21ea50cf70d64336bb431446bb8c2ab1468a68b979e17a7','1f288c9de88b85e590f145e6b1c3190bb1b505ec159d95444d58824b0088c64f'),('33','2026-10-19 21:57:05','2',NULL,'1','security','password_reset_requested',NULL,NULL,NULL,'127.0.0.1','1f288c9de88b85e590f145e6b1c3190bb1b505ec159d95444d58824b0088c64f','a7daf97f30e973ab90b53b79cfe53d58baf594be10fa4e65d6d530165e01276d'),('34','2026-10-19 21:57:05','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','a7daf97f30e973ab90b53b79cfe53d58baf594be10fa4e65d6d530165e01276d','d9e84e5fd4a83266cc8e18384f76fbbb8cb8521ef3634b6a3c631c2527215c47'),('35','2026-10-19 21:57:05','2','customer','1','security','password_reset_done',NULL,NULL,NULL,'127.0.0.1','d9e84e5fd4a83266cc8e18384f76fbbb8cb8521ef3634b6a3c631c2527215c47','4d3aeb1df101224f4f5f6e61a8423651a57d1db6bd42b9ca47747715b4cbeff1'),('36','2026-10-19 21:57:05','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','4d3aeb1df101224f4f5f6e61a8423651a57d1db6bd42b9ca47747715b4cbeff1','983cc374fbb1b68fe9fef2dfc42ca585d878509d139301fbfb1833657411f2c9'),('37','2026-10-19 21:57:05','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','983cc374fbb1b68fe9fef2dfc42ca585d878509d139301fbfb1833657411f2c9','debaed1e4ad25044162b481792452a980ae8f08655f41a6db2ca5f7bdf3c2850'),('38','2026-10-19 21:57:05','1','admin','2','admin','tenant_status_suspended','tenant','2','{\"from\":\"active\"}','127.0.0.1','debaed1e4ad25044162b481792452a980ae8f08655f41a6db2ca5f7bdf3c2850','ac4ae52224bea3efdde919651b53256fe0a516ad8aa63e087306a8b7e42a6746'),('39','2026-10-19 21:57:05','3',NULL,'2','security','login_blocked_suspended',NULL,NULL,NULL,'127.0.0.1','ac4ae52224bea3efdde919651b53256fe0a516ad8aa63e087306a8b7e42a6746','cd4383fd4caf7f928e964561276527ade7a556eeca878605b018e4f90d4f76b6'),('40','2026-10-19 21:57:05','1','admin','2','admin','tenant_status_active','tenant','2','{\"from\":\"suspended\"}','127.0.0.1','cd4383fd4caf7f928e964561276527ade7a556eeca878605b018e4f90d4f76b6','7f847f5b6bea2a5ef2e08d238be9f3b53ba43182e830a02310f122ed7daa4ad5'),('41','2026-10-19 21:57:05','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','7f847f5b6bea2a5ef2e08d238be9f3b53ba43182e830a02310f122ed7daa4ad5','be6edc1ad628093341b43d0b92174c6e3d91b3138f48ebf25ef73d12fd961583'),('42','2026-10-19 21:57:05','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','be6edc1ad628093341b43d0b92174c6e3d91b3138f48ebf25ef73d12fd961583','0160ffe2464096fcf2cd6acb1ed20321c6d56cbac3f82caada0b59d4a1d40e74'),('43','2026-10-19 21:57:06','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','0160ffe2464096fcf2cd6acb1ed20321c6d56cbac3f82caada0b59d4a1d40e74','e15f908bae6a045202a94d0fb885dfcd93a2c4e27011b281117a0a0301c82c85'),('44','2026-10-19 21:57:06','2','customer','1','data','workspace_created','workspace','1',NULL,'127.0.0.1','e15f908bae6a045202a94d0fb885dfcd93a2c4e27011b281117a0a0301c82c85','dee36b64aaeefd0fbc6ffeedec4b2352775ad7aa54c7f31b0d3dc8db48c7c7df'),('45','2026-10-19 21:57:06','2','customer','1','data','workspace_created','workspace','2',NULL,'127.0.0.1','dee36b64aaeefd0fbc6ffeedec4b2352775ad7aa54c7f31b0d3dc8db48c7c7df','687c91833ffb2461e1be7782379abe7090bd5fb548908927ef048695be4ee441'),('46','2026-10-19 21:57:06','2','customer','1','data','account_created','account','1','{\"opening_minor\":5000000}','127.0.0.1','687c91833ffb2461e1be7782379abe7090bd5fb548908927ef048695be4ee441','edee882678090efc7a14de0969da465f15e12ff1c62c1f1a5118ede1237cb0eb'),('47','2026-10-19 21:57:06','2','customer','1','data','account_created','account','2','{\"opening_minor\":0}','127.0.0.1','edee882678090efc7a14de0969da465f15e12ff1c62c1f1a5118ede1237cb0eb','d7da06110d2c31a94063981f65ed84496a84dc4443a139ca6ec3b92574a5cfda'),('48','2026-10-19 21:57:06','2','customer','1','data','account_created','account','3','{\"opening_minor\":100000}','127.0.0.1','d7da06110d2c31a94063981f65ed84496a84dc4443a139ca6ec3b92574a5cfda','36181ea2e2a280b8e33d96275683d9d6d1596f44bee175cce5cb9a2442b306b6'),('49','2026-10-19 21:57:06','2','customer','1','data','account_created','account','4','{\"opening_minor\":200000}','127.0.0.1','36181ea2e2a280b8e33d96275683d9d6d1596f44bee175cce5cb9a2442b306b6','89bbbc73f50e5e46c203f7e4aecd4b5074564304c805e3e848b2565e7acc9d64'),('50','2026-10-19 21:57:06','2','customer','1','data','account_created','account','5','{\"opening_minor\":1000000}','127.0.0.1','89bbbc73f50e5e46c203f7e4aecd4b5074564304c805e3e848b2565e7acc9d64','64a70444ce691cfed716a47ee9777e4cccf13b243be740721cdf80a99a5f9b2f'),('51','2026-10-19 21:57:06','2','customer','1','data','account_created','account','6','{\"opening_minor\":0}','127.0.0.1','64a70444ce691cfed716a47ee9777e4cccf13b243be740721cdf80a99a5f9b2f','68c8adccfc2fa60dfea9666b7772c4ae23212f03a0819d9fa2134e3db7286eef'),('52','2026-10-19 21:57:06','2','customer','1','data','contact_created','contact','1',NULL,'127.0.0.1','68c8adccfc2fa60dfea9666b7772c4ae23212f03a0819d9fa2134e3db7286eef','3fc3636b5889b50c1cb36e3a68a0ba96866fd246fccf25ae48bd2844231fc230'),('53','2026-10-19 21:57:06','2','customer','1','data','contact_created','contact','2',NULL,'127.0.0.1','3fc3636b5889b50c1cb36e3a68a0ba96866fd246fccf25ae48bd2844231fc230','0c3b368336ccb1fa595fb982763e20c82246fd166a9eed5a6181b3a9f568d784'),('54','2026-10-19 21:57:06','2','customer','1','data','entry_created','entry','1','{\"kind\":\"receivable\",\"amount_minor\":10000000,\"installments\":1}','127.0.0.1','0c3b368336ccb1fa595fb982763e20c82246fd166a9eed5a6181b3a9f568d784','b2bf83c5f99db87f88c81eee435b035c4f7c0313d694026bb379bbb7aa0b86f8'),('55','2026-10-19 21:57:06','2','customer','1','data','collection_created','transaction','1','{\"amount_minor\":6000000,\"contact_id\":1,\"allocations\":{\"1\":6000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','b2bf83c5f99db87f88c81eee435b035c4f7c0313d694026bb379bbb7aa0b86f8','13ab1aca32a8ba623d3c017736b68a613ea11c76b0a71553d90dac03f3d0b80e'),('56','2026-10-19 21:57:06','2','customer','1','data','collection_created','transaction','2','{\"amount_minor\":4000000,\"contact_id\":1,\"allocations\":{\"1\":4000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','13ab1aca32a8ba623d3c017736b68a613ea11c76b0a71553d90dac03f3d0b80e','ae35d952522e1ff06eead3e30308352245b101e53d89936130a3e1d57ce75c76'),('57','2026-10-19 21:57:06','2','customer','1','data','transfer_created','transfer','23ed00896d9c17631ba3793d8d','{\"from\":1,\"to\":2,\"amount_minor\":2000000,\"kind\":\"transfer\"}','127.0.0.1','ae35d952522e1ff06eead3e30308352245b101e53d89936130a3e1d57ce75c76','ef759ec8c2bc1e16a3428f30c20e01519514d6c87004df6df59dfc1f1e964069'),('58','2026-10-19 21:57:06','2','customer','1','data','entry_created','entry','2','{\"kind\":\"payable\",\"amount_minor\":500000,\"installments\":1}','127.0.0.1','ef759ec8c2bc1e16a3428f30c20e01519514d6c87004df6df59dfc1f1e964069','9b28a6949b3a874024ed4cb2bc652cf7281372c41aee5a740bf679de1d47bdb3'),('59','2026-10-19 21:57:07','2','customer','1','data','invoice_created','invoice','1','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":120000,\"due_date\":\"2026-11-04\",\"new_items\":0}','127.0.0.1','9b28a6949b3a874024ed4cb2bc652cf7281372c41aee5a740bf679de1d47bdb3','0ff1829487dea13a3b6a5838507e1e47a1883309bd5a0c744cbd9112cfade203'),('60','2026-10-19 21:57:07','2','customer','1','data','collection_created','transaction','5','{\"amount_minor\":120000,\"contact_id\":1,\"allocations\":{\"5\":120000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','0ff1829487dea13a3b6a5838507e1e47a1883309bd5a0c744cbd9112cfade203','81686fe598dd56a9c16bfc0ae94085dc86f99ba60da056db661aed6638d27a25'),('61','2026-10-19 21:57:07','2','customer','1','data','entry_created','entry','7','{\"kind\":\"receivable\",\"amount_minor\":50000,\"installments\":1}','127.0.0.1','81686fe598dd56a9c16bfc0ae94085dc86f99ba60da056db661aed6638d27a25','6a9a012263cd770b3f35209fc04bb51aeeced6f1c53d71fe664b121a3e6c0c59'),('62','2026-10-19 21:57:07','2','customer','1','data','fx_created','transfer','cf77304c65e5b6d9ca0b7b91da','{\"out\":1000000,\"in\":25000,\"rate\":\"0.02500000\",\"fee\":1500}','127.0.0.1','6a9a012263cd770b3f35209fc04bb51aeeced6f1c53d71fe664b121a3e6c0c59','66d2cb929f15f6577b046fc3f3fa602486efe284bc4417c3910de591a95e1a1a'),('63','2026-10-19 21:57:07','2','customer','1','data','entry_created','entry','8','{\"kind\":\"payable\",\"amount_minor\":1000000,\"installments\":1}','127.0.0.1','66d2cb929f15f6577b046fc3f3fa602486efe284bc4417c3910de591a95e1a1a','ef8077c783281312fd5c00c3a0ab7bdbb04e964848d56d1daf54343e62eeb109'),('64','2026-10-19 21:57:07','2','customer','1','data','payment_created','transaction','9','{\"amount_minor\":300000,\"contact_id\":2,\"allocations\":{\"8\":300000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','ef8077c783281312fd5c00c3a0ab7bdbb04e964848d56d1daf54343e62eeb109','ea94e248f725513f6282ec4dacc4a7107ffeac9b3efa6699f2f097eece899a80'),('65','2026-10-19 21:57:07','2','customer','1','data','entry_rescheduled','entry','8','{\"before\":{\"due_date\":\"2026-10-17\"},\"after\":{\"due_date\":\"2026-10-30\"}}','127.0.0.1','ea94e248f725513f6282ec4dacc4a7107ffeac9b3efa6699f2f097eece899a80','3eff4edb619b85f98dc59738ac1fcb3a27c32fcf5d5fbc7796f03b4be498a7bd'),('66','2026-10-19 21:57:07','2','customer','1','data','card_created','card','1',NULL,'127.0.0.1','3eff4edb619b85f98dc59738ac1fcb3a27c32fcf5d5fbc7796f03b4be498a7bd','5ee09caa30bb88833ee8ec7c141e7b900e9c62bd37e8ccba8ccdfd3e341bff44'),('67','2026-10-19 21:57:08','2','customer','1','data','card_purchase','card_purchase','1','{\"amount_minor\":120000,\"installments\":3}','127.0.0.1','5ee09caa30bb88833ee8ec7c141e7b900e9c62bd37e8ccba8ccdfd3e341bff44','fbe9ba59de9a176632a1f85a44949a53173ad7a619628ce2fa1a357ad29cda18'),('68','2026-10-19 21:57:08','2','customer','1','data','card_payment','card','1','{\"txn\":10,\"amount_minor\":40000}','127.0.0.1','fbe9ba59de9a176632a1f85a44949a53173ad7a619628ce2fa1a357ad29cda18','d4b40eaf8a7a22de816f4e498a3b0da32936e9dab20e51deffaba909b9222318'),('69','2026-10-19 21:57:08','2','customer','1','data','loan_created','loan','1','{\"principal_minor\":12000000,\"term\":12}','127.0.0.1','d4b40eaf8a7a22de816f4e498a3b0da32936e9dab20e51deffaba909b9222318','796ade2c9d0410f55d739a58d4ff994bf6f312613c28f998cb653de94bb7670d'),('70','2026-10-19 21:57:08','2','customer','1','data','loan_payment','loan','1','{\"txn\":12,\"seq\":1}','127.0.0.1','796ade2c9d0410f55d739a58d4ff994bf6f312613c28f998cb653de94bb7670d','06da64034bac1df9165d825bc57587e636416c54986cbbfc804de1c5b7181c13'),('71','2026-10-19 21:57:08','2','customer','1','data','entry_created','entry','9','{\"kind\":\"payable\",\"amount_minor\":80000,\"installments\":1}','127.0.0.1','06da64034bac1df9165d825bc57587e636416c54986cbbfc804de1c5b7181c13','401cb09bfc7ad092995ae8b9945a5cb6ae0a3657a83c8c91573cdebdd73a0604'),('72','2026-10-19 21:57:08','2','customer','1','data','statement_imported','account','1','{\"added\":3,\"duplicates\":0}','127.0.0.1','401cb09bfc7ad092995ae8b9945a5cb6ae0a3657a83c8c91573cdebdd73a0604','5ba5c608c342a178a0af1617599a9b848068af0bc897ac403fc05f5199be4a49'),('73','2026-10-19 21:57:08','2','customer','1','data','statement_imported','account','1','{\"added\":0,\"duplicates\":3}','127.0.0.1','5ba5c608c342a178a0af1617599a9b848068af0bc897ac403fc05f5199be4a49','6a462c2d494808aac4065bc1bf2bd287e61914d75c34e253e8a63259e805d7da'),('74','2026-10-19 21:57:09','2','customer','1','data','statement_line_posted','statement_line','1','{\"txn\":13}','127.0.0.1','6a462c2d494808aac4065bc1bf2bd287e61914d75c34e253e8a63259e805d7da','63905e0a6504d03da367d892b88743ffad14600ce8da33dd9c1e1666f74ed9e5'),('75','2026-10-19 21:57:09','2','customer','1','data','project_created','project','1',NULL,'127.0.0.1','63905e0a6504d03da367d892b88743ffad14600ce8da33dd9c1e1666f74ed9e5','01dc2f9ec094256c0b75cf943ed6fffa2910a063e6493984a4bd848726e2815a'),('76','2026-10-19 21:57:09','2','customer','1','data','invoice_created','invoice','3','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":1200000,\"due_date\":null,\"new_items\":0}','127.0.0.1','01dc2f9ec094256c0b75cf943ed6fffa2910a063e6493984a4bd848726e2815a','654ded113a00662448d01db716cb0960e693e3515e6debb2987a59013a78de62'),('77','2026-10-19 21:57:09','2','customer','1','data','collection_created','transaction','14','{\"amount_minor\":1200000,\"contact_id\":1,\"allocations\":{\"10\":1200000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','654ded113a00662448d01db716cb0960e693e3515e6debb2987a59013a78de62','3a044310bbb2bd303b40fc9cf94651d8844dc3299028dcd916b3d46aec0309dd'),('78','2026-10-19 21:57:09','2','customer','1','data','invoice_created','invoice','4','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":480000,\"due_date\":null,\"new_items\":0}','127.0.0.1','3a044310bbb2bd303b40fc9cf94651d8844dc3299028dcd916b3d46aec0309dd','361942c8bedf1c357eb0c5cd35382b254a86d1086d2768f209a9b9a5c7af1605'),('79','2026-10-19 21:57:09','2','customer','1','data','payment_created','transaction','15','{\"amount_minor\":480000,\"contact_id\":2,\"allocations\":{\"11\":480000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','361942c8bedf1c357eb0c5cd35382b254a86d1086d2768f209a9b9a5c7af1605','da0dc9360747e2cf1f65feda89f3c1bb1d5e229b98332be81b511c90148ffe0f'),('80','2026-10-19 21:57:09','2','customer','1','data','transaction_created','transaction','16','{\"kind\":\"expense\",\"amount_minor\":50000,\"replaces\":null}','127.0.0.1','da0dc9360747e2cf1f65feda89f3c1bb1d5e229b98332be81b511c90148ffe0f','724d2f2c3b789c6ae22aa2c62f2669a43bdd363acc1a0e9055135f57fa36b142'),('81','2026-10-19 21:57:09','2','customer','1','data','invoice_created','invoice','5','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":120000,\"due_date\":null,\"new_items\":0}','127.0.0.1','724d2f2c3b789c6ae22aa2c62f2669a43bdd363acc1a0e9055135f57fa36b142','90c850450b63833c62fb519d424bb1ecf87662493df8a00564d5917c31aa8573'),('82','2026-10-19 21:57:09','2','customer','1','data','stock_movement','stock_movement','2','{\"kind\":\"out\",\"qty_milli\":2000}','127.0.0.1','90c850450b63833c62fb519d424bb1ecf87662493df8a00564d5917c31aa8573','5180017a574c01846dcdbc0d34d103cadf4121cb64548a090951fda72c022c1b'),('83','2026-10-19 21:57:09','2','customer','1','data','settings_changed',NULL,NULL,NULL,'127.0.0.1','5180017a574c01846dcdbc0d34d103cadf4121cb64548a090951fda72c022c1b','0d7c082a7b5098e5571f6c1ae450ec30f59f3d50dc4dc4b691a5b58f5eedf518'),('84','2026-10-19 21:57:09','2','customer','1','data','stock_movement','stock_movement','3','{\"kind\":\"out\",\"qty_milli\":9000}','127.0.0.1','0d7c082a7b5098e5571f6c1ae450ec30f59f3d50dc4dc4b691a5b58f5eedf518','bb003f02a65f8daa87cf0503d14b1aa143e9c4a88a959ed46191460cc3aabd2c'),('85','2026-10-19 21:57:09','2','customer','1','data','settings_changed',NULL,NULL,NULL,'127.0.0.1','bb003f02a65f8daa87cf0503d14b1aa143e9c4a88a959ed46191460cc3aabd2c','58e3e074c6a66f84a6020635a1b3cbce57cd04db1309aad85538cd7bc7e2f2a9'),('86','2026-10-19 21:57:09','2','customer','1','data','transaction_created','transaction','17','{\"kind\":\"income\",\"amount_minor\":100000,\"replaces\":null}','127.0.0.1','58e3e074c6a66f84a6020635a1b3cbce57cd04db1309aad85538cd7bc7e2f2a9','68d815a067a819e522b01146974e5ccbc5f2e9320e40a70d2ba1bf1d8ef3935e'),('87','2026-10-19 21:57:09','2','customer','1','data','transaction_voided','transaction','17','{\"reason\":\"Hatalı giriş\",\"before\":{\"kind\":\"income\",\"amount_minor\":100000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[17]}','127.0.0.1','68d815a067a819e522b01146974e5ccbc5f2e9320e40a70d2ba1bf1d8ef3935e','c061c9ec6774af1c9555953f658b6b42bc3380f56c83b2a69fcebd92568a0e18'),('88','2026-10-19 21:57:10','2','customer','1','data','transaction_created','transaction','18','{\"kind\":\"expense\",\"amount_minor\":10000,\"replaces\":null}','127.0.0.1','c061c9ec6774af1c9555953f658b6b42bc3380f56c83b2a69fcebd92568a0e18','a817e30cbdc90f8f423a8b771befd0c2b9a202eb838fa0ceb12c5c6a98a6bee7'),('89','2026-10-19 21:57:10','2','customer','1','data','transaction_voided','transaction','18','{\"reason\":\"Düzenleme ile yenisi oluşturuldu\",\"before\":{\"kind\":\"expense\",\"amount_minor\":10000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[18]}','127.0.0.1','a817e30cbdc90f8f423a8b771befd0c2b9a202eb838fa0ceb12c5c6a98a6bee7','806773d30cf8fa86655eabb4d876bc3179bf99ff5c6dba800dfdb9023a4ca8e0'),('90','2026-10-19 21:57:10','2','customer','1','data','transaction_replaced','transaction','19','{\"kind\":\"expense\",\"amount_minor\":12000,\"replaces\":18}','127.0.0.1','806773d30cf8fa86655eabb4d876bc3179bf99ff5c6dba800dfdb9023a4ca8e0','bbcde09b0fb4ab9e19c84d43be456de45bdd093fffd671872bccc1167570430c'),('91','2026-10-19 21:57:10','2','customer','1','data','transaction_created','transaction','20','{\"kind\":\"expense\",\"amount_minor\":120000,\"replaces\":null}','127.0.0.1','bbcde09b0fb4ab9e19c84d43be456de45bdd093fffd671872bccc1167570430c','fc537e7240d1088e284646ae8a63f41b40b8401737f573246d59617a7b811b9e'),('92','2026-10-19 21:57:10','2','customer','1','data','transaction_created','transaction','21','{\"kind\":\"expense\",\"amount_minor\":120000,\"replaces\":null}','127.0.0.1','fc537e7240d1088e284646ae8a63f41b40b8401737f573246d59617a7b811b9e','c66c39080cced66a88ac80151f1b7f589ae1c6e31e54e4908da398cc21a32a09'),('93','2026-10-19 21:57:10','2','customer','1','data','balance_adjusted','account','2','{\"delta_minor\":-5000,\"reason\":\"Sayım farkı\"}','127.0.0.1','c66c39080cced66a88ac80151f1b7f589ae1c6e31e54e4908da398cc21a32a09','b32a21717f5947724200028d3efd32bbb37d665290fa779fe5421b7f462abf3f'),('94','2026-10-19 21:57:11','3','customer','2','data','workspace_created','workspace','3',NULL,'127.0.0.1','b32a21717f5947724200028d3efd32bbb37d665290fa779fe5421b7f462abf3f','0a1e8be4419f9beabd0547a143059a2acee212cc44f5c51e3a07cfe0b7eacb8f'),('95','2026-10-19 21:57:11','3','customer','2','data','account_created','account','7','{\"opening_minor\":100}','127.0.0.1','0a1e8be4419f9beabd0547a143059a2acee212cc44f5c51e3a07cfe0b7eacb8f','42cff181be0d489d9e12b54029344847153c4af72f235da614f79edd6f7a4e10'),('96','2026-10-19 21:57:11','2','customer','1','data','document_uploaded','transaction','18','{\"doc\":1,\"size\":70}','127.0.0.1','42cff181be0d489d9e12b54029344847153c4af72f235da614f79edd6f7a4e10','8901050335413c5ed97e4a885c8efb66f61fcd776cf59682b569969d734db825'),('97','2026-10-19 21:57:11','2','customer','1','data','export_transactions',NULL,NULL,'{\"format\":\"csv\",\"rows\":20}','127.0.0.1','8901050335413c5ed97e4a885c8efb66f61fcd776cf59682b569969d734db825','ba0fabc523e83f27197739dac8f0cc6531a327fbeeaded2aec41eac4084e29bd'),('98','2026-10-19 21:57:11','2','customer','1','data','transaction_created','transaction','23','{\"kind\":\"expense\",\"amount_minor\":100,\"replaces\":null}','127.0.0.1','ba0fabc523e83f27197739dac8f0cc6531a327fbeeaded2aec41eac4084e29bd','708d57f5e1b2e107e846fa0bf464b1c41d5dc47db753d34461e3d121104378d1'),('99','2026-10-19 21:57:11','2','customer','1','data','export_transactions',NULL,NULL,'{\"format\":\"csv\",\"rows\":21}','127.0.0.1','708d57f5e1b2e107e846fa0bf464b1c41d5dc47db753d34461e3d121104378d1','d8995e9b141716eea15652732aeb08db0abd25a9b7683cb805c9c1381478dd88'),('100','2026-10-19 21:57:11','2','customer','1','data','export_income-expense',NULL,NULL,'{\"format\":\"xlsx\",\"rows\":1}','127.0.0.1','d8995e9b141716eea15652732aeb08db0abd25a9b7683cb805c9c1381478dd88','c4db1d7dc5d4f98acdfa1d678bbd6cc8ea91f9c51dd45dbac70579afef0759be'),('101','2026-10-19 21:57:11','2','customer','1','data','export_vat',NULL,NULL,'{\"format\":\"csv\",\"rows\":4}','127.0.0.1','c4db1d7dc5d4f98acdfa1d678bbd6cc8ea91f9c51dd45dbac70579afef0759be','d896276789ef87de67b51e72cf2b8f8a02665793d89a64145ae59f4ccc59758e'),('102','2026-10-19 21:57:11','2','customer','1','data','tenant_data_export',NULL,NULL,NULL,'127.0.0.1','d896276789ef87de67b51e72cf2b8f8a02665793d89a64145ae59f4ccc59758e','2e4896e7620d7120e35b705e4a9d43ac11c44c2da3ab3fafccc83231adb85025'),('103','2026-10-19 21:57:11','2','customer','1','data','settings_changed',NULL,NULL,NULL,'127.0.0.1','2e4896e7620d7120e35b705e4a9d43ac11c44c2da3ab3fafccc83231adb85025','da9d5caaedc3a07e129d13a8321d3160ee637b7212223a6fe14c83d9d9a8bba3'),('104','2026-10-19 21:57:30','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','da9d5caaedc3a07e129d13a8321d3160ee637b7212223a6fe14c83d9d9a8bba3','f639d15a91faf2567d5bf961a9c54e17a1c597a35e9ee421f41f2f8647c417bf'),('105','2026-10-19 21:57:30','1','admin','1','access','admin_view_tenant_data','accounts',NULL,NULL,'127.0.0.1','f639d15a91faf2567d5bf961a9c54e17a1c597a35e9ee421f41f2f8647c417bf','376490928a8b3a7ddae6597d15861a2fc5781dddac8f23aee497a1260ddea213'),('106','2026-10-19 21:57:30','1','admin','1','access','admin_view_tenant_data','transactions',NULL,NULL,'127.0.0.1','376490928a8b3a7ddae6597d15861a2fc5781dddac8f23aee497a1260ddea213','ad22fa3ab1af26684cf463a96189a106e196ad0d0161e4900bc6817b048a2095'),('107','2026-10-19 21:57:30','1','admin','1','access','admin_view_tenant_data','reports',NULL,NULL,'127.0.0.1','ad22fa3ab1af26684cf463a96189a106e196ad0d0161e4900bc6817b048a2095','ed44d0d2e089190332a0ae26a541324403f4dc4444f4a97fc6e884dd48dc3982'),('108','2026-10-19 21:57:30','2','customer','1','data','transaction_created','transaction','24','{\"kind\":\"expense\",\"amount_minor\":7700,\"replaces\":null}','127.0.0.1','ed44d0d2e089190332a0ae26a541324403f4dc4444f4a97fc6e884dd48dc3982','1d3896ad75a686b738e735b09408f49a7156f8d90a937926cb48d9b74a58450c'),('109','2026-10-19 21:57:30','1','admin','1','data','transaction_voided','transaction','24','{\"reason\":\"[Yönetici düzeltmesi] Mükerrer giriş\",\"before\":{\"kind\":\"expense\",\"amount_minor\":7700,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[24]}','127.0.0.1','1d3896ad75a686b738e735b09408f49a7156f8d90a937926cb48d9b74a58450c','9afe48adba9795bdfbd9ac317fe9a752fdc8ea0b0f4b6256d56cfe9fb2f32525'),('110','2026-10-19 21:57:30','1','admin','1','admin','admin_correction_void','transaction','24','{\"reason\":\"Mükerrer giriş\",\"legs\":[24]}','127.0.0.1','9afe48adba9795bdfbd9ac317fe9a752fdc8ea0b0f4b6256d56cfe9fb2f32525','3c857118c6c25b78f3dfc330ede99ebbba30313fceb0baa9fd2de51a7bfc40b3'),('111','2026-10-19 21:57:30','1','admin','1','admin','tenant_status_archived','tenant','1','{\"from\":\"active\"}','127.0.0.1','3c857118c6c25b78f3dfc330ede99ebbba30313fceb0baa9fd2de51a7bfc40b3','e248b754d4688a4453511a9a1cb5d40a865fa02f9fe17319821fdef1b645832f'),('112','2026-10-19 21:57:30','1','admin','1','admin','tenant_status_active','tenant','1','{\"from\":\"archived\"}','127.0.0.1','e248b754d4688a4453511a9a1cb5d40a865fa02f9fe17319821fdef1b645832f','afeafc4f8da1b8e1dbf689dbd2308b852e16170b686623efe6f2827939c982e6'),('113','2026-10-19 21:57:30','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','afeafc4f8da1b8e1dbf689dbd2308b852e16170b686623efe6f2827939c982e6','d6e2517094d426621e41d1337bbddfc25dc39796ff2cc52f7f5ec2840b701deb'),('114','2026-10-19 21:57:30','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','d6e2517094d426621e41d1337bbddfc25dc39796ff2cc52f7f5ec2840b701deb','1668d6a27e4e83810b2f00485a21b51ce983e36c7d1d157f3eb8b851635c8edb'),('115','2026-10-19 21:57:30','2','customer','1','data','invoice_created','invoice','6','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":100000,\"due_date\":null,\"new_items\":0}','127.0.0.1','1668d6a27e4e83810b2f00485a21b51ce983e36c7d1d157f3eb8b851635c8edb','b8a254422cb1dd5ca7b28fa4c87c62aada9bda288a1fcd021c0aff1bca43ebf5'),('116','2026-10-19 21:57:31','2','customer','1','data','invoice_created','invoice','7','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"new_items\":0}','127.0.0.1','b8a254422cb1dd5ca7b28fa4c87c62aada9bda288a1fcd021c0aff1bca43ebf5','387296b9ecb133322307ca0f811988fa3f75a59cb40fc2d8b0ab011bc3685bb5'),('117','2026-10-19 21:57:31','2','customer','1','data','invoice_created','invoice','8','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":50000,\"due_date\":\"2026-12-04\",\"new_items\":0}','127.0.0.1','387296b9ecb133322307ca0f811988fa3f75a59cb40fc2d8b0ab011bc3685bb5','e814c13fe91d97ab4f8541516dfbbbd196e46b3b92be0d57dcd135d284c711a2'),('118','2026-10-19 21:57:31','2','customer','1','data','invoice_updated','invoice','7','{\"before\":{\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"lines\":1},\"after\":{\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"lines\":1}}','127.0.0.1','e814c13fe91d97ab4f8541516dfbbbd196e46b3b92be0d57dcd135d284c711a2','84d58b73ef6c25da892cadd97cf804f1180673467a6e9639e6e0ff835ff3670b'),('119','2026-10-19 21:57:31','2','customer','1','data','invoice_updated','invoice','7','{\"before\":{\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"lines\":1},\"after\":{\"total_minor\":50000,\"due_date\":null,\"lines\":1}}','127.0.0.1','84d58b73ef6c25da892cadd97cf804f1180673467a6e9639e6e0ff835ff3670b','3bd735a425b64dffe373bd8311d62539a9cac99fed4c70628104487c74f6ca03'),('120','2026-10-19 21:57:31','2','customer','1','data','entry_rescheduled','entry','15','{\"before\":{\"due_date\":null},\"after\":{\"due_date\":\"2026-10-30\"}}','127.0.0.1','3bd735a425b64dffe373bd8311d62539a9cac99fed4c70628104487c74f6ca03','16e1909b9989f2d005ae7ad0dbf95de8560256d933e30abe48e8c6e99c0540f6'),('121','2026-10-19 21:57:31','2','customer','1','data','invoice_created','invoice','9','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','16e1909b9989f2d005ae7ad0dbf95de8560256d933e30abe48e8c6e99c0540f6','d08f59a5dd587ca20e584d69235cc71a82c0d0bc6b3ccae15427d730860f4ed0'),('122','2026-10-19 21:57:31','2','customer','1','data','payment_created','transaction','25','{\"amount_minor\":400000,\"contact_id\":2,\"allocations\":{\"17\":400000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','d08f59a5dd587ca20e584d69235cc71a82c0d0bc6b3ccae15427d730860f4ed0','446efcaa0e91534e029c601c9d3fcc33a9384e85bea4254dd402acdb84ff72d9'),('123','2026-10-19 21:57:31','2','customer','1','data','payment_created','transaction','26','{\"amount_minor\":600000,\"contact_id\":2,\"allocations\":{\"17\":600000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','446efcaa0e91534e029c601c9d3fcc33a9384e85bea4254dd402acdb84ff72d9','2acaea75f53cc6b31d8f1cbde9d915d94ec460e6927137e0be8bebed88869a86'),('124','2026-10-19 21:57:31','2','customer','1','data','invoice_created','invoice','10','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','2acaea75f53cc6b31d8f1cbde9d915d94ec460e6927137e0be8bebed88869a86','b154f55b55a294191b938e66b575781cbbb55910d8a08a43be3183515e17c941'),('125','2026-10-19 21:57:32','2','customer','1','data','payment_created','transaction','27','{\"amount_minor\":3000000,\"contact_id\":2,\"allocations\":{\"18\":1000000},\"unallocated_minor\":2000000,\"for_workspace_id\":null}','127.0.0.1','b154f55b55a294191b938e66b575781cbbb55910d8a08a43be3183515e17c941','4143feedd2b5e6945223385ac556b90bae6732a00510827b0669c9a6645cd43e'),('126','2026-10-19 21:57:32','2','customer','1','data','invoice_created','invoice','11','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','4143feedd2b5e6945223385ac556b90bae6732a00510827b0669c9a6645cd43e','f51047d6ccb92b5fa29b50c1b7a84940654793e6c540a992d26973d803e159ba'),('127','2026-10-19 21:57:32','2','customer','1','data','invoice_created','invoice','12','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":6000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','f51047d6ccb92b5fa29b50c1b7a84940654793e6c540a992d26973d803e159ba','b4fc2bdfb6597c7c4df382a7841d88075a01a98647b76923b4332551fe607495'),('128','2026-10-19 21:57:32','2','customer','1','data','invoice_created','invoice','13','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":4500000,\"due_date\":null,\"new_items\":0}','127.0.0.1','b4fc2bdfb6597c7c4df382a7841d88075a01a98647b76923b4332551fe607495','0285769be2cd5fe871216349087c4301fde5c7529b9a9179ac9888d4d32b06cc'),('129','2026-10-19 21:57:32','2','customer','1','data','payment_created','transaction','28','{\"amount_minor\":5000000,\"contact_id\":2,\"allocations\":{\"19\":1000000,\"20\":4000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','0285769be2cd5fe871216349087c4301fde5c7529b9a9179ac9888d4d32b06cc','ca9b4156267cbdec54917ba4c07db61329a2bd9ebbdb222fc668f2cc5ea90406'),('130','2026-10-19 21:57:32','2','customer','1','data','payment_allocated','transaction','27','{\"new_minor\":2000000,\"allocated_minor\":3000000,\"unallocated_minor\":0}','127.0.0.1','ca9b4156267cbdec54917ba4c07db61329a2bd9ebbdb222fc668f2cc5ea90406','ddaec95e2c6cde94eb139be60bcf79d0197ab612882be9739bc91890376a6d80'),('131','2026-10-19 21:57:32','2','customer','1','data','allocation_reversed','transaction','27','{\"entry_id\":21,\"amount_minor\":2000000}','127.0.0.1','ddaec95e2c6cde94eb139be60bcf79d0197ab612882be9739bc91890376a6d80','2d7eac23e966c0a6ab5961f9ec797a2f8e445b4ad9af55a890534417349ed32c'),('132','2026-10-19 21:57:32','2','customer','1','data','allocations_replaced','transaction','27','{\"new_minor\":2000000,\"allocated_minor\":2000000,\"unallocated_minor\":1000000}','127.0.0.1','2d7eac23e966c0a6ab5961f9ec797a2f8e445b4ad9af55a890534417349ed32c','d2f6797bb97e050e32773f7e10bb734c8f837cf6c8c73da2bb9b875adc25536f'),('133','2026-10-19 21:57:33','2','customer','1','data','payment_created','transaction','29','{\"amount_minor\":10000,\"contact_id\":2,\"allocations\":[],\"unallocated_minor\":10000,\"for_workspace_id\":null}','127.0.0.1','d2f6797bb97e050e32773f7e10bb734c8f837cf6c8c73da2bb9b875adc25536f','2a423a82e2c12e073765eb9811820d17e5781157e43b2999f01e3a9809807c3a'),('134','2026-10-19 21:57:33','2','customer','1','data','payment_created','transaction','30','{\"amount_minor\":7000,\"contact_id\":2,\"allocations\":[],\"unallocated_minor\":7000,\"for_workspace_id\":null}','127.0.0.1','2a423a82e2c12e073765eb9811820d17e5781157e43b2999f01e3a9809807c3a','9fbf5bd5e66011fc1a573b4eb55da9b696029da1c97695f728fd57163ff95098'),('135','2026-10-19 21:57:33','2','customer','1','data','payment_created','transaction','31','{\"amount_minor\":7000,\"contact_id\":2,\"allocations\":[],\"unallocated_minor\":7000,\"for_workspace_id\":null}','127.0.0.1','9fbf5bd5e66011fc1a573b4eb55da9b696029da1c97695f728fd57163ff95098','1cec284a48b8231d67c33fd75752565cfb32b856cedfa338776b942f8d7d6ca0'),('136','2026-10-19 21:57:33','2','customer','1','data','invoice_created','invoice','14','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":500000,\"due_date\":null,\"new_items\":0}','127.0.0.1','1cec284a48b8231d67c33fd75752565cfb32b856cedfa338776b942f8d7d6ca0','10d278a9c343cc987ff351249f0663dc568cb6a81f368c16ac58dbc4e3cff130'),('137','2026-10-19 21:57:33','2','customer','1','data','collection_created','transaction','32','{\"amount_minor\":800000,\"contact_id\":1,\"allocations\":{\"22\":500000},\"unallocated_minor\":300000,\"for_workspace_id\":null}','127.0.0.1','10d278a9c343cc987ff351249f0663dc568cb6a81f368c16ac58dbc4e3cff130','33da47dee3bc3579c83f238e67d7085a0d82c737aa0d6bd381a413b87d0540c1'),('138','2026-10-19 21:57:33','2','customer','1','data','transaction_voided','transaction','28','{\"reason\":\"test iptal\",\"before\":{\"kind\":\"payment\",\"amount_minor\":5000000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[28]}','127.0.0.1','33da47dee3bc3579c83f238e67d7085a0d82c737aa0d6bd381a413b87d0540c1','8055ceff6726acde8d9271ac38fbda8bb91d8a04a4dfac4f5be54461fc51212c'),('139','2026-10-19 21:57:33','2','customer','1','data','stock_item_autocreated','stock_item','2','{\"name\":\"Buzdolabı T4\",\"kind\":\"product\"}','127.0.0.1','8055ceff6726acde8d9271ac38fbda8bb91d8a04a4dfac4f5be54461fc51212c','86c7c4cbde00480f5dccc4eb5f111db6663a2d3dc024d8b0fb3d61f3d8b87032'),('140','2026-10-19 21:57:33','2','customer','1','data','stock_item_autocreated','stock_item','3','{\"name\":\"Televizyon T4\",\"kind\":\"product\"}','127.0.0.1','86c7c4cbde00480f5dccc4eb5f111db6663a2d3dc024d8b0fb3d61f3d8b87032','f20a7f1df371c62d2601e3c7c64881729dd0a9676b359372d3cf8f849172de90'),('141','2026-10-19 21:57:33','2','customer','1','data','stock_item_autocreated','stock_item','4','{\"name\":\"Nakliye T4\",\"kind\":\"service\"}','127.0.0.1','f20a7f1df371c62d2601e3c7c64881729dd0a9676b359372d3cf8f849172de90','a0bfb5e237f2d2b97e88f1114b56ba2ce777964cc5b6ed3b9928ef50e32e59cb'),('142','2026-10-19 21:57:33','2','customer','1','data','invoice_created','invoice','15','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":7990000,\"due_date\":null,\"new_items\":3}','127.0.0.1','a0bfb5e237f2d2b97e88f1114b56ba2ce777964cc5b6ed3b9928ef50e32e59cb','0e4a083a29849b2fb038c8fd8505ca864bf83d0cce0bc63b360743a1eb2010ff'),('143','2026-10-19 21:57:34','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":7990000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":7990000,\"due_date\":null,\"lines\":4}}','127.0.0.1','0e4a083a29849b2fb038c8fd8505ca864bf83d0cce0bc63b360743a1eb2010ff','fa740b8f2ca2f2f2ae7b28d6c578ef03ac1cb1e384fa6cf3fca668655008e325'),('144','2026-10-19 21:57:34','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":7990000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4}}','127.0.0.1','fa740b8f2ca2f2f2ae7b28d6c578ef03ac1cb1e384fa6cf3fca668655008e325','5b39294425336278bdc4bf36f9133559fe090e2dcdd7e1c21bf767c7a34e767c'),('145','2026-10-19 21:57:34','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4}}','127.0.0.1','5b39294425336278bdc4bf36f9133559fe090e2dcdd7e1c21bf767c7a34e767c','c7d8bc6da3c659add8ba6ec6e49d2c31c168f8fe238e3ef85d307ca860a2ac47'),('146','2026-10-19 21:57:34','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":5590000,\"due_date\":null,\"lines\":4}}','127.0.0.1','c7d8bc6da3c659add8ba6ec6e49d2c31c168f8fe238e3ef85d307ca860a2ac47','3602652988c67197d0d2e2d3a0dc6097d0f9403fd19925c8b54e46f8dc342828'),('147','2026-10-19 21:57:34','2','customer','1','data','invoice_created','invoice','16','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','3602652988c67197d0d2e2d3a0dc6097d0f9403fd19925c8b54e46f8dc342828','4864f105feb2a11480e1a341475a4a9ece7df09144a8dd7e5d2b5953f4aa5cfe'),('148','2026-10-19 21:57:34','2','customer','1','data','stock_item_autocreated','stock_item','5','{\"name\":\"Stoksuz giriş\",\"kind\":\"product\"}','127.0.0.1','4864f105feb2a11480e1a341475a4a9ece7df09144a8dd7e5d2b5953f4aa5cfe','ee6e4bc3be5247dfeb91753e1b8b9bb9a9667fafbe3c1829a28e98a55898f67e'),('149','2026-10-19 21:57:34','2','customer','1','data','invoice_created','invoice','17','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":4000,\"due_date\":null,\"new_items\":1}','127.0.0.1','ee6e4bc3be5247dfeb91753e1b8b9bb9a9667fafbe3c1829a28e98a55898f67e','a1821f5a71f898d89feeb286b8a823009daea56e0a9f019c8e95dfafb4eedb08'),('151','2026-10-19 21:57:34','2','customer','1','data','stock_item_autocreated','stock_item','7','{\"name\":\"Idem\",\"kind\":\"product\"}','127.0.0.1','a1821f5a71f898d89feeb286b8a823009daea56e0a9f019c8e95dfafb4eedb08','2642df81a1e2c5946faa2f634acc64edf20cfdfd8923c81514a0681318529e2d'),('152','2026-10-19 21:57:34','2','customer','1','data','invoice_created','invoice','19','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":100,\"due_date\":null,\"new_items\":1}','127.0.0.1','2642df81a1e2c5946faa2f634acc64edf20cfdfd8923c81514a0681318529e2d','f735bcede1e2a289d30e3e17d193d89d7a5d3649ada6b78d4b93d3456896dba1'),('153','2026-10-19 21:57:34','2','customer','1','data','invoice_created','invoice','20','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":4500000,\"due_date\":null,\"new_items\":0}','127.0.0.1','f735bcede1e2a289d30e3e17d193d89d7a5d3649ada6b78d4b93d3456896dba1','6431db264c1db401da34b71c2b85faab7cb897aa06665aa1cbd276632004c5c0'),('154','2026-10-19 21:57:35','2','customer','1','data','invoice_cancelled','invoice','20','{\"reason\":\"müşteri vazgeçti\",\"total_minor\":4500000,\"was\":\"issued\"}','127.0.0.1','6431db264c1db401da34b71c2b85faab7cb897aa06665aa1cbd276632004c5c0','60d7e6dfb340da872e02243798f85d2bacee3005d4fc9bd177a2f2704dc542fe'),('155','2026-10-19 21:57:35','2','customer','1','data','stock_item_autocreated','stock_item','8','{\"name\":\"Silinecek\",\"kind\":\"product\"}','127.0.0.1','60d7e6dfb340da872e02243798f85d2bacee3005d4fc9bd177a2f2704dc542fe','ffa34e38237673a596eec4f3e573980133858a2b44cb582edc88cbbf4f24bd06'),('156','2026-10-19 21:57:35','2','customer','1','data','invoice_created','invoice','21','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":200,\"due_date\":null,\"new_items\":1}','127.0.0.1','ffa34e38237673a596eec4f3e573980133858a2b44cb582edc88cbbf4f24bd06','6d6c2e8135fad436eae7ef6be85b56c2d4cc33e2abf15967338151e6512e660e'),('157','2026-10-19 21:57:35','2','customer','1','data','invoice_deleted','invoice','21','{\"snapshot\":{\"kind\":\"purchase\",\"number\":\"T4-DEL\",\"contact_id\":2,\"issue_date\":\"2026-10-20\",\"due_date\":null,\"currency\":\"TRY\",\"status\":\"issued\",\"total_minor\":200}}','127.0.0.1','6d6c2e8135fad436eae7ef6be85b56c2d4cc33e2abf15967338151e6512e660e','4fcad52fd9ae938e46207cc909743ca454c0013aa84cc8ae94151a5d0d8c48a0'),('158','2026-10-19 21:57:35','2','customer','1','data','invoice_updated','invoice','9','{\"before\":{\"total_minor\":1000000,\"due_date\":null,\"lines\":1},\"after\":{\"total_minor\":1200000,\"due_date\":null,\"lines\":1}}','127.0.0.1','4fcad52fd9ae938e46207cc909743ca454c0013aa84cc8ae94151a5d0d8c48a0','fd0ddfc3567e2057dc87057ab304a49bb8aa3a7477cc638ecff5d704c3dc6132'),('159','2026-10-19 21:57:35','2','customer','1','data','invoice_created','invoice','22','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":50000,\"due_date\":null,\"new_items\":0}','127.0.0.1','fd0ddfc3567e2057dc87057ab304a49bb8aa3a7477cc638ecff5d704c3dc6132','d7562c5bbc67d1db999c0a24ead5c05ee5a31ad2be6310d0df25d27ffc430a32'),('160','2026-10-19 21:57:35','2','customer','1','data','collection_created','transaction','33','{\"amount_minor\":50000,\"contact_id\":1,\"allocations\":{\"29\":50000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','d7562c5bbc67d1db999c0a24ead5c05ee5a31ad2be6310d0df25d27ffc430a32','f232053966b211ed46a0996bea19f1a2065f9a4c71f46771bcadf8a4201d7a23'),('161','2026-10-19 21:57:35','2','customer','1','data','invoice_created','invoice','23','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":30000,\"due_date\":null,\"new_items\":0}','127.0.0.1','f232053966b211ed46a0996bea19f1a2065f9a4c71f46771bcadf8a4201d7a23','65c42e095edbb13d81b50e34a35e71f77ec94fabe816fe1d1fda8f40a333144b'),('162','2026-10-19 21:57:35','2','customer','1','data','invoice_delivery','invoice','22','{\"lines\":1,\"date\":\"2026-10-20\"}','127.0.0.1','65c42e095edbb13d81b50e34a35e71f77ec94fabe816fe1d1fda8f40a333144b','e481f65fcb2f9952c39f5ce22c7d77d03ab084b8b58c929a5aa595e2cc561d50'),('163','2026-10-19 21:57:35','2','customer','1','data','invoice_created','invoice','24','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":2000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','e481f65fcb2f9952c39f5ce22c7d77d03ab084b8b58c929a5aa595e2cc561d50','17301cbacfe0d2ab5becf1a7d2eb4afd74bfc8a624b73af8ffd83274621fbbff'),('164','2026-10-19 21:57:36','2','customer','1','data','payment_created','transaction','34','{\"amount_minor\":2000000,\"contact_id\":2,\"allocations\":{\"31\":2000000},\"unallocated_minor\":0,\"for_workspace_id\":1}','127.0.0.1','17301cbacfe0d2ab5becf1a7d2eb4afd74bfc8a624b73af8ffd83274621fbbff','1df20771c2d1f8e623097deb26db32ce8943214a3351ea5e9c6b8800e4603d06'),('165','2026-10-19 21:57:36','2','customer','1','data','transaction_meta_updated','transaction','34','{\"before\":{\"description\":\"Şahsi hesaptan ödendi, dekont sonra eklenecek\",\"reason\":\"ABC müşterisi siparişi malzeme alımı\"},\"after\":{\"description\":\"dekont eklendi\",\"reason\":\"Güncel neden\"}}','127.0.0.1','1df20771c2d1f8e623097deb26db32ce8943214a3351ea5e9c6b8800e4603d06','2cb256646aa6ead23d39803a933383dc0ec97abf16789182bb9328182d69e36a'),('166','2026-10-19 21:57:36','2','customer','1','data','transfer_created','transfer','85572d4e6f3f01ce7b11a238da','{\"from\":5,\"to\":1,\"amount_minor\":700000,\"kind\":\"owner_in\"}','127.0.0.1','2cb256646aa6ead23d39803a933383dc0ec97abf16789182bb9328182d69e36a','7975a4fd8587c93cac35dad2689e0c09807378f87a198e16adeb56f52e0d26c7'),('167','2026-10-19 21:57:36','2','customer','1','data','transfer_created','transfer','a03bf7b9c2ed483901effa0c81','{\"from\":1,\"to\":5,\"amount_minor\":2700000,\"kind\":\"owner_out\"}','127.0.0.1','7975a4fd8587c93cac35dad2689e0c09807378f87a198e16adeb56f52e0d26c7','96a393002d8309b22cdf68425f1ef3388b1d49b3c056bd830769c21765f84545'),('168','2026-10-19 21:57:36','2','customer','1','data','transfer_created','transfer','815b58ee04451887fbe0cc17b8','{\"from\":1,\"to\":2,\"amount_minor\":1000,\"kind\":\"transfer\"}','127.0.0.1','96a393002d8309b22cdf68425f1ef3388b1d49b3c056bd830769c21765f84545','6528b578ea8d5f822f85e580af8719a9051e47ecf5dd19f595d96489928dcafa'),('169','2026-10-19 21:57:36','2','customer','1','data','account_created','account','8','{\"opening_minor\":0}','127.0.0.1','6528b578ea8d5f822f85e580af8719a9051e47ecf5dd19f595d96489928dcafa','6ac54266effb4bc466d27cd6a7b2a03101bfa22933d6ee5bfdc34baa95778084'),('170','2026-10-19 21:57:36','2','customer','1','data','account_updated','account','8','{\"before\":{\"name\":\"Yanlış Kasa\",\"kind\":\"cash\",\"currency\":\"TRY\"},\"after\":{\"name\":\"Yanlış Kasa 2\",\"kind\":\"bank\",\"currency\":\"EUR\"}}','127.0.0.1','6ac54266effb4bc466d27cd6a7b2a03101bfa22933d6ee5bfdc34baa95778084','0c83b4c28f054869ae02b7a1de12081e95859d6eda012a1f38a276a9c8342ed1'),('171','2026-10-19 21:57:36','2','customer','1','data','account_deleted','account','8','{\"name\":\"Yanlış Kasa 2\",\"opening_minor\":0}','127.0.0.1','0c83b4c28f054869ae02b7a1de12081e95859d6eda012a1f38a276a9c8342ed1','514ee0dac8a844d4786fa76f1d78dc3d20ce3438bb4b5d7ab67f6b72ff0e9239'),('172','2026-10-19 21:57:36','2','customer','1','data','contact_created','contact','3',NULL,'127.0.0.1','514ee0dac8a844d4786fa76f1d78dc3d20ce3438bb4b5d7ab67f6b72ff0e9239','f3186498d723651b1b00d1ad3108b6486f84315c6cbf4419c6f7114835b0adde'),('173','2026-10-19 21:57:36','2','customer','1','data','contacts_deleted','contacts','3','{\"name\":\"Silinecek Cari\"}','127.0.0.1','f3186498d723651b1b00d1ad3108b6486f84315c6cbf4419c6f7114835b0adde','19b4b2f399c6a9bde4aa3b7115086731ba8bae458550fe93e6ab4c73dc69bc90'),('174','2026-10-19 21:57:36','2','customer','1','data','categories_deleted','categories','35','{\"name\":\"Silinecek Kat\"}','127.0.0.1','19b4b2f399c6a9bde4aa3b7115086731ba8bae458550fe93e6ab4c73dc69bc90','82c572c0c6e283569db892710084ee607aa64a2b2f22095ad3f44e6ad5c1a2fe'),('175','2026-10-19 21:57:37','2','customer','1','data','project_created','project','2',NULL,'127.0.0.1','82c572c0c6e283569db892710084ee607aa64a2b2f22095ad3f44e6ad5c1a2fe','807a7e4f35ba26b2b584075aff19d8a4564b7b76f08e04e272d5b7818cc83e4e'),('176','2026-10-19 21:57:37','2','customer','1','data','projects_deleted','projects','2','{\"name\":\"Silinecek Proje\"}','127.0.0.1','807a7e4f35ba26b2b584075aff19d8a4564b7b76f08e04e272d5b7818cc83e4e','89c87938c0ebcb5bad2f9965e44de7271d4b59c9e2516d60c3838b28986d08c3'),('177','2026-10-19 21:57:37','2','customer','1','data','stock_items_deleted','stock_items','10','{\"name\":\"Boş Kart\"}','127.0.0.1','89c87938c0ebcb5bad2f9965e44de7271d4b59c9e2516d60c3838b28986d08c3','fbdac56f8c67657dab96af701e2fd0dab551cf8589770928de0a177f0fd4bbfa'),('178','2026-10-19 21:57:37','2','customer','1','data','warehouses_deleted','warehouses','2','{\"name\":\"Boş Depo\"}','127.0.0.1','fbdac56f8c67657dab96af701e2fd0dab551cf8589770928de0a177f0fd4bbfa','2bf05f93a34622b4f13d9f4b82e2e1dd0e7622a43d61c4c1af2f0e761d16fb93'),('179','2026-10-19 21:57:37','2','customer','1','data','entry_created','entry','32','{\"kind\":\"payable\",\"amount_minor\":80000,\"installments\":1}','127.0.0.1','2bf05f93a34622b4f13d9f4b82e2e1dd0e7622a43d61c4c1af2f0e761d16fb93','44f22769eb9b98a346f0aa25286da1687d9f870b8d8566b52bf0423739401636'),('180','2026-10-19 21:57:37','2','customer','1','data','entry_rescheduled','entry','32','{\"before\":{\"title\":\"Elektrik\",\"provider\":\"Enerjisa\",\"period\":null,\"amount_minor\":80000,\"due_date\":\"2026-10-25\"},\"after\":{\"title\":\"Elektrik (düzeltildi)\",\"provider\":\"Başka\",\"period\":\"2026-10\",\"due_date\":null,\"amount_minor\":85000}}','127.0.0.1','44f22769eb9b98a346f0aa25286da1687d9f870b8d8566b52bf0423739401636','84910b85bcda599d511ac480329b8e5cbc999e6d4d3fa44b392dc8bd76f0e468'),('181','2026-10-19 21:57:37','2','customer','1','data','entry_deleted','entry','32','{\"snapshot\":{\"workspace_id\":2,\"kind\":\"payable\",\"source\":\"personal_bill\",\"contact_id\":null,\"title\":\"Elektrik (düzeltildi)\",\"currency\":\"TRY\",\"amount_minor\":85000,\"due_date\":null}}','127.0.0.1','84910b85bcda599d511ac480329b8e5cbc999e6d4d3fa44b392dc8bd76f0e468','beb78c015f63ae439d7c8b2fe5407dd55413c158a5caec027a3e37efe4d78443'),('182','2026-10-19 21:57:37','2','customer','1','data','entry_created','entry','33','{\"kind\":\"payable\",\"amount_minor\":10000,\"installments\":1}','127.0.0.1','beb78c015f63ae439d7c8b2fe5407dd55413c158a5caec027a3e37efe4d78443','ab60b4d5d7eaed30cfbe4f7cc2a8e31263ddc81bde30989dcb20439c64fd63c0'),('183','2026-10-19 21:57:37','2','customer','1','data','payment_created','transaction','41','{\"amount_minor\":4000,\"contact_id\":null,\"allocations\":{\"33\":4000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','ab60b4d5d7eaed30cfbe4f7cc2a8e31263ddc81bde30989dcb20439c64fd63c0','9248c1778b45223d910f5afcaac812372859a76e9b470f3b0aa95a8de2611613'),('184','2026-10-19 21:57:37','2','customer','1','data','document_uploaded','invoice','9','{\"doc\":2,\"size\":70}','127.0.0.1','9248c1778b45223d910f5afcaac812372859a76e9b470f3b0aa95a8de2611613','68a724f2a2a8130ce2be1af67f010b263ed37a1d3647fb5c353d69c534fa47da'),('185','2026-10-19 21:57:37','2','customer','1','data','document_deleted','document','2',NULL,'127.0.0.1','68a724f2a2a8130ce2be1af67f010b263ed37a1d3647fb5c353d69c534fa47da','045203367d6c05beecbf8cb836fcb4f79d6e668d48075e28b24fe3557f834ca1'),('186','2026-10-19 21:57:37','2','customer','1','data','document_uploaded','transaction','34','{\"doc\":3,\"size\":70}','127.0.0.1','045203367d6c05beecbf8cb836fcb4f79d6e668d48075e28b24fe3557f834ca1','40b34b015511757c3cd287d7edca2a25bf1f199d43f35d2ac7f7c8df9cd833ee'),('187','2026-10-19 21:57:38','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','40b34b015511757c3cd287d7edca2a25bf1f199d43f35d2ac7f7c8df9cd833ee','bc6dbbe8b94ceaae0b68eb9d8d8b5336ab4fcbbcf12e9387f5f8ba1cd8dff683'),('188','2026-10-19 21:57:38','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','bc6dbbe8b94ceaae0b68eb9d8d8b5336ab4fcbbcf12e9387f5f8ba1cd8dff683','cd02ba9c87afce3e36143d2f365dbb89369c46bda65dee44ed13e0717516d125'),('189','2026-10-19 21:57:38','2','customer','1','data','contact_created','contact','4',NULL,'127.0.0.1','cd02ba9c87afce3e36143d2f365dbb89369c46bda65dee44ed13e0717516d125','f41cf99985d08f8a37af37e6a57c09bac654070eab3904c5f55aee722e225f24'),('190','2026-10-19 21:57:38','2','customer','1','data','invoice_created','invoice','25','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":10000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','f41cf99985d08f8a37af37e6a57c09bac654070eab3904c5f55aee722e225f24','9b2bec92f3e8d32adbda51423aeac98474e465e9c6eeaf548a3a03e746e87e35'),('191','2026-10-19 21:57:38','2','customer','1','data','collection_created','transaction','42','{\"amount_minor\":3000000,\"contact_id\":4,\"allocations\":{\"34\":3000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','9b2bec92f3e8d32adbda51423aeac98474e465e9c6eeaf548a3a03e746e87e35','0eea4273c8e4d2b08ae03286440ef20b6387a6aa3c4ef02c860ffaf22a9d85fc'),('192','2026-10-19 21:57:38','2','customer','1','data','contact_created','contact','5',NULL,'127.0.0.1','0eea4273c8e4d2b08ae03286440ef20b6387a6aa3c4ef02c860ffaf22a9d85fc','d75e490d7137f5588e7a6054e9471bdd7eb3ab1a48e74e12bb34ddabff4e6130'),('193','2026-10-19 21:57:38','2','customer','1','data','collection_created','transaction','43','{\"amount_minor\":3000000,\"contact_id\":5,\"allocations\":[],\"unallocated_minor\":3000000,\"for_workspace_id\":null}','127.0.0.1','d75e490d7137f5588e7a6054e9471bdd7eb3ab1a48e74e12bb34ddabff4e6130','3019e3b4da4f5a5807f9789f2c799a95f541a49b29239f20a78e0851294136fe'),('194','2026-10-19 21:57:38','2','customer','1','data','transaction_created','transaction','44','{\"kind\":\"income\",\"amount_minor\":7700,\"replaces\":null}','127.0.0.1','3019e3b4da4f5a5807f9789f2c799a95f541a49b29239f20a78e0851294136fe','e41bf14551182615b796166747e5a42cf38ffb6064be3c77b9a311f9ceda9921'),('195','2026-10-19 21:57:38','2','customer','1','data','transaction_voided','transaction','44','{\"reason\":\"test\",\"before\":{\"kind\":\"income\",\"amount_minor\":7700,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[44]}','127.0.0.1','e41bf14551182615b796166747e5a42cf38ffb6064be3c77b9a311f9ceda9921','0130f69f75b8551a4c583d839b6bd20ba7e266532719338ef2112c50be006ebd'),('196','2026-10-19 21:57:38','2','customer','1','data','transaction_created','transaction','45','{\"kind\":\"income\",\"amount_minor\":50000,\"replaces\":null}','127.0.0.1','0130f69f75b8551a4c583d839b6bd20ba7e266532719338ef2112c50be006ebd','90ceab464cd72bf4feb852b45a91ff20b816f1c81fe7ddb9f881813620886e04'),('197','2026-10-19 21:57:38','2','customer','1','data','income_converted_to_collection','transaction','45','{\"amount_minor\":50000,\"contact_id\":5,\"was_vat_minor\":0}','127.0.0.1','90ceab464cd72bf4feb852b45a91ff20b816f1c81fe7ddb9f881813620886e04','e9db0b2d36b9cb3385c4a17974655b746d895a9f2fd425d2b6da78e9099f4030'),('198','2026-10-19 21:57:39','2','customer','1','data','transaction_voided','transaction','45','{\"reason\":\"test temizliği\",\"before\":{\"kind\":\"collection\",\"amount_minor\":50000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[45]}','127.0.0.1','e9db0b2d36b9cb3385c4a17974655b746d895a9f2fd425d2b6da78e9099f4030','83001b303539e7f4523e3eba8ddb4ed7d9b03da12dc7568e8d5230d3ca319348'),('199','2026-10-19 21:57:39','2','customer','1','data','invoice_created','invoice','26','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":10000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','83001b303539e7f4523e3eba8ddb4ed7d9b03da12dc7568e8d5230d3ca319348','36a62b1d6ec0f9f76313c8c2ebde9558ac3e31f646c8a9d0c06a53b6f100bfe5'),('200','2026-10-19 21:57:39','2','customer','1','data','payment_allocated','transaction','43','{\"new_minor\":3000000,\"allocated_minor\":3000000,\"unallocated_minor\":0}','127.0.0.1','36a62b1d6ec0f9f76313c8c2ebde9558ac3e31f646c8a9d0c06a53b6f100bfe5','6656a1874e8d210d746068dd1940eb1d7fc397cc34f19c3aca0cbbd8c81e1689'),('201','2026-10-19 21:57:39','2','customer','1','data','entry_updated','entry','35','{\"before\":{\"planned_date\":null},\"after\":{\"planned_date\":\"2026-10-18\"}}','127.0.0.1','6656a1874e8d210d746068dd1940eb1d7fc397cc34f19c3aca0cbbd8c81e1689','666c606e4dad4412dfae0344e76cb7df1c47fc33e6ee49921fb96164f125a1fe');
/*FBEND*/
INSERT INTO `audit_log` VALUES ('202','2026-10-19 21:57:39','2','customer','1','data','entry_updated','entry','35','{\"before\":{\"planned_date\":\"2026-10-18\"},\"after\":{\"planned_date\":\"2026-10-20\"}}','127.0.0.1','666c606e4dad4412dfae0344e76cb7df1c47fc33e6ee49921fb96164f125a1fe','3c368e58c1bf655572d0350d04f756f2e51c4c5ed9816a5ddea14ea1470bc475'),('203','2026-10-19 21:57:39','2','customer','1','data','collection_created','transaction','46','{\"amount_minor\":7000000,\"contact_id\":5,\"allocations\":{\"35\":7000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','3c368e58c1bf655572d0350d04f756f2e51c4c5ed9816a5ddea14ea1470bc475','47e2853a7cfa19b1febbcf9ea7bb86d9a83b12ec575c7c8fb0d565a648730034'),('204','2026-10-19 21:57:39','2','customer','1','data','invoice_created','invoice','27','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":100000,\"due_date\":\"2026-10-25\",\"new_items\":0}','127.0.0.1','47e2853a7cfa19b1febbcf9ea7bb86d9a83b12ec575c7c8fb0d565a648730034','6fd67096a59b58056e8f182de35747d609f836a33f24ff317147bd87bab39e72'),('205','2026-10-19 21:57:39','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','6fd67096a59b58056e8f182de35747d609f836a33f24ff317147bd87bab39e72','6b468e0b279f9535bdc9692e51cdeac5f7647740407a3aa94c9957121f43b4cd'),('206','2026-10-19 21:58:00','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','6b468e0b279f9535bdc9692e51cdeac5f7647740407a3aa94c9957121f43b4cd','7b03b26ea25ffdfb2abbe6f7017ef11dca37e2e2494e2e142befdcc69524effc'),('207','2026-10-19 21:58:01','2','customer','1','data','contact_created','contact','6',NULL,'127.0.0.1','7b03b26ea25ffdfb2abbe6f7017ef11dca37e2e2494e2e142befdcc69524effc','0570864396a7c52e18a690fe3c07d3729c12ab501b06ff2c0843c7522ab1daae'),('208','2026-10-19 21:58:01','2','customer','1','data','document_uploaded','transaction','46','{\"doc\":4,\"size\":70}','127.0.0.1','0570864396a7c52e18a690fe3c07d3729c12ab501b06ff2c0843c7522ab1daae','3cf4875da22f322cedbdb48014d4614fb224889b1529ff0877e5b45f84f64e5d');
/*FBEND*/
DROP TABLE IF EXISTS `budgets`;
/*FBEND*/
CREATE TABLE `budgets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `month` char(7) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `amount_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_bud` (`tenant_id`,`category_id`,`month`,`currency`),
  CONSTRAINT `fk_bu_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `budgets` VALUES ('1','1','9','2026-10','TRY','200000');
/*FBEND*/
DROP TABLE IF EXISTS `captchas`;
/*FBEND*/
CREATE TABLE `captchas` (
  `id` char(32) NOT NULL,
  `answer_hash` char(64) NOT NULL,
  `pow_seed` char(32) NOT NULL,
  `pow_bits` tinyint(4) NOT NULL,
  `ip_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_captcha_exp` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `captchas` VALUES ('015752389fb04dea8580a8a4c7c43e52','570c05afa7912931248e2011c619ef54f2ccf460ade89f32e42c5580ff53246d','0738137c0ae16aa7','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:04','2026-10-19 21:57:04'),('01aa7dd5cc026bedf4f7329a97a9e0d1','4cbc65be878c7ff8b7dce13ebcec9a5007713213c97f3dc9aea1713871ccead1','cadbb8a1a093666f','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:11','2026-10-19 21:57:11'),('080ebcef66b8b9fb6eda6ad95361b694','4af3c4bdf84da7cc3d452efe692cf830992851a39b872d0553884959cd77217e','1e6a999597838d32','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 21:57:34','2026-10-19 21:54:34'),('0e3e365e9c3c46f8d65d38ccd18c5634','4b9834aa6330504b125f4f0b7b42d45c1b884f1a77ae950170dedf74d3a07863','9ed3d40e755e960f','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:39','2026-10-19 21:57:39'),('11d27a8905e6e2374b12aa0cc02a7200','9a162a3c81a771ac04f509bbaeaad8bcdde7a3ab1adfa19568eee818dd94af9f','54032d1bab05a654','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:05','2026-10-19 21:57:05'),('1356723c8eb6d49633fddcf95de18a60','a4587fe1b33d143bff8db18f7a052de3d6dbb0a83fe1257bcda057722396cad2','e1bf4185bb6ce5a3','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:04','2026-10-19 21:57:04'),('17b8e4f41423396499131862a2cd4da0','b4766c0878bc8d0e0724f434cf3a869efe55eff88916b791177d2a7dfd4aeb76','87578ea92358817e','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:03','2026-10-19 21:57:03'),('1a7a8b2ad6fb98b4074c4706b2e9ac86','118076bd6e15cb3b188e2ab255fc948f3975eba08e3dbab253ddf1cd4c116490','c703266f9cc88324','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:03','2026-10-19 21:57:03'),('234cfce19d2f1ec8c479b0ffa684cd59','10002252a2f1504dcb147f872c8a654827ee7704fc663f81d9144468e33d04ba','b8b2ed6ccb0b5734','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 21:57:34','2026-10-19 21:54:34'),('2c78b1305b1164573d96f3b44901cd83','c6ef5bf635e7e741222eacabab431238cda293cc513d3385341d7dac7b02a3ad','71a9be85b1ee6dda','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 21:58:32','2026-10-19 21:55:32'),('3d7aed9a2429b10589782a737bcf7ed3','76e741c684f191794b054625324bc8df9375281e21d3cc3e6ea6957b4ea5e874','79c171c6254ae8e4','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:03','2026-10-19 21:57:03'),('44ad7f129ce73c35971fbb73177e70e2','a3d316d6109d5ca81eb0dfa82789b3114d95852dcebdb0d9ad95bbb9c40aae86','c3f902fade275229','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 21:57:34','2026-10-19 21:54:34'),('4b1110f7fd04a585967947ac246bc86c','ced07850496f65627292943e8c529a3321484e0c0730489b1cadaae7cc78eee2','4328430b1525a3ae','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:05','2026-10-19 21:57:05'),('4e3c11ce66bd75938704ae9704c46c54','b8dc1111a2ba0d4afe93f8834ac2b2b9b357cb18ac4ff4e3d9a4a4756c9cf4be','4eface6766aebea5','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:03','2026-10-19 21:57:03'),('5359ca7b9c70874263de6ca220d8bde6','2f498b2d4bd2324481480e038c7a01f5d68df6935db98ee0c244af3850a599bf','9c1804f12e5e75a1','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:38','2026-10-19 21:57:38'),('53c2373cad8f65bff47bd633d6de8347','8708d385032af09df42f67026c4e4077da8635fcc317a7878d43a5b522db764e','c8b2c3dfb43f8f94','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:05','2026-10-19 21:57:05'),('53e80ba170ec1a46cb0a16756efe1def','f6f0299d73270dc07264ebf85f569d93294dff74bc64ae9e77adb25840c254b5','1200ddb6dcc747c6','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:05','2026-10-19 21:57:05'),('5b41726fa296e9ff43a94307eaea05ef','f43ec4afae822f179ca98c5dfd8fb72a04b88d496d27ebb6dfa013ce15f02563','4b9abc150fa5a747','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:38','2026-10-19 21:57:38'),('674e6c9ddb51d50741cbaca912aadcf1','dc06a8d2ee3e10bc7e4e21297465598f4dadff9c5d5d9599896e7d94ec2cc0f2','8f09c446aee7684a','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 21:58:32',NULL),('754a2e3f7c4527e97d6540be4e2ec772','e749e78ad3622cb55d759c2275e125fddd7c31f87b9d6121ddd555150b5c5c70','3d56d0f41c1b18ea','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 21:58:32','2026-10-19 21:55:32'),('79363e568f07ec78abb4dfc746251d66','f01193550ef08077cc82ab7a275a463c76228f7b262e88ef21d826647996998f','570593dd6ba1e79b','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:04','2026-10-19 21:57:04'),('7b70d108ddf9295d2478084987503dd0','958985a99105640fb77e6f844f39eacb8ec9f8c7c2626fa80f57f3c003b4941e','086455d97f3a5531','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:30','2026-10-19 21:57:30'),('8554f36abcce2197717f51547e719451','98d768934ca7467fa788fd3d0b2f83a34e37a98f7fbfb3e64872ac8c29af47b3','3b89a520e9ec57b7','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:39','2026-10-19 21:57:39'),('86a1be0b5f20f17d5ab8772f37034021','36c6347a0b7fa84dc738139e6840d21c1cc5d9bed99a4572ed4321983d81e4ae','227a8bea24b64165','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:04','2026-10-19 21:57:05'),('871ad83c92e1a649a09bc8a94223b8f9','8e0501ffd3081214a36cceb137f8329f5c09672caa1665d364ac018908a9de56','1d6f97bf1f89faab','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:05','2026-10-19 21:57:05'),('8c17edbc95eb64ee7c7ee8bd370f0612','3e9d2c5628fcb739d892641c83382ce2ddec58812b97613592bef638e3225342','d2fa00f2a2549131','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 21:59:32','2026-10-19 21:56:32'),('9a570547708d3776499493eb12f20d3d','a56ed273a3e57fd3e1504668413bb18d022f41b6d761847aa08e3854563cd6e1','3a0b1ca0ba25220b','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 21:57:37','2026-10-19 21:54:37'),('9bb819a8725c64fb1cf2e3fe7d928588','fe238f41dd3bc166f832a4203d77c740274ec52fc0b0e06098d542251b7d8a38','9eb3540c98fba3fd','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 21:59:02','2026-10-19 21:56:02'),('9cf92e74e3f9fcdeeb21da0a54dd0274','0b43454b7a6e778bfd646676f139cbd3338227adf5213a3f0f05df1db369bc37','9b3dffabc82816c2','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:04','2026-10-19 21:57:04'),('a54c5d486982ee000a2320d8669150ef','1b3e19f9661a2dc6834256294385507e052022bb10bd356f5a0018773a28413f','4a80528f39ee94c5','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:05','2026-10-19 21:57:05'),('abd59489077194062562fbcdcac9612b','9bdc46e6035a0cf58ed2dd0400b75dca62ad1299cd41508e407ad447a7a463f4','a802988acc45c488','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:05','2026-10-19 21:57:05'),('ad45eb5a4f7b06454d662a1ddf745741','54edfa1c7665bbbc86e9c0fe312e0575b4bea3c38953f59ffe60497e5f738603','ea09b931e807c119','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:30','2026-10-19 21:57:30'),('ae5d0518b45bf01cb7114943992152dd','f1486293af0207db3c1e65a89f6613ed13103024daf396ac512e42df2686dbf1','11c5442c200826c4','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:04','2026-10-19 21:57:04'),('bfe4f4e76b9696c67d3407bf4afd42aa','cc51aa045ab142891b69fc1493c47b5940bd1552b02b07babbd569f2d75b890a','c78d4069f1ababd6','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:04','2026-10-19 21:57:04'),('c5d2dde41a01f988409d0e1a6b2876fb','883f7810f50bca81f4f09e47f9d3f6b2a5b2692290712c9852c82fb6b9cb668b','2f5498213fdbba27','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:03',NULL),('cae0c548d32d544cddae4c88a0d3ecdc','1a5698529b450d2736dda4707b40997fba5868d4a3ea09bb49868648c9028fc5','57c678415fcc1f9e','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:05','2026-10-19 21:57:05'),('cd7a88be9f9f3a969a192da26c1f976f','dfeeab7de917e6e904e36f280af83228e1c5b5f7021ebba2cf7bced5ec73d581','5648cfbe85df7fc9','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:04','2026-10-19 21:57:04'),('d2d9de2cbcebf751655801b8ce84c32a','03dca4c6dc358559b14fb54849baf4bf9bf094751a63cad4a05459189ed6b38f','8bd641292b62e1e3','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:04','2026-10-19 21:57:04'),('e509e6a113cd0c9b48b68c7d91a8ba4c','e9c582c7206d79515dd0fa5947f63c0a8bef11d2362044adabdcf8b6ea0b8e21','dca852cf18693911','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 21:58:01','2026-10-19 21:55:01'),('ec1b3cf2bb211cb0f29fd0bd87dc6f37','88e4889f2063447cd9be081114cfda93ba0c2275f1c4d0ec864f2b09f4752819','69a6707cfd7d736e','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:00:05','2026-10-19 21:57:05');
/*FBEND*/
DROP TABLE IF EXISTS `card_installments`;
/*FBEND*/
CREATE TABLE `card_installments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `card_id` bigint(20) unsigned NOT NULL,
  `purchase_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ci_t` (`tenant_id`,`card_id`,`due_date`),
  KEY `fk_ci_p` (`purchase_id`),
  CONSTRAINT `fk_ci_p` FOREIGN KEY (`purchase_id`) REFERENCES `card_purchases` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `card_installments` VALUES ('1','1','1','1','1','2026-11-15','40000'),('2','1','1','1','2','2026-12-15','40000'),('3','1','1','1','3','2027-01-15','40000');
/*FBEND*/
DROP TABLE IF EXISTS `card_purchases`;
/*FBEND*/
CREATE TABLE `card_purchases` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `card_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `txn_date` date NOT NULL,
  `description` varchar(250) NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `installments` int(11) NOT NULL DEFAULT 1,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_cp_t` (`tenant_id`,`card_id`),
  CONSTRAINT `fk_cp_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `card_purchases` VALUES ('1','1','1','1','2026-10-20','Ofis malzemesi','120000','2000','20000','3','9',NULL,NULL,'posted','2026-10-19 21:57:08');
/*FBEND*/
DROP TABLE IF EXISTS `cards`;
/*FBEND*/
CREATE TABLE `cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `limit_minor` bigint(20) NOT NULL DEFAULT 0,
  `statement_day` tinyint(4) NOT NULL DEFAULT 1,
  `due_day` tinyint(4) NOT NULL DEFAULT 10,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cd_t` (`tenant_id`),
  CONSTRAINT `fk_cd_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `cards` VALUES ('1','1','1','Kurumsal Kart',NULL,'TRY','5000000','5','15','0','2026-10-19 21:57:07');
/*FBEND*/
DROP TABLE IF EXISTS `categories`;
/*FBEND*/
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('income','expense') NOT NULL,
  `name` varchar(100) NOT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_cat` (`tenant_id`,`kind`,`name`),
  CONSTRAINT `fk_cat_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `categories` VALUES ('1','1','income','Satış Geliri','0'),('2','1','income','Hizmet Geliri','0'),('3','1','income','Kira Geliri','0'),('4','1','income','Faiz Geliri','0'),('5','1','income','Diğer Gelirler','0'),('6','1','expense','Yakıt','0'),('7','1','expense','Ulaşım','0'),('8','1','expense','Yemek','0'),('9','1','expense','Malzeme','0'),('10','1','expense','İşçilik','0'),('11','1','expense','Taşeron','0'),('12','1','expense','Kira','0'),('13','1','expense','Abonelik','0'),('14','1','expense','Banka Masrafı','0'),('15','1','expense','Vergi','0'),('16','1','expense','Sigorta','0'),('17','1','expense','Diğer Giderler','0'),('18','2','income','Satış Geliri','0'),('19','2','income','Hizmet Geliri','0'),('20','2','income','Kira Geliri','0'),('21','2','income','Faiz Geliri','0'),('22','2','income','Diğer Gelirler','0'),('23','2','expense','Yakıt','0'),('24','2','expense','Ulaşım','0'),('25','2','expense','Yemek','0'),('26','2','expense','Malzeme','0'),('27','2','expense','İşçilik','0'),('28','2','expense','Taşeron','0'),('29','2','expense','Kira','0'),('30','2','expense','Abonelik','0'),('31','2','expense','Banka Masrafı','0'),('32','2','expense','Vergi','0'),('33','2','expense','Sigorta','0'),('34','2','expense','Diğer Giderler','0');
/*FBEND*/
DROP TABLE IF EXISTS `contacts`;
/*FBEND*/
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('customer','supplier','both') NOT NULL DEFAULT 'customer',
  `name` varchar(200) NOT NULL,
  `tax_no` varchar(30) DEFAULT NULL,
  `tax_office` varchar(100) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `address` varchar(400) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ct_t` (`tenant_id`),
  CONSTRAINT `fk_ct_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `contacts` VALUES ('1','1','customer','Müşteri A',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 21:57:06'),('2','1','supplier','Tedarikçi B',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 21:57:06'),('4','1','customer','Avans Müşterisi',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 21:57:38'),('5','1','customer','Avans Müşterisi 2',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 21:57:38'),('6','1','customer','<script>alert(1)</script>',NULL,NULL,NULL,NULL,NULL,'\"><img src=x onerror=alert(1)>','0','2026-10-19 21:58:01');
/*FBEND*/
DROP TABLE IF EXISTS `documents`;
/*FBEND*/
CREATE TABLE `documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `entity` varchar(30) NOT NULL,
  `entity_id` bigint(20) unsigned NOT NULL,
  `orig_name` varchar(200) NOT NULL,
  `stored_name` char(64) NOT NULL,
  `mime` varchar(100) NOT NULL,
  `size_bytes` bigint(20) NOT NULL,
  `sha256` char(64) NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_doc_ent` (`tenant_id`,`entity`,`entity_id`),
  CONSTRAINT `fk_doc_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `documents` VALUES ('1','1','transaction','18','fis.png','a116c0f086b96edf6de7c7286c42b622bdd1f3e0a16faa1abc0a102dd504205a','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 21:57:11',NULL),('2','1','invoice','9','fatura.png','3a022130eb58a3635a3759f93863e6a15be9cd6ccc7647275949d0f99c6cc142','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 21:57:37','2026-10-19 21:57:37'),('3','1','transaction','34','dekont.png','0a1528a3b0e3435b4478ceb63092633bab295724a7a1c2370788f011aa1c236a','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 21:57:37',NULL),('4','1','transaction','46','fis2.png','636249af8a3601ce4ba5bd174942f0b894806ecec06cad5b6449264f5e9c30ba','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 21:58:01',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `entries`;
/*FBEND*/
CREATE TABLE `entries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `kind` enum('receivable','payable') NOT NULL,
  `source` enum('manual','invoice','personal_bill','recurring','milestone') NOT NULL DEFAULT 'manual',
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `recurring_id` bigint(20) unsigned DEFAULT NULL,
  `group_id` varchar(26) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  `seq_total` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `provider` varchar(120) DEFAULT NULL,
  `period` varchar(20) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `amount_minor` bigint(20) NOT NULL,
  `due_date` date DEFAULT NULL,
  `original_due_date` date DEFAULT NULL,
  `priority` tinyint(4) NOT NULL DEFAULT 2,
  `affects_pl` tinyint(4) NOT NULL DEFAULT 0,
  `status` enum('open','cancelled') NOT NULL DEFAULT 'open',
  `note` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `invoice_key` varchar(40) DEFAULT NULL,
  `planned_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_entry_invoice` (`tenant_id`,`invoice_key`),
  UNIQUE KEY `ux_entry_recur` (`tenant_id`,`recurring_id`,`due_date`),
  KEY `ix_en_t` (`tenant_id`,`status`,`due_date`),
  KEY `ix_en_planned` (`tenant_id`,`status`,`planned_date`),
  CONSTRAINT `fk_en_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `entries` VALUES ('1','1','1','receivable','manual','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Büyük satış',NULL,NULL,'TRY','10000000','2026-10-30','2026-10-30','2','0','open',NULL,'2026-10-19 21:57:06',NULL,NULL,NULL),('2','1','1','payable','manual','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Plan: kira',NULL,NULL,'TRY','500000','2026-11-09','2026-11-09','2','1','open',NULL,'2026-10-19 21:57:06',NULL,NULL,NULL),('3','1','1','payable','recurring',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'Aylık abonelik',NULL,NULL,'TRY','30000','2026-10-23','2026-10-23','2','1','open',NULL,'2026-10-19 21:57:06',NULL,NULL,NULL),('4','1','1','payable','recurring',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'Aylık abonelik',NULL,NULL,'TRY','30000','2026-11-23','2026-11-23','2','1','open',NULL,'2026-10-19 21:57:06',NULL,NULL,NULL),('5','1','1','receivable','invoice','1',NULL,NULL,'1',NULL,NULL,NULL,NULL,'Satış faturası FB-2026-001 — Müşteri A',NULL,NULL,'TRY','120000','2026-11-04','2026-11-04','2','0','open',NULL,'2026-10-19 21:57:07',NULL,'1',NULL),('7','1','1','receivable','manual','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'EUR alacak',NULL,NULL,'EUR','50000','2026-10-25','2026-10-25','2','0','open',NULL,'2026-10-19 21:57:07',NULL,NULL,NULL),('8','1','1','payable','manual','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tedarikçi borcu',NULL,NULL,'TRY','1000000','2026-10-30','2026-10-17','2','0','open',NULL,'2026-10-19 21:57:07',NULL,NULL,NULL),('9','1','2','payable','personal_bill',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Elektrik','Enerjisa','2026-10','TRY','80000','2026-10-20','2026-10-20','2','1','open',NULL,'2026-10-19 21:57:08',NULL,NULL,NULL),('10','1','1','receivable','invoice','1','1',NULL,'3',NULL,NULL,NULL,NULL,'Satış faturası PR-1 — Müşteri A',NULL,NULL,'TRY','1200000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:09',NULL,'3',NULL),('11','1','1','payable','invoice','2','1',NULL,'4',NULL,NULL,NULL,NULL,'Alış faturası ALIS-9 — Tedarikçi B',NULL,NULL,'TRY','480000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:09',NULL,'4',NULL),('12','1','1','receivable','milestone','1','1',NULL,NULL,NULL,NULL,NULL,NULL,'Santral Kurulumu — Hakediş 2',NULL,NULL,'TRY','2000000','2026-11-19','2026-11-19','2','1','open',NULL,'2026-10-19 21:57:09',NULL,NULL,NULL),('13','1','1','payable','invoice','2',NULL,NULL,'5',NULL,NULL,NULL,NULL,'Alış faturası STK-1 — Tedarikçi B',NULL,NULL,'TRY','120000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:09',NULL,'5',NULL),('14','1','1','payable','invoice','2',NULL,NULL,'6',NULL,NULL,NULL,NULL,'Alış faturası T4-1-2894 — Tedarikçi B',NULL,NULL,'TRY','100000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:30',NULL,'6',NULL),('15','1','1','payable','invoice','2',NULL,NULL,'7',NULL,NULL,NULL,NULL,'Alış faturası T4-2-fd54 — Tedarikçi B',NULL,NULL,'TRY','50000','2026-10-30','2026-10-27','2','0','open',NULL,'2026-10-19 21:57:31',NULL,'7',NULL),('16','1','1','payable','invoice','2',NULL,NULL,'8',NULL,NULL,NULL,NULL,'Alış faturası T4-3-ef70 — Tedarikçi B',NULL,NULL,'TRY','50000','2026-12-04','2026-12-04','2','0','open',NULL,'2026-10-19 21:57:31',NULL,'8',NULL),('17','1','1','payable','invoice','2',NULL,NULL,'9',NULL,NULL,NULL,NULL,'Alış faturası T4-5-b743 — Tedarikçi B',NULL,NULL,'TRY','1200000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:31',NULL,'9',NULL),('18','1','1','payable','invoice','2',NULL,NULL,'10',NULL,NULL,NULL,NULL,'Alış faturası T4-6-bd90 — Tedarikçi B',NULL,NULL,'TRY','1000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:31',NULL,'10',NULL),('19','1','1','payable','invoice','2',NULL,NULL,'11',NULL,NULL,NULL,NULL,'Alış faturası T4-7-990c — Tedarikçi B',NULL,NULL,'TRY','1000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:32',NULL,'11',NULL),('20','1','1','payable','invoice','2',NULL,NULL,'12',NULL,NULL,NULL,NULL,'Alış faturası T4-8-3262 — Tedarikçi B',NULL,NULL,'TRY','6000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:32',NULL,'12',NULL),('21','1','1','payable','invoice','2',NULL,NULL,'13',NULL,NULL,NULL,NULL,'Alış faturası T4-9-54d7 — Tedarikçi B',NULL,NULL,'TRY','4500000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:32',NULL,'13',NULL),('22','1','1','receivable','invoice','1',NULL,NULL,'14',NULL,NULL,NULL,NULL,'Satış faturası T4-10-00d8 — Müşteri A',NULL,NULL,'TRY','500000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:33',NULL,'14',NULL),('23','1','1','payable','invoice','2',NULL,NULL,'15',NULL,NULL,NULL,NULL,'Alış faturası T4-STK-1 — Tedarikçi B',NULL,NULL,'TRY','5590000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:33',NULL,'15',NULL),('24','1','1','payable','invoice','2',NULL,NULL,'16',NULL,NULL,NULL,NULL,'Alış faturası T4-STK-2 — Tedarikçi B',NULL,NULL,'TRY','1000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:34',NULL,'16',NULL),('25','1','1','payable','invoice','2',NULL,NULL,'17',NULL,NULL,NULL,NULL,'Alış faturası T4-STK-3 — Tedarikçi B',NULL,NULL,'TRY','4000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:34',NULL,'17',NULL),('26','1','1','payable','invoice','2',NULL,NULL,'19',NULL,NULL,NULL,NULL,'Alış faturası T4-IDEM — Tedarikçi B',NULL,NULL,'TRY','100',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:34',NULL,'19',NULL),('27','1','1','receivable','invoice','1',NULL,NULL,'20',NULL,NULL,NULL,NULL,'Satış faturası T4-S-BZ — Müşteri A',NULL,NULL,'TRY','4500000',NULL,NULL,'2','0','cancelled',NULL,'2026-10-19 21:57:34','2026-10-19 21:57:35','20',NULL),('29','1','1','receivable','invoice','1',NULL,NULL,'22',NULL,NULL,NULL,NULL,'Satış faturası T4-S-NO — Müşteri A',NULL,NULL,'TRY','50000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:35',NULL,'22',NULL),('30','1','1','payable','invoice','2',NULL,NULL,'23',NULL,NULL,NULL,NULL,'Alış faturası T4-SUP-NO — Tedarikçi B',NULL,NULL,'TRY','30000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:35',NULL,'23',NULL),('31','1','1','payable','invoice','2',NULL,NULL,'24',NULL,NULL,NULL,NULL,'Alış faturası T4-11-2d43 — Tedarikçi B',NULL,NULL,'TRY','2000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:35',NULL,'24',NULL),('33','1','2','payable','personal_bill',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Su',NULL,NULL,'TRY','10000','2026-10-25','2026-10-25','2','1','open',NULL,'2026-10-19 21:57:37',NULL,NULL,NULL),('34','1','1','receivable','invoice','4',NULL,NULL,'25',NULL,NULL,NULL,NULL,'Satış faturası HOME-1 — Avans Müşterisi',NULL,NULL,'TRY','10000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:38',NULL,'25',NULL),('35','1','1','receivable','invoice','5',NULL,NULL,'26',NULL,NULL,NULL,NULL,'Satış faturası HOME-2 — Avans Müşterisi 2',NULL,NULL,'TRY','10000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 21:57:39',NULL,'26','2026-10-20'),('36','1','1','payable','invoice','2',NULL,NULL,'27',NULL,NULL,NULL,NULL,'Alış faturası HOME-P1 — Tedarikçi B',NULL,NULL,'TRY','100000','2026-10-25','2026-10-25','2','0','open',NULL,'2026-10-19 21:57:39',NULL,'27',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `fx_rates`;
/*FBEND*/
CREATE TABLE `fx_rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `currency` char(3) NOT NULL,
  `rate_date` date NOT NULL,
  `rate` decimal(18,8) NOT NULL,
  `source` varchar(30) NOT NULL DEFAULT 'manual',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_fx` (`tenant_id`,`currency`,`rate_date`),
  CONSTRAINT `fk_fx_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `fx_rates` VALUES ('1','1','EUR','2026-10-20','40.50000000','manual'),('2','1','USD','2026-10-20','35.25000000','manual');
/*FBEND*/
DROP TABLE IF EXISTS `idempotency_keys`;
/*FBEND*/
CREATE TABLE `idempotency_keys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `ikey` char(64) NOT NULL,
  `route` varchar(160) NOT NULL,
  `status_code` smallint(6) DEFAULT NULL,
  `response` mediumtext DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_idem` (`tenant_id`,`ikey`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `idempotency_keys` VALUES ('1','1','380fa4658290f90b59c8dba21f2c5a9ca45d814209bfacbbe6d483498122c401','POST /transactions','201','{\"ok\":true,\"id\":17,\"warning\":null}','2026-10-19 21:57:09'),('3','1','4b638ad525dc60cd7a6fe2464c1ec6646b0137782beeda2d921a2551e93686e6','POST /payments','201','{\"ok\":true,\"id\":25,\"allocated_minor\":400000,\"unallocated_minor\":0}','2026-10-19 21:57:31'),('4','1','9deb76c461bb8c1af7655abd56f2609dfccbac47f0d25f286ea6ca0ebf761fa1','POST /payments','201','{\"ok\":true,\"id\":26,\"allocated_minor\":600000,\"unallocated_minor\":0}','2026-10-19 21:57:31'),('6','1','7a0ba943c3fe1882550a4b271639b2e642304a1e69523f08dad0062115ade303','POST /payments','201','{\"ok\":true,\"id\":27,\"allocated_minor\":1000000,\"unallocated_minor\":2000000}','2026-10-19 21:57:32'),('8','1','49a00c2bb51f2c34c9e0f1bef804857d02c90b6c94c1ba61c81596195ce2d591','POST /payments','201','{\"ok\":true,\"id\":28,\"allocated_minor\":5000000,\"unallocated_minor\":0}','2026-10-19 21:57:32'),('9','1','ed2a9c58cc395e78128129bfc54d1ea46ff6b293325a0cb37f15c45347d9152f','POST /payments/27/allocate','200','{\"ok\":true,\"allocated_minor\":3000000,\"unallocated_minor\":0}','2026-10-19 21:57:32'),('10','1','b064909815fabfee91ee3ce9f55762cb7f60162acd5e649b493eec57a27c7a29','POST /payments','201','{\"ok\":true,\"id\":29,\"allocated_minor\":0,\"unallocated_minor\":10000}','2026-10-19 21:57:33'),('12','1','b31d3ecd5729fe9d54d64188b9119b0a66fe11f93b4c1460055103eade1f5873','POST /payments','201','{\"ok\":true,\"id\":30,\"allocated_minor\":0,\"unallocated_minor\":7000}','2026-10-19 21:57:33'),('14','1','94f5b6814deda22a6a30def552984cd87b90f5dee598070c939f6a2260c20347','POST /payments','201','{\"ok\":true,\"id\":31,\"allocated_minor\":0,\"unallocated_minor\":7000}','2026-10-19 21:57:33'),('15','1','ac287208429f7e72dd65d84d962ff2098d80c67a7cf97d3a2cee8f4a7ebbc061','POST /payments','201','{\"ok\":true,\"id\":32,\"allocated_minor\":500000,\"unallocated_minor\":300000}','2026-10-19 21:57:33'),('22','1','df0e1b7c267e98066204098c9637fa72f57a585f27382da7b9d04049f0bab418','POST /invoices','201','{\"ok\":true,\"id\":15,\"warnings\":[],\"new_items\":3}','2026-10-19 21:57:33'),('23','1','4186e7f67d2471412ef45521158607d0c9ea8b4cf127aaeedcad58b86fdc72c6','POST /invoices','201','{\"ok\":true,\"id\":19,\"warnings\":[],\"new_items\":1}','2026-10-19 21:57:34'),('25','1','59bc8692e5cb77f7fe69b1d1bbf054c10e27032cf210d20cff705ee886356ee6','POST /payments','201','{\"ok\":true,\"id\":33,\"allocated_minor\":50000,\"unallocated_minor\":0}','2026-10-19 21:57:35'),('26','1','2ffa0d9bf0df9d487732fafaf6522f8870c03dece702301d10c30a06df0a9db2','POST /invoices/22/deliver','200','{\"ok\":true,\"delivery\":{\"state\":\"partial\",\"tracked_milli\":5000,\"fulfilled_milli\":2000,\"pending_milli\":3000}}','2026-10-19 21:57:35'),('28','1','6a547eb813a416ad7d748edb944ce6021bb788ccf3eaf739fa8e690f8c83cde9','POST /payments','201','{\"ok\":true,\"id\":34,\"allocated_minor\":2000000,\"unallocated_minor\":0}','2026-10-19 21:57:36'),('29','1','1d97f161966bc97e44f3ef6229547d9fdef772ea2a6cbe5895a1123d72ca1fa6','POST /transfers','201','{\"ok\":true,\"group\":\"85572d4e6f3f01ce7b11a238da\",\"ids\":[35,36]}','2026-10-19 21:57:36'),('31','1','865b41ca80abfb8a40174394f4affb05e066e11283732c26716550fdb9da051d','POST /transfers','201','{\"ok\":true,\"group\":\"a03bf7b9c2ed483901effa0c81\",\"ids\":[37,38]}','2026-10-19 21:57:36'),('32','1','a7e7626bc5cbc22c73a1c128a2685966038c65d8c422d828d51514fde526b448','POST /transfers','201','{\"ok\":true,\"group\":\"815b58ee04451887fbe0cc17b8\",\"ids\":[39,40]}','2026-10-19 21:57:36'),('33','1','5b1f4f2caa7fb88ec511e105073722d16bd42209906b704b9b55f0354f368733','POST /entries/33/settle','201','{\"ok\":true,\"id\":41,\"remaining_minor\":6000}','2026-10-19 21:57:37'),('37','1','56d9092c5c178a6becf29e019c3fc0d5945020c8c0db454903c26ce609e5fd81','POST /payments','201','{\"ok\":true,\"id\":42,\"allocated_minor\":3000000,\"unallocated_minor\":0}','2026-10-19 21:57:38'),('38','1','c17bb17c755fb0fedb16a28527cd81adc8f37017b08ffb5c099187e0b7cc55a2','POST /transactions','201','{\"ok\":true,\"id\":43,\"warning\":\"Tutar müşteri avansı olarak cari hesaba işlendi (gelir sayılmadı; fatura ile eşleştirebilirsiniz).\"}','2026-10-19 21:57:38'),('39','1','993a1590b392cacc8f2b82542453d6776de69c5030c874acd6ac3fbec99ba0e1','POST /transactions','201','{\"ok\":true,\"id\":44,\"warning\":null}','2026-10-19 21:57:38'),('40','1','85b878401e2a97f11e72a4feb5cb33d235a1191ec8bef59c0c0de3894e15c636','POST /transactions','201','{\"ok\":true,\"id\":45,\"warning\":null}','2026-10-19 21:57:38'),('41','1','226bba834bdea01bb8e7bfb74a82a40d2a2315dd89cc0396e4cfef47e90e15c9','POST /payments/43/allocate','200','{\"ok\":true,\"allocated_minor\":3000000,\"unallocated_minor\":0}','2026-10-19 21:57:39'),('42','1','c6ab2e8b9e071d8d03de20a8cd180fef264f0ee2635c51f6093bb89eaf47d5f4','POST /payments','201','{\"ok\":true,\"id\":46,\"allocated_minor\":7000000,\"unallocated_minor\":0}','2026-10-19 21:57:39');
/*FBEND*/
DROP TABLE IF EXISTS `invoice_lines`;
/*FBEND*/
CREATE TABLE `invoice_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `invoice_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `description` varchar(300) NOT NULL,
  `item_id` bigint(20) unsigned DEFAULT NULL,
  `warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `qty_milli` bigint(20) NOT NULL,
  `unit` varchar(20) NOT NULL DEFAULT 'adet',
  `unit_price_minor` bigint(20) NOT NULL,
  `discount_bp` int(11) NOT NULL DEFAULT 0,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `net_minor` bigint(20) NOT NULL,
  `vat_minor` bigint(20) NOT NULL,
  `total_minor` bigint(20) NOT NULL,
  `fulfilled_milli` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_il_inv` (`invoice_id`),
  CONSTRAINT `fk_il_inv` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `invoice_lines` VALUES ('1','1','1','1','Danışmanlık',NULL,NULL,'1000','adet','100000','0','2000','100000','20000','120000','0'),('2','1','3','1','Hakediş 1',NULL,NULL,'1000','adet','1000000','0','2000','1000000','200000','1200000','0'),('3','1','4','1','Malzeme',NULL,NULL,'1000','adet','400000','0','2000','400000','80000','480000','0'),('4','1','5','1','Kablo','1','1','10000','adet','10000','0','2000','100000','20000','120000','10000'),('5','1','6','1','Kalem',NULL,NULL,'1000','adet','100000','0','0','100000','0','100000','0'),('6','1','7','1','Kalem',NULL,NULL,'1000','adet','50000','0','0','50000','0','50000','0'),('7','1','8','1','Kalem',NULL,NULL,'1000','adet','50000','0','0','50000','0','50000','0'),('8','1','9','1','Kalem (düzeltilmiş)',NULL,NULL,'1000','adet','1200000','0','0','1200000','0','1200000','0'),('9','1','10','1','Kalem',NULL,NULL,'1000','adet','1000000','0','0','1000000','0','1000000','0'),('10','1','11','1','Kalem',NULL,NULL,'1000','adet','1000000','0','0','1000000','0','1000000','0'),('11','1','12','1','Kalem',NULL,NULL,'1000','adet','6000000','0','0','6000000','0','6000000','0'),('12','1','13','1','Kalem',NULL,NULL,'1000','adet','4500000','0','0','4500000','0','4500000','0'),('13','1','14','1','Kalem',NULL,NULL,'1000','adet','500000','0','0','500000','0','500000','0'),('14','1','15','1','Buzdolabı T4','2','1','3000','adet','1000000','0','2000','3000000','600000','3600000','3000'),('15','1','15','2','Televizyon T4','3','1','2000','adet','800000','0','2000','1600000','320000','1920000','2000'),('16','1','15','3','Nakliye T4','4',NULL,'1000','adet','50000','0','2000','50000','10000','60000','0'),('17','1','15','4','Serbest not satırı',NULL,NULL,'1000','adet','10000','0','0','10000','0','10000','0'),('18','1','16','1','buzdolabı t4','2','1','1000','adet','1000000','0','0','1000000','0','1000000','1000'),('19','1','17','1','Stoksuz giriş','5',NULL,'4000','adet','1000','0','0','4000','0','4000','0'),('20','1','19','1','Idem','7','1','1000','adet','100','0','0','100','0','100','1000'),('21','1','20','1','Buzdolabı satış','2','1','3000','adet','1500000','0','0','4500000','0','4500000','3000'),('23','1','22','1','Stoksuz','9','1','5000','adet','10000','0','0','50000','0','50000','2000'),('24','1','23','1','Stoksuz tedarik','9','1','5000','adet','6000','0','0','30000','0','30000','5000'),('25','1','24','1','Kalem',NULL,NULL,'1000','adet','2000000','0','0','2000000','0','2000000','0'),('26','1','25','1','İş',NULL,NULL,'1000','adet','10000000','0','0','10000000','0','10000000','0'),('27','1','26','1','İş',NULL,NULL,'1000','adet','10000000','0','0','10000000','0','10000000','0'),('28','1','27','1','Mal',NULL,NULL,'1000','adet','100000','0','0','100000','0','100000','0');
/*FBEND*/
DROP TABLE IF EXISTS `invoices`;
/*FBEND*/
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `kind` enum('sales','purchase') NOT NULL,
  `number` varchar(60) DEFAULT NULL,
  `contact_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `issue_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `status` enum('planned','issued','cancelled') NOT NULL DEFAULT 'issued',
  `subtotal_minor` bigint(20) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `total_minor` bigint(20) NOT NULL DEFAULT 0,
  `note` text DEFAULT NULL,
  `cancel_reason` varchar(300) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `dedupe_key` varchar(300) DEFAULT NULL,
  `defer_delivery` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_inv_dedupe` (`tenant_id`,`dedupe_key`),
  KEY `ix_inv_t` (`tenant_id`,`issue_date`),
  CONSTRAINT `fk_inv_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `invoices` VALUES ('1','1','1','sales','FB-2026-001','1',NULL,'2026-10-20','2026-11-04','TRY','issued','100000','20000','120000',NULL,NULL,NULL,'2','2026-10-19 21:57:07','a754d2aa8eeed97efccef5a323ae68f9e6c145b8a336eb2712976e6d4c2d2240','0'),('3','1','1','sales','PR-1','1','1','2026-10-20',NULL,'TRY','issued','1000000','200000','1200000',NULL,NULL,NULL,'2','2026-10-19 21:57:09','b8bc46e741c40ec3b74a4651c8dd1fa976d82fbcf0a1be20c7c81f4972a509ad','0'),('4','1','1','purchase','ALIS-9','2','1','2026-10-20',NULL,'TRY','issued','400000','80000','480000',NULL,NULL,NULL,'2','2026-10-19 21:57:09','7e15c3cdf198254634085553a61d00d96f61631d5e3c9d5ebf1177cfcda79456','0'),('5','1','1','purchase','STK-1','2',NULL,'2026-10-20',NULL,'TRY','issued','100000','20000','120000',NULL,NULL,NULL,'2','2026-10-19 21:57:09','f9a2c7eab1de39765fe12024afa7c15639f12f15ebebef3f0f3282fa95242c94','0'),('6','1','1','purchase','T4-1-2894','2',NULL,'2026-08-21',NULL,'TRY','issued','100000','0','100000',NULL,NULL,NULL,'2','2026-10-19 21:57:30','655500337e8bc501e14ea5e18e0f1c93bd57dcfe1a6879faa75aee34622c00e2','0'),('7','1','1','purchase','T4-2-fd54','2',NULL,'2026-10-20',NULL,'TRY','issued','50000','0','50000','sadece not',NULL,NULL,'2','2026-10-19 21:57:31','e30e13b37638b747f5acb7605b4cc4bd1fb415b309465b929039ed7ec2c1a472','0'),('8','1','1','purchase','T4-3-ef70','2',NULL,'2026-10-20','2026-12-04','TRY','issued','50000','0','50000',NULL,NULL,NULL,'2','2026-10-19 21:57:31','0887dbdfdd38aed2336a6621a8d00f3f697231e8060d3177ccc1bad2f250ad4f','0'),('9','1','1','purchase','T4-5-b743','2',NULL,'2026-10-20',NULL,'TRY','issued','1200000','0','1200000',NULL,NULL,NULL,'2','2026-10-19 21:57:31','5fe8dd61120f9f87737dd5b17a5f3583311ec358f8237a6652bf80f8dc74a229','0'),('10','1','1','purchase','T4-6-bd90','2',NULL,'2026-10-20',NULL,'TRY','issued','1000000','0','1000000',NULL,NULL,NULL,'2','2026-10-19 21:57:31','c8c4d0a67a27bfdeaca2ee86d10f908b959ac647b912a5bb7b29589796ab64de','0'),('11','1','1','purchase','T4-7-990c','2',NULL,'2026-10-20',NULL,'TRY','issued','1000000','0','1000000',NULL,NULL,NULL,'2','2026-10-19 21:57:32','72a4d12c16dace31f29a889d0b3608a10cc2f5c12cd6cd30074370b79f2b1e74','0'),('12','1','1','purchase','T4-8-3262','2',NULL,'2026-10-20',NULL,'TRY','issued','6000000','0','6000000',NULL,NULL,NULL,'2','2026-10-19 21:57:32','b89090dc1ffecbe9429c35ea493e0686ff2138548c730ce7470c25ecdc9b5c6d','0'),('13','1','1','purchase','T4-9-54d7','2',NULL,'2026-10-20',NULL,'TRY','issued','4500000','0','4500000',NULL,NULL,NULL,'2','2026-10-19 21:57:32','2e4f09965c33d98ec1b4c2b25c4f1ebdf023ab052420760a558d3c07f5756b5b','0'),('14','1','1','sales','T4-10-00d8','1',NULL,'2026-10-20',NULL,'TRY','issued','500000','0','500000',NULL,NULL,NULL,'2','2026-10-19 21:57:33','33c6639552646d9f8589bf6a02d654aebd587d55af4c32d40f57cd7da8ef95da','0'),('15','1','1','purchase','T4-STK-1','2',NULL,'2026-10-20',NULL,'TRY','issued','4660000','930000','5590000',NULL,NULL,NULL,'2','2026-10-19 21:57:33','e1ac5254b542481ebc8036b673ec23d57ec477cd765925e8a5581e79aa80aa51','0'),('16','1','1','purchase','T4-STK-2','2',NULL,'2026-10-20',NULL,'TRY','issued','1000000','0','1000000',NULL,NULL,NULL,'2','2026-10-19 21:57:34','c6744dea9981945fc0f907bffe09b2086d250fc7ef48f1c5ee7e3109e50ea926','0'),('17','1','1','purchase','T4-STK-3','2',NULL,'2026-10-20',NULL,'TRY','issued','4000','0','4000',NULL,NULL,NULL,'2','2026-10-19 21:57:34','ce05d1a80529a7c8550e2e6e342f17d7f3106eaeff60605ab0dc05c37537db37','0'),('19','1','1','purchase','T4-IDEM','2',NULL,'2026-10-20',NULL,'TRY','issued','100','0','100',NULL,NULL,NULL,'2','2026-10-19 21:57:34','a14dbf3ccf5544863fd18803b9b6543230df5f719b52e2ad5d546e37c2668f53','0'),('20','1','1','sales','T4-S-BZ','1',NULL,'2026-10-20',NULL,'TRY','cancelled','4500000','0','4500000',NULL,'müşteri vazgeçti','2026-10-19 21:57:35','2','2026-10-19 21:57:34','b846f7f8969fec18addb81f07e3380439c716b190f0c93696bced8118bbd4026','0'),('22','1','1','sales','T4-S-NO','1',NULL,'2026-10-20',NULL,'TRY','issued','50000','0','50000',NULL,NULL,NULL,'2','2026-10-19 21:57:35','bdf6d8bde42d0bde5010b566f66755e61b64925556c291ec3a003d471838c04f','0'),('23','1','1','purchase','T4-SUP-NO','2',NULL,'2026-10-20',NULL,'TRY','issued','30000','0','30000',NULL,NULL,NULL,'2','2026-10-19 21:57:35','f37b2b06e1d61b54548261d81dc7b53d8f379fc6cd554fd54ffb2a94cb67e5f1','0'),('24','1','1','purchase','T4-11-2d43','2',NULL,'2026-10-20',NULL,'TRY','issued','2000000','0','2000000',NULL,NULL,NULL,'2','2026-10-19 21:57:35','a911149b3c167d1853de592afa0e36dc2fcc3b41ffd89a706526e41b359be883','0'),('25','1','1','sales','HOME-1','4',NULL,'2026-10-20',NULL,'TRY','issued','10000000','0','10000000',NULL,NULL,NULL,'2','2026-10-19 21:57:38','802eaa9e5dec5bf3741d41a35f84fffb8c6fbf524c2d54c7e56482152f9fb06c','0'),('26','1','1','sales','HOME-2','5',NULL,'2026-10-20',NULL,'TRY','issued','10000000','0','10000000',NULL,NULL,NULL,'2','2026-10-19 21:57:39','2db1d2e1d0f25daa74f8343e8ab5fda6a283cf10c7081cea0187863d9aaf59fb','0'),('27','1','1','purchase','HOME-P1','2',NULL,'2026-10-20','2026-10-25','TRY','issued','100000','0','100000',NULL,NULL,NULL,'2','2026-10-19 21:57:39','eecb2094c884fea81c14757a257954083fcd315a0df08288073dc5e2af4e1253','0');
/*FBEND*/
DROP TABLE IF EXISTS `loan_installments`;
/*FBEND*/
CREATE TABLE `loan_installments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `loan_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `principal_minor` bigint(20) NOT NULL,
  `interest_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_li_t` (`tenant_id`,`loan_id`),
  KEY `fk_li_l` (`loan_id`),
  CONSTRAINT `fk_li_l` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `loan_installments` VALUES ('1','1','1','1','2026-11-20','894715','240000'),('2','1','1','2','2026-12-20','912609','222106'),('3','1','1','3','2027-01-20','930861','203854'),('4','1','1','4','2027-02-20','949479','185236'),('5','1','1','5','2027-03-20','968468','166247'),('6','1','1','6','2027-04-20','987838','146877'),('7','1','1','7','2027-05-20','1007594','127121'),('8','1','1','8','2027-06-20','1027746','106969'),('9','1','1','9','2027-07-20','1048301','86414'),('10','1','1','10','2027-08-20','1069267','65448'),('11','1','1','11','2027-09-20','1090653','44062'),('12','1','1','12','2027-10-20','1112469','22249');
/*FBEND*/
DROP TABLE IF EXISTS `loans`;
/*FBEND*/
CREATE TABLE `loans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `principal_minor` bigint(20) NOT NULL,
  `monthly_rate_bp` int(11) NOT NULL DEFAULT 0,
  `term_months` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `status` enum('active','closed','cancelled') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ln_t` (`tenant_id`),
  CONSTRAINT `fk_ln_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `loans` VALUES ('1','1','1','İşletme Kredisi',NULL,'TRY','12000000','200','12','2026-10-20','active','2026-10-19 21:57:08');
/*FBEND*/
DROP TABLE IF EXISTS `login_tickets`;
/*FBEND*/
CREATE TABLE `login_tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `token_hash` char(64) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `ip` varchar(64) NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_tickets_token` (`token_hash`),
  KEY `fk_tickets_user` (`user_id`),
  CONSTRAINT `fk_tickets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `login_tickets` VALUES ('1','08014c4fe5ce41359fb4b7399eeeb84f55ecc4b560bc140a64299a78cae14667','1','127.0.0.1','1','2026-10-19 21:59:34',NULL),('2','14062517eca09c78339a19a6d026847115a0565314b71ea9a0841e431e321be5','1','127.0.0.1','1','2026-10-19 21:59:34','2026-10-19 21:54:34'),('3','c4967d380b7dc0675c3f1829c3a37b6f9fc5a50ae7055441c42dd65891285e29','1','127.0.0.1','1','2026-10-19 21:59:37','2026-10-19 21:55:01'),('4','6d1b3d2651606800fe9b480b0c4477398a17ac4a1ac8a6f468cce8495fbee09a','1','127.0.0.1','1','2026-10-19 22:00:01','2026-10-19 21:55:32'),('5','520f0360332a6e16b7700d9e8de30b41cf5bb9a94e4bc5614f4b7f1b1b40097b','1','127.0.0.1','0','2026-10-19 22:00:32',NULL),('6','94d694aee814499be5e6e3a4f839a60eddf056e74ccd73e18b75be6fb713dca0','1','127.0.0.1','1','2026-10-19 22:00:32','2026-10-19 21:56:02'),('7','c627be5afbf9a080b748884d2ee5941282468360ff21236e637dba89d73f0fbd','1','127.0.0.1','1','2026-10-19 22:01:02','2026-10-19 21:56:32'),('8','fd58cae8cffed4e0bdb61b678052065f337ae3e542a745519f61c6b386a4b6b1','1','127.0.0.1','1','2026-10-19 22:01:32','2026-10-19 21:57:02'),('9','826a57e6fd3fe019f76de20ccd6d8ffdc32587031fb35cd50544ffa1c2925502','1','127.0.0.1','1','2026-10-19 22:02:11','2026-10-19 21:57:30'),('10','bb0aec9f9c2b1d54350f6addbca2099a6fab9168cd9e13db9ff2df1775fe5dc9','1','127.0.0.1','1','2026-10-19 22:02:39','2026-10-19 21:58:00');
/*FBEND*/
DROP TABLE IF EXISTS `password_tokens`;
/*FBEND*/
CREATE TABLE `password_tokens` (
  `token_hash` char(64) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `purpose` enum('reset','invite') NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`token_hash`),
  KEY `ix_pt_user` (`user_id`),
  CONSTRAINT `fk_pt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `password_tokens` VALUES ('0bcb1387ee2f3fb9a4da991b021c09991310cb1ccba548bf289fa4ec6b7bcd28','2','reset','2026-10-19 22:27:05','2026-10-19 21:57:05',NULL,'2026-10-19 21:57:05'),('5c4477e4e0b51031f925ad51abdcca8106aa988aa75136e81833bb5eee37a63b','2','invite','2026-10-22 21:57:03','2026-10-19 21:57:03','1','2026-10-19 21:57:03');
/*FBEND*/
DROP TABLE IF EXISTS `payment_allocations`;
/*FBEND*/
CREATE TABLE `payment_allocations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `txn_id` bigint(20) unsigned NOT NULL,
  `entry_id` bigint(20) unsigned NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `status` enum('active','reversed') NOT NULL DEFAULT 'active',
  `note` varchar(300) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `reversed_at` datetime DEFAULT NULL,
  `reversed_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_pa_txn` (`tenant_id`,`txn_id`,`status`),
  KEY `ix_pa_entry` (`tenant_id`,`entry_id`,`status`),
  KEY `fk_pa_txn` (`txn_id`),
  KEY `fk_pa_entry` (`entry_id`),
  CONSTRAINT `fk_pa_entry` FOREIGN KEY (`entry_id`) REFERENCES `entries` (`id`),
  CONSTRAINT `fk_pa_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`),
  CONSTRAINT `fk_pa_txn` FOREIGN KEY (`txn_id`) REFERENCES `transactions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `payment_allocations` VALUES ('1','1','1','1','6000000','active',NULL,'2','2026-10-19 21:57:06',NULL,NULL),('2','1','2','1','4000000','active',NULL,'2','2026-10-19 21:57:06',NULL,NULL),('3','1','5','5','120000','active',NULL,'2','2026-10-19 21:57:07',NULL,NULL),('4','1','9','8','300000','active',NULL,'2','2026-10-19 21:57:07',NULL,NULL),('5','1','14','10','1200000','active',NULL,'2','2026-10-19 21:57:09',NULL,NULL),('6','1','15','11','480000','active',NULL,'2','2026-10-19 21:57:09',NULL,NULL),('7','1','25','17','400000','active',NULL,'2','2026-10-19 21:57:31',NULL,NULL),('8','1','26','17','600000','active',NULL,'2','2026-10-19 21:57:31',NULL,NULL),('9','1','27','18','1000000','reversed',NULL,'2','2026-10-19 21:57:32','2026-10-19 21:57:32','2'),('10','1','28','19','1000000','active',NULL,'2','2026-10-19 21:57:32',NULL,NULL),('11','1','28','20','4000000','active',NULL,'2','2026-10-19 21:57:32',NULL,NULL),('12','1','27','21','2000000','reversed',NULL,'2','2026-10-19 21:57:32','2026-10-19 21:57:32','2'),('13','1','27','20','1500000','active',NULL,'2','2026-10-19 21:57:32',NULL,NULL),('14','1','27','21','500000','active',NULL,'2','2026-10-19 21:57:32',NULL,NULL),('15','1','32','22','500000','active',NULL,'2','2026-10-19 21:57:33',NULL,NULL),('16','1','33','29','50000','active',NULL,'2','2026-10-19 21:57:35',NULL,NULL),('17','1','34','31','2000000','active',NULL,'2','2026-10-19 21:57:36',NULL,NULL),('18','1','41','33','4000','active',NULL,'2','2026-10-19 21:57:37',NULL,NULL),('19','1','42','34','3000000','active',NULL,'2','2026-10-19 21:57:38',NULL,NULL),('20','1','43','35','3000000','active',NULL,'2','2026-10-19 21:57:39',NULL,NULL),('21','1','46','35','7000000','active',NULL,'2','2026-10-19 21:57:39',NULL,NULL);
/*FBEND*/
DROP TABLE IF EXISTS `project_milestones`;
/*FBEND*/
CREATE TABLE `project_milestones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `due_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `entry_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pm_t` (`tenant_id`),
  CONSTRAINT `fk_pm_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `project_milestones` VALUES ('1','1','1','Hakediş 2','2026-11-19','2000000','12','2026-10-19 21:57:09');
/*FBEND*/
DROP TABLE IF EXISTS `project_quotes`;
/*FBEND*/
CREATE TABLE `project_quotes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned NOT NULL,
  `kind` enum('quote','order') NOT NULL DEFAULT 'quote',
  `number` varchar(60) DEFAULT NULL,
  `quote_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `status` enum('draft','sent','accepted','rejected') NOT NULL DEFAULT 'draft',
  `note` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pq_t` (`tenant_id`),
  CONSTRAINT `fk_pq_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
DROP TABLE IF EXISTS `projects`;
/*FBEND*/
CREATE TABLE `projects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(160) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `contract_minor` bigint(20) NOT NULL DEFAULT 0,
  `est_cost_minor` bigint(20) NOT NULL DEFAULT 0,
  `status` enum('planned','active','done','cancelled') NOT NULL DEFAULT 'active',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_pr_t` (`tenant_id`),
  CONSTRAINT `fk_pr_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `projects` VALUES ('1','1','1','1','Santral Kurulumu','TRY','5000000','3000000','active',NULL,NULL,NULL,'0','2026-10-19 21:57:09');
/*FBEND*/
DROP TABLE IF EXISTS `rate_limits`;
/*FBEND*/
CREATE TABLE `rate_limits` (
  `k` varchar(120) NOT NULL,
  `hits` int(11) NOT NULL,
  `window_start` datetime NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `rate_limits` VALUES ('2fa_enable:1','2','2026-10-19 21:54:34'),('2fa_ip:127.0.0.1','9','2026-10-19 21:54:34'),('adm_acc:1:1:accounts','1','2026-10-19 21:57:30'),('adm_acc:1:1:reports','1','2026-10-19 21:57:30'),('adm_acc:1:1:transactions','1','2026-10-19 21:57:30'),('api_ip:127.0.0.1','609','2026-10-19 21:57:03'),('api_user:1','19','2026-10-19 21:57:03'),('api_user:2','467','2026-10-19 21:57:04'),('api_user:3','38','2026-10-19 21:57:03'),('captcha_ip:127.0.0.1','40','2026-10-19 21:54:34'),('forgot_id:10b002daf7d0d7bb6ce4ddb1eace6e6ea8797dc2ae8eac370896018434fdc32b','1','2026-10-19 21:57:05'),('forgot_id:9d158211d6d187975b6ea8731d701836746c45264805fb516c4b825d77575a12','1','2026-10-19 21:57:05'),('forgot_ip:127.0.0.1','2','2026-10-19 21:57:05'),('honeypot:127.0.0.1','1','2026-10-19 21:57:03'),('login_id:2adbc0b959b6cefa8a28619eba9556a8b3e989948da312fdc252299441054066','11','2026-10-19 21:54:34'),('login_id:9d158211d6d187975b6ea8731d701836746c45264805fb516c4b825d77575a12','15','2026-10-19 21:57:04'),('login_id:bf7af099680062112c03af6bf21788199efd3be7eb5577030428c546327e2d13','1','2026-10-19 21:57:03'),('login_id:d3206c76a6d95265cea4f2b55e315c420f7dadad3198cdfba7831a080179d026','7','2026-10-19 21:57:03'),('login_ip:127.0.0.1','40','2026-10-19 21:54:34'),('pwchange:3','4','2026-10-19 21:57:03'),('reset_ip:127.0.0.1','4','2026-10-19 21:57:03');
/*FBEND*/
DROP TABLE IF EXISTS `recurring_templates`;
/*FBEND*/
CREATE TABLE `recurring_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `entry_kind` enum('receivable','payable') NOT NULL,
  `title` varchar(200) NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `frequency` enum('weekly','monthly','yearly') NOT NULL DEFAULT 'monthly',
  `next_date` date NOT NULL,
  `anchor_day` tinyint(4) NOT NULL DEFAULT 1,
  `end_date` date DEFAULT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `last_generated` date DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_rt_t` (`tenant_id`),
  CONSTRAINT `fk_rt_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `recurring_templates` VALUES ('1','1','1','payable','Aylık abonelik','30000','TRY',NULL,NULL,'monthly','2026-12-23','23',NULL,'1','2026-10-20','2026-10-19 21:57:06');
/*FBEND*/
DROP TABLE IF EXISTS `schema_migrations`;
/*FBEND*/
CREATE TABLE `schema_migrations` (
  `version` varchar(100) NOT NULL,
  `checksum` char(64) NOT NULL,
  `applied_at` datetime NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*FBEND*/
INSERT INTO `schema_migrations` VALUES ('001_core','2d7a0f529b8d465b588d781044a60d9cb4baf28da2486cf3fea7a419c77b2087','2026-10-19 21:54:33'),('002_finance','280896f0df01ee75f67ba9f9195332cffca21c8e6a49a5c4c3626a6abd726ced','2026-10-19 21:54:33'),('003_payments_allocations','64f57c10b2fca0825123cf9bfe36db39250c1789b8cf7b2c1a1c8eef9a37b87c','2026-10-19 21:54:33'),('004_planned_dates','d7b59bc0ce7bd1a5010ac728fe803eb2ad31bf0d17355987959945fbfdf62ccb','2026-10-19 21:54:33');
/*FBEND*/
DROP TABLE IF EXISTS `sessions`;
/*FBEND*/
CREATE TABLE `sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `token_hash` char(64) NOT NULL,
  `prev_token_hash` char(64) DEFAULT NULL,
  `prev_valid_until` datetime DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `epoch` int(11) NOT NULL,
  `csrf_secret` char(64) NOT NULL,
  `ip` varchar(64) NOT NULL,
  `ua_hash` char(64) NOT NULL,
  `label` varchar(160) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `last_seen_at` datetime NOT NULL,
  `rotated_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `revoked_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sessions_token` (`token_hash`),
  KEY `ix_sessions_prev` (`prev_token_hash`),
  KEY `ix_sessions_user` (`user_id`),
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `sessions` VALUES ('1','e9f5bc13e5f0db5dc10f07f9e020843ac0f8728c0bd2c98f59425be19e2c9cf2',NULL,'2026-10-19 21:54:32','1','2','308edecd61eff7213aaf9b370c392e7ad46a94fc408c3723b211e203cdb396b4','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:54:34','2026-10-19 21:54:34','2026-10-19 21:54:34','2026-10-20 09:54:34',NULL),('2','0776f0324188561aab1623540ee696f1816d45e75bd8a8e1eb175ac6224b043d','da6de8b2f2ac8f139499d8d91c76de168c895564b9393268e4a706a0959047d0','2026-10-19 21:54:32','1','2','acfe58646a0b80aaa8d7185da5bdf1217d53b527d0bea034c48e83fbf010803d','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:54:34','2026-10-19 21:54:37','2026-10-19 21:54:37','2026-10-20 09:54:34',NULL),('3','607f1ae0f27687f004e6e95b36ad425e3c6ee28d768a320af572432634409550',NULL,NULL,'1','2','fb0be7bbaaaf9db8977859b0b093d84590ecdd03d872c42a3c894062651d142f','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:55:01','2026-10-19 21:55:01','2026-10-19 21:55:01','2026-10-20 09:55:01',NULL),('4','f8c0ddd6a70a7d2e8a10503e12e0aa7e188305da98d7a260fbdac72d770a3cca',NULL,NULL,'1','2','e51b529c4280fb20f06e431dc0dd743287d4e08f0381a126f8b794111b437af6','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:55:32','2026-10-19 21:55:32','2026-10-19 21:55:32','2026-10-20 09:55:32','2026-10-19 21:55:32'),('5','54113f1761a8d4f9b1d608b0248734bc80a050207a00b4323f7e87ae4eea9f86',NULL,NULL,'1','2','2838321700b56b0ae90d35817d63bc93e43d1d87e29ac370e3339f46de6f5943','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:56:02','2026-10-19 21:56:02','2026-10-19 21:56:02','2026-10-20 09:56:02',NULL),('6','c879b3a24b13cff1b21e8baa079b6669dab43f3fef9a66b4f96f5c98ec07a3d8',NULL,NULL,'1','2','14528434340f2ac34a57696a27aba730dfdc239f749f527c1708f37dae27023f','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:56:32','2026-10-19 21:56:32','2026-10-19 21:56:32','2026-10-20 09:56:32',NULL),('7','8561de7d6aec7e0a13d7e85903248a287cb8b1acdbb268338a314ed1a46788ad','7a214d77963383defe02a08811720963c7b8eccb117f1a682f9ac1775cbc2777','2026-10-19 21:58:05','1','2','807f4b8ee19e3ec4b2d817d9311d8c2a0d40073b7f49014f06f40538319185f0','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:02','2026-10-19 21:57:05','2026-10-19 21:57:05','2026-10-20 09:57:02',NULL),('8','c738cde3e92c28941204ccb77b8907689d6a0ae9d69ed1270a99821d1eead153',NULL,NULL,'3','1','e7cbb0243639f3d1127b89ad853af34db324effad22cc20c58a884ff5b1a99b0','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:03','2026-10-19 21:57:03','2026-10-19 21:57:03','2026-10-20 09:57:03','2026-10-19 21:57:03'),('9','b627502bd05c7a40d8f859bf765d5ce574d79c03bf6d2aad84e312d39953139a',NULL,NULL,'3','2','ae1fe2ef7175764ad9db9696d30260869f9a86a99f104ede753f12b269ffd1f8','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:03','2026-10-19 21:57:03','2026-10-19 21:57:03','2026-10-20 09:57:03','2026-10-19 21:57:05'),('10','e2049d66234019dff678178388200110173d648f6c0e1633cb186070379f20ba',NULL,NULL,'2','2','62bc895ad74cc20d80c4c74c8ad965e38f9262d1395ac601e610a43e2f2d9193','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:04','2026-10-19 21:57:04','2026-10-19 21:57:04','2026-10-20 09:57:04','2026-10-19 21:57:04'),('11','41ab5eca4b39ec1610090d27a8310e6b44b1fc1d338441062841bd39963f6ba7',NULL,NULL,'2','2','200f1c63c16ee2b46d7ebadc37e9f9928e9e20ad4d0db314102817eecc46df24','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:04','2026-10-19 21:57:04','2026-10-19 21:57:04','2026-10-20 09:57:04','2026-10-19 21:57:05'),('12','291d38eb20dcb3a36d99910c0eb41f5a6574bbce33836d80817843382f1b5070',NULL,NULL,'2','2','f8a43fa3e09c583932d3a8152164593186c050a8833853c21e848e6eea8b7cca','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:05','2026-10-19 21:57:05','2026-10-19 21:57:05','2026-10-20 09:57:05','2026-10-19 21:57:05'),('13','16f7a0f2b59b5fe24b02ac1803ed620a2e3ec4870f7e8e1bd8385198258835e1',NULL,NULL,'2','2','70f195d614388aa8af34462a6c2f56f0f02080cb7660a11c0eaf6e8f9789c654','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:05','2026-10-19 21:57:05','2026-10-19 21:57:05','2026-10-20 09:57:05','2026-10-19 21:57:05'),('14','39a799832cb777d6fe0aea424e7a45f94ee8124c6a4f56be7b678878e9fc81ef',NULL,NULL,'2','3','c43f3e48949abf8f9865b3bb61b302891279aca3df7be3ad1f04bd2cad9ab523','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:05','2026-10-19 21:57:05','2026-10-19 21:57:05','2026-10-20 09:57:05','2026-10-19 21:57:30'),('15','08f65489b21e900673e26804d6d8ea23b9a1b7fd9d2f0a357564537b4b846e89',NULL,NULL,'3','2','100bbe8558ba1b23dba1d1532079a38ce9b3b514639f65c2b74687f5ee0e6c92','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:05','2026-10-19 21:57:05','2026-10-19 21:57:05','2026-10-20 09:57:05','2026-10-19 21:57:05'),('16','5748b344090b19c4e45e9444b90b04ed9cdf398b25ff6c4a7a1205593f8a0c03',NULL,NULL,'3','3','2f5e6dd922d81e8dc3e3f417ef71cbec3a240b1223500f63e87a5b86071039a2','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:05','2026-10-19 21:57:05','2026-10-19 21:57:05','2026-10-20 09:57:05',NULL),('17','a582719ee56f2d5eb68c507d784a81887ca84450ee26e5d1ba893da518a2d877','5ae8dbe560f15a114281325175b8d4b41565efd2c4d1ef48a6afa1f1e74eb84e','2026-10-19 21:58:30','2','3','2e2c0087da509ed883bbe5608fc2ee3110b864f4ffc58be18a340fbf157940d5','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:05','2026-10-19 21:57:30','2026-10-19 21:57:30','2026-10-20 09:57:05','2026-10-19 21:57:30'),('18','eea203166218d52ae29de92a96dd8047704acb3fed3983fc4480300e983349bc','50cacbb4cd8094649eb4b6958a27480224f3fa32a9fdca33ae41159c0909561d','2026-10-19 21:58:10','3','3','08a40cea391a899abcbf520c2f1033181a5c82e5950de3dc90d23f7330768a37','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:06','2026-10-19 21:57:10','2026-10-19 21:57:10','2026-10-20 09:57:06',NULL),('19','b71e331f9f0b7c804aa085a538459dc4f4a87e2f221509f864459fe726cb97a5',NULL,NULL,'1','2','a20bf1fce6a1fd83eb67f81cd3a4d6e688baa74c3287455f835a040885a9c539','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:30','2026-10-19 21:57:30','2026-10-19 21:57:30','2026-10-20 09:57:30',NULL),('20','fefc23477e09341f6a67e0384dab8fb12ba41aeb62ec528f6d6f9063fbb6f4a1','06f7d64b2714a1e40412edb6227808c70a663b8f7403f09b2c89e7a3a86c2207','2026-10-19 21:58:36','2','4','74f6ddb7af8e42e88d10fc02a61404be98125c724ec71e19b12a1b65867ff1c2','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:30','2026-10-19 21:57:36','2026-10-19 21:57:36','2026-10-20 09:57:30',NULL),('21','f58c895440495240e1134f88b1aa6e07c6954615cabe7e83024de55db6b88572','68fdfb88fdfe797f68228ff543d9e3c528aebcf20f997d000912c19455c2ef2c','2026-10-19 21:58:37','3','3','ed81fc4a7cb3823c3d67c10f71e52f7dc90882dd39deb1f55b17655959d08644','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:30','2026-10-19 21:57:37','2026-10-19 21:57:37','2026-10-20 09:57:30',NULL),('22','bfc1c37267d00bb44de738b6c5a7d0337a5c6fa27907104203a5c149046d6a2f',NULL,NULL,'2','4','3a918dafd0eef4ab0401d80193c787bab89eecd75e642ee04af1c4ca283da678','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:38','2026-10-19 21:57:38','2026-10-19 21:57:38','2026-10-20 09:57:38',NULL),('23','ee294d9d7b4081b91e69733bc6b589275de1fa1905dbd7479c66eaa0d2f5461e',NULL,NULL,'3','3','e0f76b46012cb5ab99beda1f877c03045a3e3112a6b32f67ab1a6fe69dd9b54d','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:38','2026-10-19 21:57:38','2026-10-19 21:57:38','2026-10-20 09:57:38',NULL),('24','6627e7677bd412e863684342af2ffd4030c84791a872c43786b8b88dc5fa78ac','cc639b775626e67d00c6502a7228b29cd9c2207f323b19ca87710beb0fa6eb03','2026-10-19 21:59:00','2','4','6a0e278ac5559998bb8c258e6ffac4dfdab6c64dddf41a742bed9a2e985b5905','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:57:39','2026-10-19 21:58:00','2026-10-19 21:58:00','2026-10-20 09:57:39',NULL),('25','26b57fc012c545e5d05f7ebb6f73376a4d4b7fcc973417408386b7ee706af792',NULL,NULL,'1','2','cdcbe430dbff9de8ebde634a426396ed5e95863e61f7457ba0e41a762630b422','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:58:00','2026-10-19 21:58:00','2026-10-19 21:58:00','2026-10-20 09:58:00',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `statement_lines`;
/*FBEND*/
CREATE TABLE `statement_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `line_date` date NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `line_hash` char(64) NOT NULL,
  `matched_txn_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('unmatched','matched','ignored') NOT NULL DEFAULT 'unmatched',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sl_hash` (`tenant_id`,`account_id`,`line_hash`),
  CONSTRAINT `fk_sl_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `statement_lines` VALUES ('1','1','1','2026-10-20','POS TAHSILAT','25000','2dd70cd3ad2358a7943c0e8cac8c05d73ae6b21e9d93ef0e63fb60ee1c70cd29','13','matched','2026-10-19 21:57:08'),('2','1','1','2026-10-20','KOMISYON','-500','6ab4bf50d5e6e6224b07dfaa833e7336a0a25f2c620a77c0244f5807239ae01d',NULL,'unmatched','2026-10-19 21:57:08'),('3','1','1','2026-10-20','KOMISYON','-500','982e8957d68f530fe63e2ee3fadbda5c9c4640deb1e8a5a1e1faae6365fca202',NULL,'unmatched','2026-10-19 21:57:08');
/*FBEND*/
DROP TABLE IF EXISTS `stock_items`;
/*FBEND*/
CREATE TABLE `stock_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('product','service') NOT NULL DEFAULT 'product',
  `code` varchar(60) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `unit` varchar(20) NOT NULL DEFAULT 'adet',
  `barcode` varchar(60) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `sale_price_minor` bigint(20) NOT NULL DEFAULT 0,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 2000,
  `min_qty_milli` bigint(20) NOT NULL DEFAULT 0,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_si_code` (`tenant_id`,`code`),
  CONSTRAINT `fk_si_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `stock_items` VALUES ('1','1','product','KBL-1','Kablo 10m','adet',NULL,'TRY','0','2000','0','0','2026-10-19 21:57:09'),('2','1','product','BZD-T4','Buzdolabı T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 21:57:33'),('3','1','product',NULL,'Televizyon T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 21:57:33'),('4','1','service',NULL,'Nakliye T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 21:57:33'),('5','1','product',NULL,'Stoksuz giriş','adet',NULL,'TRY','0','2000','0','0','2026-10-19 21:57:34'),('7','1','product','IDM-1','Idem','adet',NULL,'TRY','0','2000','0','0','2026-10-19 21:57:34'),('8','1','product','DEL-1','Silinecek','adet',NULL,'TRY','0','2000','0','0','2026-10-19 21:57:35'),('9','1','product','NOSTK','Stoksuz Ürün T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 21:57:35');
/*FBEND*/
DROP TABLE IF EXISTS `stock_movements`;
/*FBEND*/
CREATE TABLE `stock_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `warehouse_id` bigint(20) unsigned NOT NULL,
  `kind` enum('in','out','return_in','return_out') NOT NULL,
  `qty_milli` bigint(20) NOT NULL,
  `unit_cost_minor` bigint(20) NOT NULL DEFAULT 0,
  `move_date` date NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_sm_t` (`tenant_id`,`item_id`),
  KEY `ix_sm_inv` (`invoice_id`),
  CONSTRAINT `fk_sm_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `stock_movements` VALUES ('1','1','1','1','in','10000','10000','2026-10-20',NULL,'5','Alış faturası','posted','2026-10-19 21:57:09'),('2','1','1','1','out','2000','10000','2026-10-20','1',NULL,NULL,'posted','2026-10-19 21:57:09'),('3','1','1','1','out','9000','10000','2026-10-20',NULL,NULL,NULL,'posted','2026-10-19 21:57:09'),('4','1','2','1','in','5000','1000000','2026-10-20',NULL,'15','Alış faturası','posted','2026-10-19 21:57:33'),('5','1','3','1','in','2000','800000','2026-10-20',NULL,'15','Alış faturası','posted','2026-10-19 21:57:33'),('6','1','2','1','in','2000','1000000','2026-10-20',NULL,'15','Alış faturası','posted','2026-10-19 21:57:34'),('7','1','2','1','return_out','4000','1000000','2026-10-20',NULL,'15','Alış faturası (düzeltme)','posted','2026-10-19 21:57:34'),('8','1','2','1','in','1000','1000000','2026-10-20',NULL,'16','Alış faturası','posted','2026-10-19 21:57:34'),('9','1','7','1','in','1000','100','2026-10-20',NULL,'19','Alış faturası','posted','2026-10-19 21:57:34'),('10','1','2','1','out','3000','1000000','2026-10-20',NULL,'20','Satış faturası','voided','2026-10-19 21:57:34'),('12','1','9','1','in','5000','6000','2026-10-20',NULL,'23','Alış faturası','posted','2026-10-19 21:57:35'),('13','1','9','1','out','2000','6000','2026-10-20',NULL,'22','Satış faturası','posted','2026-10-19 21:57:35');
/*FBEND*/
DROP TABLE IF EXISTS `system_settings`;
/*FBEND*/
CREATE TABLE `system_settings` (
  `k` varchar(80) NOT NULL,
  `v` mediumtext DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
DROP TABLE IF EXISTS `tenants`;
/*FBEND*/
CREATE TABLE `tenants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `company_name` varchar(200) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `status` enum('active','suspended','archived') NOT NULL DEFAULT 'active',
  `settings` mediumtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tenants_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `tenants` VALUES ('1','Alfa Ltd','Alfa Ticaret',NULL,'active','{\"locale\":\"tr-TR\",\"theme\":\"dark\",\"date_format\":\"DD.MM.YYYY\",\"default_workspace_id\":null,\"default_account_id\":1,\"vat_rates\":[0,800,1000,2000],\"preferred_currency\":\"TRY\",\"notify\":{\"due\":true,\"overdue\":true,\"card\":true,\"bills\":false,\"email\":false},\"invoice\":{\"prefix\":\"\",\"default_due_days\":30,\"note\":\"\"},\"stock\":{\"allow_negative\":false}}','1','2026-10-19 21:57:03','2026-10-19 21:57:39',NULL),('2','Beta AŞ',NULL,NULL,'active','{\"locale\":\"tr-TR\",\"notify\":{\"due\":true,\"overdue\":true,\"card\":true,\"bills\":true,\"email\":false}}','1','2026-10-19 21:57:03','2026-10-19 21:57:38',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `transactions`;
/*FBEND*/
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `direction` enum('in','out') NOT NULL,
  `kind` enum('income','expense','collection','payment','transfer','fx','card_payment','loan_payment','loan_proceeds','adjustment','owner_in','owner_out') NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `interest_minor` bigint(20) NOT NULL DEFAULT 0,
  `currency` char(3) NOT NULL,
  `txn_date` date NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `entry_id` bigint(20) unsigned DEFAULT NULL,
  `card_id` bigint(20) unsigned DEFAULT NULL,
  `loan_id` bigint(20) unsigned DEFAULT NULL,
  `loan_installment_id` bigint(20) unsigned DEFAULT NULL,
  `transfer_group` varchar(26) DEFAULT NULL,
  `fx_rate` decimal(18,8) DEFAULT NULL,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `void_reason` varchar(300) DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `voided_by` bigint(20) unsigned DEFAULT NULL,
  `replaces_id` bigint(20) unsigned DEFAULT NULL,
  `statement_line_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `reason` varchar(300) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `method` varchar(30) DEFAULT NULL,
  `for_workspace_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tx_acc` (`tenant_id`,`account_id`,`status`),
  KEY `ix_tx_date` (`tenant_id`,`txn_date`),
  KEY `ix_tx_entry` (`entry_id`),
  KEY `ix_tx_group` (`transfer_group`),
  KEY `fk_tx_a` (`account_id`),
  KEY `ix_tx_contact` (`tenant_id`,`contact_id`),
  KEY `ix_tx_forws` (`tenant_id`,`for_workspace_id`),
  CONSTRAINT `fk_tx_a` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `fk_tx_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `transactions` VALUES ('1','1','1','1','in','collection','6000000','0','TRY','2026-10-20','Tahsilat: Büyük satış',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:06',NULL,NULL,NULL,NULL),('2','1','1','1','in','collection','4000000','0','TRY','2026-10-20','Tahsilat: Büyük satış',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:06',NULL,NULL,NULL,NULL),('3','1','1','1','out','transfer','2000000','0','TRY','2026-10-20','Transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'23ed00896d9c17631ba3793d8d',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:06',NULL,NULL,NULL,NULL),('4','1','1','2','in','transfer','2000000','0','TRY','2026-10-20','Transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'23ed00896d9c17631ba3793d8d',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:06',NULL,NULL,NULL,NULL),('5','1','1','1','in','collection','120000','0','TRY','2026-10-20','Tahsilat: Satış faturası FB-2026-001 — Müşteri A',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:07',NULL,NULL,NULL,NULL),('6','1','1','1','out','fx','1000000','0','TRY','2026-10-20','Döviz: TRY→EUR kur 0.02500000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'cf77304c65e5b6d9ca0b7b91da','0.02500000','0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:07',NULL,NULL,NULL,NULL),('7','1','1','3','in','fx','25000','0','EUR','2026-10-20','Döviz: TRY→EUR kur 0.02500000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'cf77304c65e5b6d9ca0b7b91da','0.02500000','0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:07',NULL,NULL,NULL,NULL),('8','1','1','1','out','expense','1500','0','TRY','2026-10-20','Döviz işlem masrafı','14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:07',NULL,NULL,NULL,NULL),('9','1','1','1','out','payment','300000','0','TRY','2026-10-20','Ödeme: Tedarikçi borcu',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:07',NULL,NULL,NULL,NULL),('10','1','1','1','out','card_payment','40000','0','TRY','2026-10-20','Kart ödemesi: Kurumsal Kart',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:08',NULL,NULL,NULL,NULL),('11','1','1','1','in','loan_proceeds','12000000','0','TRY','2026-10-20','Kredi kullandırım: İşletme Kredisi',NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:08',NULL,NULL,NULL,NULL),('12','1','1','1','out','loan_payment','1134715','240000','TRY','2026-10-20','Kredi taksiti 1/12: İşletme Kredisi',NULL,NULL,NULL,NULL,NULL,'1','1',NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:08',NULL,NULL,NULL,NULL),('13','1','1','1','in','income','25000','0','TRY','2026-10-20','POS TAHSILAT','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,'1','2','2026-10-19 21:57:09',NULL,NULL,NULL,NULL),('14','1','1','1','in','collection','1200000','0','TRY','2026-10-20','Tahsilat: Satış faturası PR-1 — Müşteri A',NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:09',NULL,NULL,NULL,NULL),('15','1','1','1','out','payment','480000','0','TRY','2026-10-20','Ödeme: Alış faturası ALIS-9 — Tedarikçi B',NULL,'2','1',NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:09',NULL,NULL,NULL,NULL),('16','1','1','1','out','expense','50000','0','TRY','2026-10-20','Yakıt','6',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:09',NULL,NULL,NULL,NULL),('17','1','1','1','in','income','100000','0','TRY','2026-10-20','Çift tık testi','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','Hatalı giriş','2026-10-19 21:57:09','2',NULL,NULL,'2','2026-10-19 21:57:09',NULL,NULL,NULL,NULL),('18','1','1','1','out','expense','10000','0','TRY','2026-10-20','eski',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','Düzenleme ile yenisi oluşturuldu','2026-10-19 21:57:10','2',NULL,NULL,'2','2026-10-19 21:57:10',NULL,NULL,NULL,NULL),('19','1','1','1','out','expense','12000','0','TRY','2026-10-20','düzeltilmiş',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,'18',NULL,'2','2026-10-19 21:57:10',NULL,NULL,NULL,NULL),('20','1','1','1','out','expense','120000','0','TRY','2026-10-20','KDV dahil',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2000','20000','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:10',NULL,NULL,NULL,NULL),('21','1','1','1','out','expense','120000','0','TRY','2026-10-20','KDV hariç',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2000','20000','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:10',NULL,NULL,NULL,NULL),('22','1','1','2','out','adjustment','5000','0','TRY','2026-10-20','Bakiye düzeltme: Sayım farkı',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:10',NULL,NULL,NULL,NULL),('23','1','1','1','out','expense','100','0','TRY','2026-10-20','=HYPERLINK(\"http://evil\",\"x\")',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:11',NULL,NULL,NULL,NULL),('24','1','1','1','out','expense','7700','0','TRY','2026-10-20','admin düzeltilecek',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','[Yönetici düzeltmesi] Mükerrer giriş','2026-10-19 21:57:30','1',NULL,NULL,'2','2026-10-19 21:57:30',NULL,NULL,NULL,NULL),('25','1','1','1','out','payment','400000','0','TRY','2026-10-20','Ödeme: Alış faturası T4-5-b743 — Tedarikçi B',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:31','Kısmi ödeme',NULL,NULL,NULL),('26','1','1','1','out','payment','600000','0','TRY','2026-10-20','Ödeme: Alış faturası T4-5-b743 — Tedarikçi B',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:31',NULL,NULL,NULL,NULL),('27','1','1','1','out','payment','3000000','0','TRY','2026-10-20','Toplu gönderim',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:32',NULL,NULL,NULL,NULL),('28','1','1','1','out','payment','5000000','0','TRY','2026-10-20','Ödeme: Alış faturası T4-7-990c — Tedarikçi B',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','test iptal','2026-10-19 21:57:33','2',NULL,NULL,'2','2026-10-19 21:57:32',NULL,NULL,NULL,NULL),('29','1','1','2','out','payment','10000','0','TRY','2026-10-20','çift tık',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:33',NULL,NULL,NULL,NULL),('30','1','1','1','out','payment','7000','0','TRY','2026-10-20','Ödeme',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:33',NULL,'DKN-77',NULL,NULL),('31','1','1','1','out','payment','7000','0','TRY','2026-10-20','Ödeme',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:33',NULL,'DKN-77',NULL,NULL),('32','1','1','1','in','collection','800000','0','TRY','2026-10-20','Tahsilat: Satış faturası T4-10-00d8 — Müşteri A',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:33',NULL,NULL,NULL,NULL),('33','1','1','1','in','collection','50000','0','TRY','2026-10-20','Tahsilat: Satış faturası T4-S-NO — Müşteri A',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:35',NULL,NULL,NULL,NULL),('34','1','2','5','out','payment','2000000','0','TRY','2026-10-20','dekont eklendi',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:36','Güncel neden','SAHSI-1','transfer','1'),('35','1','2','5','out','owner_in','700000','0','TRY','2026-10-20','Sermaye',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'85572d4e6f3f01ce7b11a238da',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:36',NULL,NULL,NULL,NULL),('36','1','1','1','in','owner_in','700000','0','TRY','2026-10-20','Sermaye',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'85572d4e6f3f01ce7b11a238da',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:36',NULL,NULL,NULL,NULL),('37','1','1','1','out','owner_out','2700000','0','TRY','2026-10-20','Geri ödeme',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'a03bf7b9c2ed483901effa0c81',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:36',NULL,NULL,NULL,NULL),('38','1','2','5','in','owner_out','2700000','0','TRY','2026-10-20','Geri ödeme',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'a03bf7b9c2ed483901effa0c81',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:36',NULL,NULL,NULL,NULL),('39','1','1','1','out','transfer','1000','0','TRY','2026-10-20','iç transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'815b58ee04451887fbe0cc17b8',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:36',NULL,NULL,NULL,NULL),('40','1','1','2','in','transfer','1000','0','TRY','2026-10-20','iç transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'815b58ee04451887fbe0cc17b8',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:36',NULL,NULL,NULL,NULL),('41','1','2','5','out','payment','4000','0','TRY','2026-10-20','Ödeme: Su',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:37',NULL,NULL,NULL,NULL),('42','1','1','1','in','collection','3000000','0','TRY','2026-10-20','Tahsilat: Satış faturası HOME-1 — Avans Müşterisi',NULL,'4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:38',NULL,NULL,NULL,NULL),('43','1','1','1','in','collection','3000000','0','TRY','2026-10-20','Avans',NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:38',NULL,NULL,NULL,NULL),('44','1','1','1','in','income','7700','0','TRY','2026-10-20',NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','test','2026-10-19 21:57:38','2',NULL,NULL,'2','2026-10-19 21:57:38',NULL,NULL,NULL,NULL),('45','1','1','1','in','collection','50000','0','TRY','2026-10-20',NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','test temizliği','2026-10-19 21:57:39','2',NULL,NULL,'2','2026-10-19 21:57:38',NULL,NULL,NULL,NULL),('46','1','1','1','in','collection','7000000','0','TRY','2026-10-20','Tahsilat: Satış faturası HOME-2 — Avans Müşterisi 2',NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 21:57:39',NULL,NULL,NULL,NULL);
/*FBEND*/
DROP TABLE IF EXISTS `users`;
/*FBEND*/
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `email` varchar(190) NOT NULL,
  `display_name` varchar(160) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL,
  `admin_flag` tinyint(4) DEFAULT NULL,
  `status` enum('active','suspended','archived') NOT NULL DEFAULT 'active',
  `must_change_password` tinyint(4) NOT NULL DEFAULT 0,
  `email_verified_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(64) DEFAULT NULL,
  `prev_login_at` datetime DEFAULT NULL,
  `prev_login_ip` varchar(64) DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `lock_level` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `totp_secret_enc` text DEFAULT NULL,
  `totp_enabled` tinyint(4) NOT NULL DEFAULT 0,
  `totp_last_step` bigint(20) DEFAULT NULL,
  `recovery_codes` text DEFAULT NULL,
  `session_epoch` int(11) NOT NULL DEFAULT 1,
  `password_changed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_users_email` (`email`),
  UNIQUE KEY `ux_users_admin` (`admin_flag`),
  KEY `ix_users_tenant` (`tenant_id`),
  CONSTRAINT `fk_users_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `users` VALUES ('1',NULL,'owner@test.local','Yönetici','$argon2id$v=19$m=19456,t=2,p=1$Z0VaZ3dLQi5mL2Z1aG1JdA$Sh9IByJb711bQ9C6gdHpQ2T/Ld6dZ5otG415oU6A76A','admin','1','active','0','2026-10-19 21:54:33','2026-10-19 21:58:00','127.0.0.1','2026-10-19 21:57:30','127.0.0.1','0','0',NULL,'z/4Sd/S96TMp68jywHa81CiCmFACDYEp3rVzrc0YvXD1TMNWnxDnyTRYSb+rRboTkmti4yqVXsH2IZkl','1','59748237','[\"35f981e4deff173edf5b75865040dfe23cc2bd56c786747170f58461639a786c\",\"a63014f9187fcc62901c9006493258281317e4302eae58dffa843ecd9b93db67\",\"53abf0bdcdc6164f70fdc1480dc80a5d6edb59860cd53b282c9de4383eb09434\",\"05f3c0bb48343d20e1f6bafb67deaddc3ac7d4f7a347c662e21e2c682c03deb5\",\"b5d676da23846d44a7eb84948a05cec9cca7056273a0adab73d69d96603b4a2b\",\"0b5e02c15b5dc34e10782d3d974711b4e78ae794352f6f95612aca76176b9b74\",\"c9911830276fb437b2b7af106bed7373cc062183b70f52ddb03c352851b636b5\",\"b181ab6ca63d1ea97e65711fa6dbf9c1abd0891366bafd96ee68be2b99aec2fe\"]','2','2026-10-19 21:54:33','2026-10-19 21:54:33'),('2','1','alfa@test.local','Hile','$argon2id$v=19$m=19456,t=2,p=1$blgvdVdNWTZ2OUJzSXpGcA$tsHDwR5JVLfOvTLOQ1X5/gAGUTe53GIBXMrHO6Nk2wk','customer',NULL,'active','0','2026-10-19 21:57:04','2026-10-19 21:57:39','127.0.0.1','2026-10-19 21:57:38','127.0.0.1','0','0',NULL,NULL,'0',NULL,NULL,'4','2026-10-19 21:57:05','2026-10-19 21:57:03'),('3','2','beta@test.local','Beta AŞ','$argon2id$v=19$m=19456,t=2,p=1$TzlLbE9QQ0dyc2JCb1BTYw$umMADyXIVDvaoLr0PM09jYjoYWow1euMNdsJvU/+hK0','customer',NULL,'active','0',NULL,'2026-10-19 21:57:38','127.0.0.1','2026-10-19 21:57:30','127.0.0.1','0','0',NULL,NULL,'0',NULL,NULL,'3','2026-10-19 21:57:03','2026-10-19 21:57:03');
/*FBEND*/
DROP TABLE IF EXISTS `warehouses`;
/*FBEND*/
CREATE TABLE `warehouses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_wh` (`tenant_id`,`name`),
  CONSTRAINT `fk_wh_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `warehouses` VALUES ('1','1','Ana Depo','0');
/*FBEND*/
DROP TABLE IF EXISTS `workspaces`;
/*FBEND*/
CREATE TABLE `workspaces` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `kind` enum('business','personal') NOT NULL DEFAULT 'business',
  `legal_name` varchar(200) DEFAULT NULL,
  `tax_no` varchar(30) DEFAULT NULL,
  `color` varchar(9) DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_ws_name` (`tenant_id`,`name`),
  CONSTRAINT `fk_ws_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `workspaces` VALUES ('1','1','Horizon','business',NULL,NULL,NULL,'0','2026-10-19 21:57:06'),('2','1','Şahsi','personal',NULL,NULL,NULL,'0','2026-10-19 21:57:06'),('3','2','Beta Ortak','business',NULL,NULL,NULL,'0','2026-10-19 21:57:11');
/*FBEND*/
SET FOREIGN_KEY_CHECKS=1;
/*FBEND*/
/*FBCOUNTS {"accounts":7,"audit_log":207,"budgets":1,"captchas":40,"card_installments":3,"card_purchases":1,"cards":1,"categories":34,"contacts":5,"documents":4,"entries":33,"fx_rates":2,"idempotency_keys":25,"invoice_lines":27,"invoices":24,"loan_installments":12,"loans":1,"login_tickets":10,"password_tokens":2,"payment_allocations":21,"project_milestones":1,"project_quotes":0,"projects":1,"rate_limits":21,"recurring_templates":1,"schema_migrations":4,"sessions":25,"statement_lines":3,"stock_items":8,"stock_movements":12,"system_settings":0,"tenants":2,"transactions":46,"users":3,"warehouses":1,"workspaces":3}*/
