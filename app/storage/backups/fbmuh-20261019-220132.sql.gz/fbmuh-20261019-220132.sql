/*FBMUH BACKUP 20261019-220132*/
SET NAMES utf8mb4;
/*FBEND*/
SET FOREIGN_KEY_CHECKS=0;
/*FBEND*/
DROP TABLE IF EXISTS `accounts`;
/*FBEND*/
CREATE TABLE `accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `kind` enum('bank','cash') NOT NULL DEFAULT 'bank',
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `iban` varchar(40) DEFAULT NULL,
  `opening_minor` bigint(20) NOT NULL DEFAULT 0,
  `opening_date` date NOT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT 0,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ac_t` (`tenant_id`),
  KEY `fk_ac_w` (`workspace_id`),
  CONSTRAINT `fk_ac_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`),
  CONSTRAINT `fk_ac_w` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `accounts` VALUES ('1','1','1',NULL,'Ana Banka TL','bank','Test Bank','TRY',NULL,'5000000','2026-01-01','0','0','2026-10-19 22:00:34'),('2','1','1',NULL,'Kasa TL','cash',NULL,'TRY',NULL,'0','2026-01-01','0','0','2026-10-19 22:00:34'),('3','1','1',NULL,'Banka EUR','bank',NULL,'EUR',NULL,'100000','2026-01-01','0','0','2026-10-19 22:00:34'),('4','1','1',NULL,'Banka USD','bank',NULL,'USD',NULL,'200000','2026-01-01','0','0','2026-10-19 22:00:34'),('5','1','2',NULL,'Şahsi Banka','bank',NULL,'TRY',NULL,'1000000','2026-01-01','0','0','2026-10-19 22:00:34'),('6','1','1',NULL,'IBANlı','bank',NULL,'TRY','TR330006100519786457841326','0','2026-01-01','0','0','2026-10-19 22:00:34'),('7','2','3',NULL,'Beta Banka','bank',NULL,'TRY',NULL,'100','2026-01-01','0','0','2026-10-19 22:00:39');
/*FBEND*/
DROP TABLE IF EXISTS `audit_log`;
/*FBEND*/
CREATE TABLE `audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ts` datetime NOT NULL,
  `actor_user_id` bigint(20) unsigned DEFAULT NULL,
  `actor_role` varchar(20) DEFAULT NULL,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `category` enum('security','admin','data','access','system') NOT NULL,
  `action` varchar(80) NOT NULL,
  `entity` varchar(60) DEFAULT NULL,
  `entity_id` varchar(40) DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `prev_hash` char(64) NOT NULL,
  `hash` char(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_audit_tenant` (`tenant_id`,`id`),
  KEY `ix_audit_cat` (`category`,`id`),
  KEY `ix_audit_actor` (`actor_user_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `audit_log` VALUES ('1','2026-10-19 21:58:03','1','admin',NULL,'admin','admin_created','user','1',NULL,'installer','0000000000000000000000000000000000000000000000000000000000000000','9f99e60e97ee102eed8c975ffabf8d9e8386aa0a78fd72319854b7a37d42cbd4'),('2','2026-10-19 21:58:04','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','9f99e60e97ee102eed8c975ffabf8d9e8386aa0a78fd72319854b7a37d42cbd4','3a7c928fc7561a4fcc80e213a50653bc829b9067e6f9f5e60648b53aed9bd900'),('3','2026-10-19 21:58:04','1','admin',NULL,'security','2fa_enabled',NULL,NULL,NULL,'127.0.0.1','3a7c928fc7561a4fcc80e213a50653bc829b9067e6f9f5e60648b53aed9bd900','4de1f0749b5c6657e06aabc714cada1338f66235a725447f07abcbdb9229e888'),('4','2026-10-19 21:58:04','1',NULL,NULL,'security','2fa_failed',NULL,NULL,NULL,'127.0.0.1','4de1f0749b5c6657e06aabc714cada1338f66235a725447f07abcbdb9229e888','cec6648fc0788a59e6c4fd605cb7b1b26a2706d2c9bea699c16004fe087cb52f'),('5','2026-10-19 21:58:04','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','cec6648fc0788a59e6c4fd605cb7b1b26a2706d2c9bea699c16004fe087cb52f','313dd49012ef7d38670bfb433a3c051f4826f64ae2c5eefb70ae4b551930482f'),('6','2026-10-19 21:58:32','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','313dd49012ef7d38670bfb433a3c051f4826f64ae2c5eefb70ae4b551930482f','c37653b82024a90d9cf7a091f26fafff0f2537a29f75baf0c1671919250e4919'),('7','2026-10-19 21:59:02','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','c37653b82024a90d9cf7a091f26fafff0f2537a29f75baf0c1671919250e4919','5dc3b3032766e4907a15333a604e0affcd3744ac5a12c5075ac91c00a19ea764'),('8','2026-10-19 21:59:02','1','admin',NULL,'security','logout',NULL,NULL,NULL,'127.0.0.1','5dc3b3032766e4907a15333a604e0affcd3744ac5a12c5075ac91c00a19ea764','2216e6b6a9053ef6fbf1163f4c3054bd58fd2b78dbcb1f8409e0a9d1912d702d'),('9','2026-10-19 21:59:32','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','2216e6b6a9053ef6fbf1163f4c3054bd58fd2b78dbcb1f8409e0a9d1912d702d','0efee7df246cd503f9e7f609a689f755be6e72773dbcb884d22b2c8b98de2a1c'),('10','2026-10-19 22:00:00','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','0efee7df246cd503f9e7f609a689f755be6e72773dbcb884d22b2c8b98de2a1c','2b258cb98259cf412dfa3a441a964f57f92fd15343ac64f1ecc7dc7e982853d3'),('11','2026-10-19 22:00:30','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','2b258cb98259cf412dfa3a441a964f57f92fd15343ac64f1ecc7dc7e982853d3','dac913753e2283732cb0c8dc8783bb1dee6e30a64fd1ddabffc4827a419202ca'),('12','2026-10-19 22:00:30',NULL,NULL,NULL,'security','login_failed',NULL,NULL,'{\"id\":\"bf7af0996800\",\"reason\":\"unknown\"}','127.0.0.1','dac913753e2283732cb0c8dc8783bb1dee6e30a64fd1ddabffc4827a419202ca','249ab3a2bbb2a8f4fa2facec1918b0ba55f785cc75d37f4fd55fbb1d997ec0ff'),('13','2026-10-19 22:00:30','1','admin','1','admin','tenant_created','tenant','1','{\"mode\":\"invite\",\"email\":\"alfa@test.local\"}','127.0.0.1','249ab3a2bbb2a8f4fa2facec1918b0ba55f785cc75d37f4fd55fbb1d997ec0ff','4b5a25d9c94ff4ad68aa3727aa0221431e0170fb379ebef991c943e24dfbd64e'),('14','2026-10-19 22:00:31','1','admin','2','admin','tenant_created','tenant','2','{\"mode\":\"temp\",\"email\":\"beta@test.local\"}','127.0.0.1','4b5a25d9c94ff4ad68aa3727aa0221431e0170fb379ebef991c943e24dfbd64e','01fbdddadd56be8cdb86d0397dcfac3584ac2989ec41a0eaad015dc6d055dd95'),('15','2026-10-19 22:00:31','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','01fbdddadd56be8cdb86d0397dcfac3584ac2989ec41a0eaad015dc6d055dd95','97f81a671bb9949ab80aecbf1ebb6b6ffa0632c40607a28b9a7c18fef5e239fa'),('16','2026-10-19 22:00:31','3','customer','2','security','password_change_failed',NULL,NULL,NULL,'127.0.0.1','97f81a671bb9949ab80aecbf1ebb6b6ffa0632c40607a28b9a7c18fef5e239fa','61665d7d29235fd44b2979bda1ca6203af3244d76be83faafad969d9190c759c'),('17','2026-10-19 22:00:31','3','customer','2','security','password_changed',NULL,NULL,NULL,'127.0.0.1','61665d7d29235fd44b2979bda1ca6203af3244d76be83faafad969d9190c759c','8994e65d15505d2a2528b183dd7eb323919f82022b070379b4a3ee147b2ae24e'),('18','2026-10-19 22:00:31','2','customer','1','security','invite_accepted',NULL,NULL,NULL,'127.0.0.1','8994e65d15505d2a2528b183dd7eb323919f82022b070379b4a3ee147b2ae24e','4d9e2fb3ba7a42a428c05408c668e8a2b08a7e192d42760643ddf55c9e74207e'),('19','2026-10-19 22:00:31','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','4d9e2fb3ba7a42a428c05408c668e8a2b08a7e192d42760643ddf55c9e74207e','3792305ad53633a79c6060487b1fc5609502686ade059b40e0c7f185116325e4'),('20','2026-10-19 22:00:31','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','3792305ad53633a79c6060487b1fc5609502686ade059b40e0c7f185116325e4','35795428cd667a4ee718d988ece8250c3a23da9d1a257e9f1cb0f5ee57605ac8'),('21','2026-10-19 22:00:31','2','customer','1','security','admin_endpoint_denied','route','/admin/overview',NULL,'127.0.0.1','35795428cd667a4ee718d988ece8250c3a23da9d1a257e9f1cb0f5ee57605ac8','9c119e02381e97e128e7b1f3a8825c662084da7118db6c76492e8492c4f942f0'),('22','2026-10-19 22:00:31','2','customer','1','security','admin_endpoint_denied','route','/admin/tenants',NULL,'127.0.0.1','9c119e02381e97e128e7b1f3a8825c662084da7118db6c76492e8492c4f942f0','4051649fa444d39075670b1202f520756b0451dc91904ee292bd82412c05e5bb'),('23','2026-10-19 22:00:31','2','customer','1','security','admin_endpoint_denied','route','/admin/tenants',NULL,'127.0.0.1','4051649fa444d39075670b1202f520756b0451dc91904ee292bd82412c05e5bb','6e521c118009bbde32ef13f8163a939a5a1724b09a679809518f2095da847d80'),('24','2026-10-19 22:00:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','6e521c118009bbde32ef13f8163a939a5a1724b09a679809518f2095da847d80','f871894baa8c44942d0ef598064e09616fa683d7b1bace80dce8fccc0531aa6b'),('25','2026-10-19 22:00:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','f871894baa8c44942d0ef598064e09616fa683d7b1bace80dce8fccc0531aa6b','f7692082ef6a83c04b0aa95850a120936c2fb303ef31ce13cdfafd3e2ca1ec31'),('26','2026-10-19 22:00:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','f7692082ef6a83c04b0aa95850a120936c2fb303ef31ce13cdfafd3e2ca1ec31','201b972b747d399d851ecba9f374e2503c257d3b0c6e78d90670e9d52ca24fc4'),('27','2026-10-19 22:00:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','201b972b747d399d851ecba9f374e2503c257d3b0c6e78d90670e9d52ca24fc4','a0f1bea4e86f48e567a3823928826f243d9bd0d46209a81e0509b92371750eaa'),('28','2026-10-19 22:00:32','2',NULL,'1','security','account_locked',NULL,NULL,'{\"level\":1}','127.0.0.1','a0f1bea4e86f48e567a3823928826f243d9bd0d46209a81e0509b92371750eaa','a8e48dec960370ae0d01c292722e0d752fb9d125b25da398aea77e59b48d2179'),('29','2026-10-19 22:00:32','2',NULL,'1','security','login_failed',NULL,NULL,'{\"reason\":\"password\"}','127.0.0.1','a8e48dec960370ae0d01c292722e0d752fb9d125b25da398aea77e59b48d2179','d6f406b4fb44e47926e009d5506916ae4865dd1c3a05ffc6475d8160a7370d57'),('30','2026-10-19 22:00:32','2',NULL,'1','security','login_locked',NULL,NULL,NULL,'127.0.0.1','d6f406b4fb44e47926e009d5506916ae4865dd1c3a05ffc6475d8160a7370d57','f712ffa3d79a9ddeed99cb8706947dd1620984922313bc6d115f9db4cbce54fa'),('31','2026-10-19 22:00:32','1','admin','1','admin','tenant_unlocked',NULL,NULL,NULL,'127.0.0.1','f712ffa3d79a9ddeed99cb8706947dd1620984922313bc6d115f9db4cbce54fa','f5a93e265080fcfe242942c92a64b9584053a7744214599fb3935853270e568c'),('32','2026-10-19 22:00:32','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','f5a93e265080fcfe242942c92a64b9584053a7744214599fb3935853270e568c','5277bfe66e3b52a2c2d9f33a703885b35219138188c5122f6a7c4ac47a669e22'),('33','2026-10-19 22:00:32','2',NULL,'1','security','password_reset_requested',NULL,NULL,NULL,'127.0.0.1','5277bfe66e3b52a2c2d9f33a703885b35219138188c5122f6a7c4ac47a669e22','c3c2d6705cd8fb381f8277194144c3c0b57be26847991b0427f38f26e01fdefd'),('34','2026-10-19 22:00:33','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','c3c2d6705cd8fb381f8277194144c3c0b57be26847991b0427f38f26e01fdefd','910d071b08d97e88210e636ba4a4b79fffe4631f71b12c2fa49cf5016c31f2f1'),('35','2026-10-19 22:00:33','2','customer','1','security','password_reset_done',NULL,NULL,NULL,'127.0.0.1','910d071b08d97e88210e636ba4a4b79fffe4631f71b12c2fa49cf5016c31f2f1','bf88bc8ee0a9f73593db01de1489c66016f3985f4ea10101356e06ca8299f8fe'),('36','2026-10-19 22:00:33','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','bf88bc8ee0a9f73593db01de1489c66016f3985f4ea10101356e06ca8299f8fe','1cf23113eabeee184e6b6519a0c57d20e68a120b4ccc81dd430ae06974a2944c'),('37','2026-10-19 22:00:33','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','1cf23113eabeee184e6b6519a0c57d20e68a120b4ccc81dd430ae06974a2944c','a9ac4a280b4c227aaeb018fc4ea2553de3679a925086948107ec42732d8c3e9a'),('38','2026-10-19 22:00:33','1','admin','2','admin','tenant_status_suspended','tenant','2','{\"from\":\"active\"}','127.0.0.1','a9ac4a280b4c227aaeb018fc4ea2553de3679a925086948107ec42732d8c3e9a','2b0650c8e36662b8e38cfe08af70738958dcf2134ba729f5943cc07864a29e17'),('39','2026-10-19 22:00:33','3',NULL,'2','security','login_blocked_suspended',NULL,NULL,NULL,'127.0.0.1','2b0650c8e36662b8e38cfe08af70738958dcf2134ba729f5943cc07864a29e17','e5572d800ba0b6160d94a7aad7f461f0116e09d3b75fc928c1f722566e19f4c4'),('40','2026-10-19 22:00:33','1','admin','2','admin','tenant_status_active','tenant','2','{\"from\":\"suspended\"}','127.0.0.1','e5572d800ba0b6160d94a7aad7f461f0116e09d3b75fc928c1f722566e19f4c4','776732e8fb656fe43a5fada755ccb14b6dc71374df7e7c8e90153b8a9da370c6'),('41','2026-10-19 22:00:33','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','776732e8fb656fe43a5fada755ccb14b6dc71374df7e7c8e90153b8a9da370c6','93567c3e4c99feea5ad49d5126fcc0c9326020aba8bcab5406b1a3c4580d31d3'),('42','2026-10-19 22:00:33','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','93567c3e4c99feea5ad49d5126fcc0c9326020aba8bcab5406b1a3c4580d31d3','5d0fb165ce74d6dc54784f18c22048f0b809a4f6a2fec603023b938931da6efb'),('43','2026-10-19 22:00:34','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','5d0fb165ce74d6dc54784f18c22048f0b809a4f6a2fec603023b938931da6efb','1675378ce9dd86d012cd3e3e10120a9e77260cd1db431fbeb1e26adbc4ff6753'),('44','2026-10-19 22:00:34','2','customer','1','data','workspace_created','workspace','1',NULL,'127.0.0.1','1675378ce9dd86d012cd3e3e10120a9e77260cd1db431fbeb1e26adbc4ff6753','16a563e105ce719d9ae8874b041fd2223b40f9b959a52cf922fb78dc60a8c110'),('45','2026-10-19 22:00:34','2','customer','1','data','workspace_created','workspace','2',NULL,'127.0.0.1','16a563e105ce719d9ae8874b041fd2223b40f9b959a52cf922fb78dc60a8c110','515d67537ef20e27dfdd6acdbdd1e3227da480c230cf692d3571e03abc2d4e5e'),('46','2026-10-19 22:00:34','2','customer','1','data','account_created','account','1','{\"opening_minor\":5000000}','127.0.0.1','515d67537ef20e27dfdd6acdbdd1e3227da480c230cf692d3571e03abc2d4e5e','80d2dac1fc8022f9043376a8be4b9e08c9afa3db38c3a15c99e4a6348a0077e9'),('47','2026-10-19 22:00:34','2','customer','1','data','account_created','account','2','{\"opening_minor\":0}','127.0.0.1','80d2dac1fc8022f9043376a8be4b9e08c9afa3db38c3a15c99e4a6348a0077e9','492bf0c3960ba6ef27ba225301c05e518b80c6f677d924d8dbc3e3f4929db40e'),('48','2026-10-19 22:00:34','2','customer','1','data','account_created','account','3','{\"opening_minor\":100000}','127.0.0.1','492bf0c3960ba6ef27ba225301c05e518b80c6f677d924d8dbc3e3f4929db40e','9f9f74903d97bf79c4bc0d8404b79f76add7bfb8b3aa01d62c21131542b41fe3'),('49','2026-10-19 22:00:34','2','customer','1','data','account_created','account','4','{\"opening_minor\":200000}','127.0.0.1','9f9f74903d97bf79c4bc0d8404b79f76add7bfb8b3aa01d62c21131542b41fe3','540c6ee9062025657987eecaaa4339183d0eb058b729a1739e18bccf352ad368'),('50','2026-10-19 22:00:34','2','customer','1','data','account_created','account','5','{\"opening_minor\":1000000}','127.0.0.1','540c6ee9062025657987eecaaa4339183d0eb058b729a1739e18bccf352ad368','30bf7636fb40396af9b03dadea1a4d68d2597d51560bb172efa3f049f92d2347'),('51','2026-10-19 22:00:34','2','customer','1','data','account_created','account','6','{\"opening_minor\":0}','127.0.0.1','30bf7636fb40396af9b03dadea1a4d68d2597d51560bb172efa3f049f92d2347','7da45979a5f6a133a259e75f67d961c120f5cd27781b623b7d7ea4a025686add'),('52','2026-10-19 22:00:34','2','customer','1','data','contact_created','contact','1',NULL,'127.0.0.1','7da45979a5f6a133a259e75f67d961c120f5cd27781b623b7d7ea4a025686add','142bfc7df0c76ab9326d96918613a14139ef63ee5b5c7d7102ba6b871bd4eebc'),('53','2026-10-19 22:00:34','2','customer','1','data','contact_created','contact','2',NULL,'127.0.0.1','142bfc7df0c76ab9326d96918613a14139ef63ee5b5c7d7102ba6b871bd4eebc','44757b44d4195853276dfa4fdfeaea46cb07e513f2b237396185fc0a9ef25202'),('54','2026-10-19 22:00:34','2','customer','1','data','entry_created','entry','1','{\"kind\":\"receivable\",\"amount_minor\":10000000,\"installments\":1}','127.0.0.1','44757b44d4195853276dfa4fdfeaea46cb07e513f2b237396185fc0a9ef25202','ba3f4a47b14eb852bc1e323c947a588aa10fdb52097de5c20657d5099dc914e2'),('55','2026-10-19 22:00:34','2','customer','1','data','collection_created','transaction','1','{\"amount_minor\":6000000,\"contact_id\":1,\"allocations\":{\"1\":6000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','ba3f4a47b14eb852bc1e323c947a588aa10fdb52097de5c20657d5099dc914e2','79f0419469d65a021ba19be8b20547832094c2d3a5f3d3dcbca025d70598c821'),('56','2026-10-19 22:00:34','2','customer','1','data','collection_created','transaction','2','{\"amount_minor\":4000000,\"contact_id\":1,\"allocations\":{\"1\":4000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','79f0419469d65a021ba19be8b20547832094c2d3a5f3d3dcbca025d70598c821','7d8ee19d491716ba2e7d591420d28f6089150ea70b6e1316c3f0808642e5c2f8'),('57','2026-10-19 22:00:34','2','customer','1','data','transfer_created','transfer','785f5684783ad8dc07a502189a','{\"from\":1,\"to\":2,\"amount_minor\":2000000,\"kind\":\"transfer\"}','127.0.0.1','7d8ee19d491716ba2e7d591420d28f6089150ea70b6e1316c3f0808642e5c2f8','ea9b61cfa8d6d573f61a49e93e485cbce4976e6b49f3902cc635fde094f8bd47'),('58','2026-10-19 22:00:35','2','customer','1','data','entry_created','entry','2','{\"kind\":\"payable\",\"amount_minor\":500000,\"installments\":1}','127.0.0.1','ea9b61cfa8d6d573f61a49e93e485cbce4976e6b49f3902cc635fde094f8bd47','019ba08fa048954a1db5dc1d479be6dd75fd73bc7b657bf177ec7530e316b6e1'),('59','2026-10-19 22:00:35','2','customer','1','data','invoice_created','invoice','1','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":120000,\"due_date\":\"2026-11-04\",\"new_items\":0}','127.0.0.1','019ba08fa048954a1db5dc1d479be6dd75fd73bc7b657bf177ec7530e316b6e1','fac9873bf06100370814c0de73bbfb62c5f562c898e82f6357accdbae31d0c02'),('60','2026-10-19 22:00:35','2','customer','1','data','collection_created','transaction','5','{\"amount_minor\":120000,\"contact_id\":1,\"allocations\":{\"5\":120000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','fac9873bf06100370814c0de73bbfb62c5f562c898e82f6357accdbae31d0c02','65f2f6ad66451164c6c8cea9fdeed1bcd68d0f4d991b59611435be1fe82438d3'),('61','2026-10-19 22:00:35','2','customer','1','data','entry_created','entry','7','{\"kind\":\"receivable\",\"amount_minor\":50000,\"installments\":1}','127.0.0.1','65f2f6ad66451164c6c8cea9fdeed1bcd68d0f4d991b59611435be1fe82438d3','927163ddd94b4c419b4624bd9c05fee0818ef0a54dedb67da30cd5f365c80156'),('62','2026-10-19 22:00:35','2','customer','1','data','fx_created','transfer','30c779aa29b1a4afb61e2971c0','{\"out\":1000000,\"in\":25000,\"rate\":\"0.02500000\",\"fee\":1500}','127.0.0.1','927163ddd94b4c419b4624bd9c05fee0818ef0a54dedb67da30cd5f365c80156','3ff5cb5d05f92ec5cef5c33462c217643d3e0d48b3a690a6eaf8ea31239f8bf5'),('63','2026-10-19 22:00:35','2','customer','1','data','entry_created','entry','8','{\"kind\":\"payable\",\"amount_minor\":1000000,\"installments\":1}','127.0.0.1','3ff5cb5d05f92ec5cef5c33462c217643d3e0d48b3a690a6eaf8ea31239f8bf5','90bf17ec4997c5c1249021240af51bda0f5a91ed977715d51d180b5058092db5'),('64','2026-10-19 22:00:35','2','customer','1','data','payment_created','transaction','9','{\"amount_minor\":300000,\"contact_id\":2,\"allocations\":{\"8\":300000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','90bf17ec4997c5c1249021240af51bda0f5a91ed977715d51d180b5058092db5','a98e58ac800cc8885a03cac0a443c7439aeab176a4491b82a9eae73bc9883521'),('65','2026-10-19 22:00:36','2','customer','1','data','entry_rescheduled','entry','8','{\"before\":{\"due_date\":\"2026-10-17\"},\"after\":{\"due_date\":\"2026-10-30\"}}','127.0.0.1','a98e58ac800cc8885a03cac0a443c7439aeab176a4491b82a9eae73bc9883521','8d0b3fe7853fb1b7bc08cb7901e3f7ba36f8fb083cd5c9bdbcc516b4918da613'),('66','2026-10-19 22:00:36','2','customer','1','data','card_created','card','1',NULL,'127.0.0.1','8d0b3fe7853fb1b7bc08cb7901e3f7ba36f8fb083cd5c9bdbcc516b4918da613','33755854ea66cf99eba003330df350443d608d5d0c1b43d7c47720d6be3bab6e'),('67','2026-10-19 22:00:36','2','customer','1','data','card_purchase','card_purchase','1','{\"amount_minor\":120000,\"installments\":3}','127.0.0.1','33755854ea66cf99eba003330df350443d608d5d0c1b43d7c47720d6be3bab6e','2bd9154b93d63a0bf37584ce69386771631de99e251302283228d82b85826c99'),('68','2026-10-19 22:00:36','2','customer','1','data','card_payment','card','1','{\"txn\":10,\"amount_minor\":40000}','127.0.0.1','2bd9154b93d63a0bf37584ce69386771631de99e251302283228d82b85826c99','e261742442961332e2cb97d915244fc89f7be4d341bc0689162658b6028e7663'),('69','2026-10-19 22:00:36','2','customer','1','data','loan_created','loan','1','{\"principal_minor\":12000000,\"term\":12}','127.0.0.1','e261742442961332e2cb97d915244fc89f7be4d341bc0689162658b6028e7663','e04142e5230d46d341c7f6aa7a12412dfdfff929a05e5e8df72acbba06fce04a'),('70','2026-10-19 22:00:36','2','customer','1','data','loan_payment','loan','1','{\"txn\":12,\"seq\":1}','127.0.0.1','e04142e5230d46d341c7f6aa7a12412dfdfff929a05e5e8df72acbba06fce04a','7622f2197c83501f2d36aada15920f89c7e6c00cd47699db15be56deb7fb63f5'),('71','2026-10-19 22:00:36','2','customer','1','data','entry_created','entry','9','{\"kind\":\"payable\",\"amount_minor\":80000,\"installments\":1}','127.0.0.1','7622f2197c83501f2d36aada15920f89c7e6c00cd47699db15be56deb7fb63f5','1057e15e54ab2a6e43e097fd348ce02904deb95efd003e7ea977b0852e54df83'),('72','2026-10-19 22:00:37','2','customer','1','data','statement_imported','account','1','{\"added\":3,\"duplicates\":0}','127.0.0.1','1057e15e54ab2a6e43e097fd348ce02904deb95efd003e7ea977b0852e54df83','c4ab7347d2b4e32204c371bee4594e075f14a2a72d0ceb98e1cf0d20ed42eca0'),('73','2026-10-19 22:00:37','2','customer','1','data','statement_imported','account','1','{\"added\":0,\"duplicates\":3}','127.0.0.1','c4ab7347d2b4e32204c371bee4594e075f14a2a72d0ceb98e1cf0d20ed42eca0','03cb4b32dc2234245dea9940ee3e4ccfa600865460af2a8fe26f186e55e4048a'),('74','2026-10-19 22:00:37','2','customer','1','data','statement_line_posted','statement_line','1','{\"txn\":13}','127.0.0.1','03cb4b32dc2234245dea9940ee3e4ccfa600865460af2a8fe26f186e55e4048a','f6a51c6fc73e711b1c6adaa64e48378eef9a6cfe9edc3b3ed49cabaf905af101'),('75','2026-10-19 22:00:37','2','customer','1','data','project_created','project','1',NULL,'127.0.0.1','f6a51c6fc73e711b1c6adaa64e48378eef9a6cfe9edc3b3ed49cabaf905af101','22d6e167d51972c5a666b75ab50296112cb540fc38a89e6f98f3ed854c66fbec'),('76','2026-10-19 22:00:37','2','customer','1','data','invoice_created','invoice','3','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":1200000,\"due_date\":null,\"new_items\":0}','127.0.0.1','22d6e167d51972c5a666b75ab50296112cb540fc38a89e6f98f3ed854c66fbec','5cdc4990d7f9b95bef6f5b5912c70f579db977c5fce6113ff06918ef111c1e45'),('77','2026-10-19 22:00:37','2','customer','1','data','collection_created','transaction','14','{\"amount_minor\":1200000,\"contact_id\":1,\"allocations\":{\"10\":1200000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','5cdc4990d7f9b95bef6f5b5912c70f579db977c5fce6113ff06918ef111c1e45','9b63d48db35b1cc432b42370b7e7027fd22c1e62bb5f93dc0573516eca95d4e2'),('78','2026-10-19 22:00:37','2','customer','1','data','invoice_created','invoice','4','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":480000,\"due_date\":null,\"new_items\":0}','127.0.0.1','9b63d48db35b1cc432b42370b7e7027fd22c1e62bb5f93dc0573516eca95d4e2','fc45faad97cd7d8f444497de445c17e7f4ac257a6f0c872552d50f8ac3332197'),('79','2026-10-19 22:00:37','2','customer','1','data','payment_created','transaction','15','{\"amount_minor\":480000,\"contact_id\":2,\"allocations\":{\"11\":480000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','fc45faad97cd7d8f444497de445c17e7f4ac257a6f0c872552d50f8ac3332197','40d5128a99596c157d897c1e0b911ff624795a2d1f755e3feeaf2b64d47e912e'),('80','2026-10-19 22:00:37','2','customer','1','data','transaction_created','transaction','16','{\"kind\":\"expense\",\"amount_minor\":50000,\"replaces\":null}','127.0.0.1','40d5128a99596c157d897c1e0b911ff624795a2d1f755e3feeaf2b64d47e912e','8daeef96c42691b4169a00991bf5c3abe3f00a83791dc61e073286aecbdc701f'),('81','2026-10-19 22:00:37','2','customer','1','data','invoice_created','invoice','5','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":120000,\"due_date\":null,\"new_items\":0}','127.0.0.1','8daeef96c42691b4169a00991bf5c3abe3f00a83791dc61e073286aecbdc701f','1d34aec3d5678de6fbefb5773783eef60b85fd8ff8aee2c5ff586b42ed5d38bf'),('82','2026-10-19 22:00:37','2','customer','1','data','stock_movement','stock_movement','2','{\"kind\":\"out\",\"qty_milli\":2000}','127.0.0.1','1d34aec3d5678de6fbefb5773783eef60b85fd8ff8aee2c5ff586b42ed5d38bf','5d46ce1abd2d12d8151dd49e9dcaee81ae5bf2335e677f2975e388d8e2975bf2'),('83','2026-10-19 22:00:37','2','customer','1','data','settings_changed',NULL,NULL,NULL,'127.0.0.1','5d46ce1abd2d12d8151dd49e9dcaee81ae5bf2335e677f2975e388d8e2975bf2','f56cda3814fc17e166ef5b7ff867f4cf316306c341d53f6685fdbb0c45304990'),('84','2026-10-19 22:00:37','2','customer','1','data','stock_movement','stock_movement','3','{\"kind\":\"out\",\"qty_milli\":9000}','127.0.0.1','f56cda3814fc17e166ef5b7ff867f4cf316306c341d53f6685fdbb0c45304990','f2fcafd85e52cc5517d98a1436d141026e066b948a012e6780b8b0458f035d66'),('85','2026-10-19 22:00:37','2','customer','1','data','settings_changed',NULL,NULL,NULL,'127.0.0.1','f2fcafd85e52cc5517d98a1436d141026e066b948a012e6780b8b0458f035d66','d0923d4a08d58c3111b0792154176b753928f8fe9727d3cda7984730fbd51bb3'),('86','2026-10-19 22:00:38','2','customer','1','data','transaction_created','transaction','17','{\"kind\":\"income\",\"amount_minor\":100000,\"replaces\":null}','127.0.0.1','d0923d4a08d58c3111b0792154176b753928f8fe9727d3cda7984730fbd51bb3','f8190ffc9071143706bfd8e5cc7ac2df812fe94f891036f7fe6d92afbe961843'),('87','2026-10-19 22:00:38','2','customer','1','data','transaction_voided','transaction','17','{\"reason\":\"Hatalı giriş\",\"before\":{\"kind\":\"income\",\"amount_minor\":100000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[17]}','127.0.0.1','f8190ffc9071143706bfd8e5cc7ac2df812fe94f891036f7fe6d92afbe961843','e8de4a1fc421b783feefdac0a1fc5590d143757a6d474328a04d933cc9894583'),('88','2026-10-19 22:00:38','2','customer','1','data','transaction_created','transaction','18','{\"kind\":\"expense\",\"amount_minor\":10000,\"replaces\":null}','127.0.0.1','e8de4a1fc421b783feefdac0a1fc5590d143757a6d474328a04d933cc9894583','6db356921f4645964101db0d5c139b8f3724d1dcb73771a1bf2be607ef042941'),('89','2026-10-19 22:00:38','2','customer','1','data','transaction_voided','transaction','18','{\"reason\":\"Düzenleme ile yenisi oluşturuldu\",\"before\":{\"kind\":\"expense\",\"amount_minor\":10000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[18]}','127.0.0.1','6db356921f4645964101db0d5c139b8f3724d1dcb73771a1bf2be607ef042941','66340caa97097a407af03a144ff368858de1e5cd965358b208a7ba1067158792'),('90','2026-10-19 22:00:38','2','customer','1','data','transaction_replaced','transaction','19','{\"kind\":\"expense\",\"amount_minor\":12000,\"replaces\":18}','127.0.0.1','66340caa97097a407af03a144ff368858de1e5cd965358b208a7ba1067158792','130ca6e6bc1266ac7ffb02e8c4946b66faed1df84e67141bb25f9db5634c28f9'),('91','2026-10-19 22:00:38','2','customer','1','data','transaction_created','transaction','20','{\"kind\":\"expense\",\"amount_minor\":120000,\"replaces\":null}','127.0.0.1','130ca6e6bc1266ac7ffb02e8c4946b66faed1df84e67141bb25f9db5634c28f9','9e1213021a46eac448d9f6605745c0ef8d8d877211e7810ae34ff2de5d92568f'),('92','2026-10-19 22:00:38','2','customer','1','data','transaction_created','transaction','21','{\"kind\":\"expense\",\"amount_minor\":120000,\"replaces\":null}','127.0.0.1','9e1213021a46eac448d9f6605745c0ef8d8d877211e7810ae34ff2de5d92568f','74e1147d07e7a599caf7f0b6b5f99a9c79efd3778f761185e1120bb07ac6c831'),('93','2026-10-19 22:00:38','2','customer','1','data','balance_adjusted','account','2','{\"delta_minor\":-5000,\"reason\":\"Sayım farkı\"}','127.0.0.1','74e1147d07e7a599caf7f0b6b5f99a9c79efd3778f761185e1120bb07ac6c831','4edb6c71bd6ea1279a92fb6898f5eefcaa27e00b2f26439cf6166450a46f4edf'),('94','2026-10-19 22:00:39','3','customer','2','data','workspace_created','workspace','3',NULL,'127.0.0.1','4edb6c71bd6ea1279a92fb6898f5eefcaa27e00b2f26439cf6166450a46f4edf','028ccc0cc6392545e6f93a7109f5957beac3669f73fcfd052cb9f592db34948e'),('95','2026-10-19 22:00:39','3','customer','2','data','account_created','account','7','{\"opening_minor\":100}','127.0.0.1','028ccc0cc6392545e6f93a7109f5957beac3669f73fcfd052cb9f592db34948e','a5c6a378beba467e2baf0fc1418805447005f52ea0e24f58a6dd08fefb563915'),('96','2026-10-19 22:00:39','2','customer','1','data','document_uploaded','transaction','18','{\"doc\":1,\"size\":70}','127.0.0.1','a5c6a378beba467e2baf0fc1418805447005f52ea0e24f58a6dd08fefb563915','a79e16c030a1de638df1e5f7f489d4e5e716f09b1daa5e882d7770b8a2b4f34b'),('97','2026-10-19 22:00:39','2','customer','1','data','export_transactions',NULL,NULL,'{\"format\":\"csv\",\"rows\":20}','127.0.0.1','a79e16c030a1de638df1e5f7f489d4e5e716f09b1daa5e882d7770b8a2b4f34b','8eed250d86121e88e7221e7b619406533f697282cef30a62a101b395b888e0b0'),('98','2026-10-19 22:00:39','2','customer','1','data','transaction_created','transaction','23','{\"kind\":\"expense\",\"amount_minor\":100,\"replaces\":null}','127.0.0.1','8eed250d86121e88e7221e7b619406533f697282cef30a62a101b395b888e0b0','0b60362b0a358dea5ca5ca2b349373b428377839c961024f364580be5a294bc2'),('99','2026-10-19 22:00:39','2','customer','1','data','export_transactions',NULL,NULL,'{\"format\":\"csv\",\"rows\":21}','127.0.0.1','0b60362b0a358dea5ca5ca2b349373b428377839c961024f364580be5a294bc2','14f0c119b4aa2d4860bce8d97d58eceef1c9b740fa29c099dd4a607ecf70cca5'),('100','2026-10-19 22:00:39','2','customer','1','data','export_income-expense',NULL,NULL,'{\"format\":\"xlsx\",\"rows\":1}','127.0.0.1','14f0c119b4aa2d4860bce8d97d58eceef1c9b740fa29c099dd4a607ecf70cca5','56321e9bcb11a7dce7880054d23386d61ab445725c6704868a8e6460a4674dbf'),('101','2026-10-19 22:00:40','2','customer','1','data','export_vat',NULL,NULL,'{\"format\":\"csv\",\"rows\":4}','127.0.0.1','56321e9bcb11a7dce7880054d23386d61ab445725c6704868a8e6460a4674dbf','529a82208e2bd5439066c67ab998ff5c5ada743dc2539730f7fa0f638e80be09'),('102','2026-10-19 22:00:40','2','customer','1','data','tenant_data_export',NULL,NULL,NULL,'127.0.0.1','529a82208e2bd5439066c67ab998ff5c5ada743dc2539730f7fa0f638e80be09','e7dc8896611f22af3769ddd0ce1afb5c6a718ec515fbc9b0404ecb2003f12317'),('103','2026-10-19 22:00:40','2','customer','1','data','settings_changed',NULL,NULL,NULL,'127.0.0.1','e7dc8896611f22af3769ddd0ce1afb5c6a718ec515fbc9b0404ecb2003f12317','d894e5a0a9bb6e6d5fafa90bec24498cdbd40a5984ac69a5450c40348d9abda6'),('104','2026-10-19 22:01:01','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','d894e5a0a9bb6e6d5fafa90bec24498cdbd40a5984ac69a5450c40348d9abda6','2c3cc027d0f08441e68443582fbf46cdf28a1a304e28dd60e5af3cd03a633699'),('105','2026-10-19 22:01:01','1','admin','1','access','admin_view_tenant_data','accounts',NULL,NULL,'127.0.0.1','2c3cc027d0f08441e68443582fbf46cdf28a1a304e28dd60e5af3cd03a633699','7414a9371931a80c34b4e9b2feb22be5b741bded013845bfcaa34095a8b93d59'),('106','2026-10-19 22:01:01','1','admin','1','access','admin_view_tenant_data','transactions',NULL,NULL,'127.0.0.1','7414a9371931a80c34b4e9b2feb22be5b741bded013845bfcaa34095a8b93d59','8c33988c6235b316bf9265b8a7149e0a92d79d566c923ca16ae23935892f6c2e'),('107','2026-10-19 22:01:01','1','admin','1','access','admin_view_tenant_data','reports',NULL,NULL,'127.0.0.1','8c33988c6235b316bf9265b8a7149e0a92d79d566c923ca16ae23935892f6c2e','b10453c3c262bfdba0b21de9c7e22f813df362f482d60d2edd399b55ad7f15a6'),('108','2026-10-19 22:01:01','2','customer','1','data','transaction_created','transaction','24','{\"kind\":\"expense\",\"amount_minor\":7700,\"replaces\":null}','127.0.0.1','b10453c3c262bfdba0b21de9c7e22f813df362f482d60d2edd399b55ad7f15a6','23984737c123b0675de21f2c39d362c406fe359e5e2d6840807caa4ea257c1f2'),('109','2026-10-19 22:01:01','1','admin','1','data','transaction_voided','transaction','24','{\"reason\":\"[Yönetici düzeltmesi] Mükerrer giriş\",\"before\":{\"kind\":\"expense\",\"amount_minor\":7700,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[24]}','127.0.0.1','23984737c123b0675de21f2c39d362c406fe359e5e2d6840807caa4ea257c1f2','4aaad471e2a1e24cf68aaa9ae1e1466ef3d17b697dbdb9062825c32e72533f0e'),('110','2026-10-19 22:01:01','1','admin','1','admin','admin_correction_void','transaction','24','{\"reason\":\"Mükerrer giriş\",\"legs\":[24]}','127.0.0.1','4aaad471e2a1e24cf68aaa9ae1e1466ef3d17b697dbdb9062825c32e72533f0e','d2a1a86bfddfc41ccdcaa12371bddbc69763f559714a998f9734c8a59885f79b'),('111','2026-10-19 22:01:01','1','admin','1','admin','tenant_status_archived','tenant','1','{\"from\":\"active\"}','127.0.0.1','d2a1a86bfddfc41ccdcaa12371bddbc69763f559714a998f9734c8a59885f79b','08ec9b5fc30c28d796c5635a9acc583a1b1245e2513c2434230f004ffaff9512'),('112','2026-10-19 22:01:01','1','admin','1','admin','tenant_status_active','tenant','1','{\"from\":\"archived\"}','127.0.0.1','08ec9b5fc30c28d796c5635a9acc583a1b1245e2513c2434230f004ffaff9512','647319781c043d30ec7ce472142e87c4dc3758c82fca48ae9b38751e35b09931'),('113','2026-10-19 22:01:02','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','647319781c043d30ec7ce472142e87c4dc3758c82fca48ae9b38751e35b09931','caf6530c2785f903a3c823b4ea6871c91c4387d4a492ba65fd823b4e24504276'),('114','2026-10-19 22:01:02','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','caf6530c2785f903a3c823b4ea6871c91c4387d4a492ba65fd823b4e24504276','6979cb99d4c99ef7717781866faed64507693a823b53112a7f76d488172844b7'),('115','2026-10-19 22:01:02','2','customer','1','data','invoice_created','invoice','6','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":100000,\"due_date\":null,\"new_items\":0}','127.0.0.1','6979cb99d4c99ef7717781866faed64507693a823b53112a7f76d488172844b7','be26caa51fe0a713c5929f3d04066c13d9a72b0544f603a0e314eb85e678eddd'),('116','2026-10-19 22:01:02','2','customer','1','data','invoice_created','invoice','7','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"new_items\":0}','127.0.0.1','be26caa51fe0a713c5929f3d04066c13d9a72b0544f603a0e314eb85e678eddd','dea3848d0f8b2c968545c021ecaaca2c6b8e154c81114538edc4abfd9171436e'),('117','2026-10-19 22:01:02','2','customer','1','data','invoice_created','invoice','8','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":50000,\"due_date\":\"2026-12-04\",\"new_items\":0}','127.0.0.1','dea3848d0f8b2c968545c021ecaaca2c6b8e154c81114538edc4abfd9171436e','bcd42698969c3d681b1bea716d39a61a813606fb23cdfb2bc73384143c524946'),('118','2026-10-19 22:01:02','2','customer','1','data','invoice_updated','invoice','7','{\"before\":{\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"lines\":1},\"after\":{\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"lines\":1}}','127.0.0.1','bcd42698969c3d681b1bea716d39a61a813606fb23cdfb2bc73384143c524946','d66e8ae725c0e4a08a204beee2a76a0128feafba2a524cc499df9033e0dd9b09'),('119','2026-10-19 22:01:02','2','customer','1','data','invoice_updated','invoice','7','{\"before\":{\"total_minor\":50000,\"due_date\":\"2026-10-27\",\"lines\":1},\"after\":{\"total_minor\":50000,\"due_date\":null,\"lines\":1}}','127.0.0.1','d66e8ae725c0e4a08a204beee2a76a0128feafba2a524cc499df9033e0dd9b09','7cf81ac063cbf87374abc343a8aae23c4beb49540e97af82a72e2900d302e345'),('120','2026-10-19 22:01:02','2','customer','1','data','entry_rescheduled','entry','15','{\"before\":{\"due_date\":null},\"after\":{\"due_date\":\"2026-10-30\"}}','127.0.0.1','7cf81ac063cbf87374abc343a8aae23c4beb49540e97af82a72e2900d302e345','6a7575828abe0174ec1d1a1943649b3026944e9db0a93ebd486a4ab2e98c3478'),('121','2026-10-19 22:01:02','2','customer','1','data','invoice_created','invoice','9','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','6a7575828abe0174ec1d1a1943649b3026944e9db0a93ebd486a4ab2e98c3478','a490ffe1b2e5222c5c24026397b90e1bb8251863ce75acc2467711287835b55a'),('122','2026-10-19 22:01:02','2','customer','1','data','payment_created','transaction','25','{\"amount_minor\":400000,\"contact_id\":2,\"allocations\":{\"17\":400000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','a490ffe1b2e5222c5c24026397b90e1bb8251863ce75acc2467711287835b55a','89ca93321c0572bfc0625bb092e62c35447be70c32d3b90b21eac9268b8b455a'),('123','2026-10-19 22:01:02','2','customer','1','data','payment_created','transaction','26','{\"amount_minor\":600000,\"contact_id\":2,\"allocations\":{\"17\":600000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','89ca93321c0572bfc0625bb092e62c35447be70c32d3b90b21eac9268b8b455a','b7cec7d679b0b9743d34d3bf2be1cbd00adeca176aa9bca02b4b71b9ca8456d3'),('124','2026-10-19 22:01:03','2','customer','1','data','invoice_created','invoice','10','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','b7cec7d679b0b9743d34d3bf2be1cbd00adeca176aa9bca02b4b71b9ca8456d3','71c9c4bca2f15a4f8daaa5876f190b4d35ad70bd4a6b5e90e553f7e3591145b8'),('125','2026-10-19 22:01:03','2','customer','1','data','payment_created','transaction','27','{\"amount_minor\":3000000,\"contact_id\":2,\"allocations\":{\"18\":1000000},\"unallocated_minor\":2000000,\"for_workspace_id\":null}','127.0.0.1','71c9c4bca2f15a4f8daaa5876f190b4d35ad70bd4a6b5e90e553f7e3591145b8','c6e1e403c1e7f49434fd4562b59b66fbf54d61fd6b2ea75eacd687212572f951'),('126','2026-10-19 22:01:03','2','customer','1','data','invoice_created','invoice','11','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','c6e1e403c1e7f49434fd4562b59b66fbf54d61fd6b2ea75eacd687212572f951','f13abe9c224547e46bd53adca9f057bd7b8d0df126ab1649066eb49f57409e86'),('127','2026-10-19 22:01:03','2','customer','1','data','invoice_created','invoice','12','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":6000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','f13abe9c224547e46bd53adca9f057bd7b8d0df126ab1649066eb49f57409e86','d7e45ee8933a3e3407f682d1fc48e9050e450297de94a92e58fa42763e48f33b'),('128','2026-10-19 22:01:03','2','customer','1','data','invoice_created','invoice','13','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":4500000,\"due_date\":null,\"new_items\":0}','127.0.0.1','d7e45ee8933a3e3407f682d1fc48e9050e450297de94a92e58fa42763e48f33b','e30dfb7e1740190fa1dbb3516eb5af00b70109d9e38d6c11e35a5116598dffac'),('129','2026-10-19 22:01:03','2','customer','1','data','payment_created','transaction','28','{\"amount_minor\":5000000,\"contact_id\":2,\"allocations\":{\"19\":1000000,\"20\":4000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','e30dfb7e1740190fa1dbb3516eb5af00b70109d9e38d6c11e35a5116598dffac','6f0dad85a4f5fa9b55c2c6506d7df04d20820fa2ed854c1ded6b8b26011c7787'),('130','2026-10-19 22:01:03','2','customer','1','data','payment_allocated','transaction','27','{\"new_minor\":2000000,\"allocated_minor\":3000000,\"unallocated_minor\":0}','127.0.0.1','6f0dad85a4f5fa9b55c2c6506d7df04d20820fa2ed854c1ded6b8b26011c7787','573a4be35c434a3d8ba584bdfa0318ec52df4805e476223a5fd7da4e6bc87851'),('131','2026-10-19 22:01:03','2','customer','1','data','allocation_reversed','transaction','27','{\"entry_id\":21,\"amount_minor\":2000000}','127.0.0.1','573a4be35c434a3d8ba584bdfa0318ec52df4805e476223a5fd7da4e6bc87851','c1545520e6b49a3d2364fa861fe949d30a70cd93517b62a6f3998904fc6389f2'),('132','2026-10-19 22:01:03','2','customer','1','data','allocations_replaced','transaction','27','{\"new_minor\":2000000,\"allocated_minor\":2000000,\"unallocated_minor\":1000000}','127.0.0.1','c1545520e6b49a3d2364fa861fe949d30a70cd93517b62a6f3998904fc6389f2','4f685d2ef9b3aa9a4e95e55936b991c53cde43a763b4f68171399a7ebb27684c'),('133','2026-10-19 22:01:04','2','customer','1','data','payment_created','transaction','29','{\"amount_minor\":10000,\"contact_id\":2,\"allocations\":[],\"unallocated_minor\":10000,\"for_workspace_id\":null}','127.0.0.1','4f685d2ef9b3aa9a4e95e55936b991c53cde43a763b4f68171399a7ebb27684c','afbcf05d616c0e289ba43da73660c79f5598b3620ecc722bc464c71dd28f18da'),('134','2026-10-19 22:01:04','2','customer','1','data','payment_created','transaction','30','{\"amount_minor\":7000,\"contact_id\":2,\"allocations\":[],\"unallocated_minor\":7000,\"for_workspace_id\":null}','127.0.0.1','afbcf05d616c0e289ba43da73660c79f5598b3620ecc722bc464c71dd28f18da','a6c2b1cac812b57e7442c6fb7083249e19d70be89836c9ef647c6e01b94c5c5e'),('135','2026-10-19 22:01:04','2','customer','1','data','payment_created','transaction','31','{\"amount_minor\":7000,\"contact_id\":2,\"allocations\":[],\"unallocated_minor\":7000,\"for_workspace_id\":null}','127.0.0.1','a6c2b1cac812b57e7442c6fb7083249e19d70be89836c9ef647c6e01b94c5c5e','b62847b0f57ca51e6f30ef90bcd857df20b01ac8e0679b4c9a269d78fa579a75'),('136','2026-10-19 22:01:04','2','customer','1','data','invoice_created','invoice','14','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":500000,\"due_date\":null,\"new_items\":0}','127.0.0.1','b62847b0f57ca51e6f30ef90bcd857df20b01ac8e0679b4c9a269d78fa579a75','d48f7bb179278a112625bb35814db8a7b53c0a3ca21e41f59be92e0a0ac4f13a'),('137','2026-10-19 22:01:04','2','customer','1','data','collection_created','transaction','32','{\"amount_minor\":800000,\"contact_id\":1,\"allocations\":{\"22\":500000},\"unallocated_minor\":300000,\"for_workspace_id\":null}','127.0.0.1','d48f7bb179278a112625bb35814db8a7b53c0a3ca21e41f59be92e0a0ac4f13a','ec828799fa5c3da3b12f60d2aaca4747ab37112ff2b6c5cdc6a01ffd0ae29f45'),('138','2026-10-19 22:01:04','2','customer','1','data','transaction_voided','transaction','28','{\"reason\":\"test iptal\",\"before\":{\"kind\":\"payment\",\"amount_minor\":5000000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[28]}','127.0.0.1','ec828799fa5c3da3b12f60d2aaca4747ab37112ff2b6c5cdc6a01ffd0ae29f45','80e78b56288717de8bfa119a0edd1d8fef253a15b88675b78b3205e1f0ec9639'),('139','2026-10-19 22:01:04','2','customer','1','data','stock_item_autocreated','stock_item','2','{\"name\":\"Buzdolabı T4\",\"kind\":\"product\"}','127.0.0.1','80e78b56288717de8bfa119a0edd1d8fef253a15b88675b78b3205e1f0ec9639','eb7119d21d0e7991a2d763564165fe8154d2adebb60fa588117a44a8562e4ad0'),('140','2026-10-19 22:01:04','2','customer','1','data','stock_item_autocreated','stock_item','3','{\"name\":\"Televizyon T4\",\"kind\":\"product\"}','127.0.0.1','eb7119d21d0e7991a2d763564165fe8154d2adebb60fa588117a44a8562e4ad0','0d13f3d0ee28284fa70719bd2cd24aaa29ace42632394916830c0d35e6715053'),('141','2026-10-19 22:01:04','2','customer','1','data','stock_item_autocreated','stock_item','4','{\"name\":\"Nakliye T4\",\"kind\":\"service\"}','127.0.0.1','0d13f3d0ee28284fa70719bd2cd24aaa29ace42632394916830c0d35e6715053','29d48f5518b855f747046d64e6472f5a6291075fbe16e838ed53bc977651b743'),('142','2026-10-19 22:01:04','2','customer','1','data','invoice_created','invoice','15','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":7990000,\"due_date\":null,\"new_items\":3}','127.0.0.1','29d48f5518b855f747046d64e6472f5a6291075fbe16e838ed53bc977651b743','d2cb1e2b1ee8f432364f7e0ccd3807739cf2df22ab2b26eb468311c3bb7af216'),('143','2026-10-19 22:01:05','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":7990000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":7990000,\"due_date\":null,\"lines\":4}}','127.0.0.1','d2cb1e2b1ee8f432364f7e0ccd3807739cf2df22ab2b26eb468311c3bb7af216','5a4491fcd98bb656607983a23af42a9ccc7a72f0aa508d04898ce0965326cac0'),('144','2026-10-19 22:01:05','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":7990000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4}}','127.0.0.1','5a4491fcd98bb656607983a23af42a9ccc7a72f0aa508d04898ce0965326cac0','c1dd5095337611dab6e7a06af9ee4cb25c0ec994332f08ac8b49410e95347142'),('145','2026-10-19 22:01:05','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4}}','127.0.0.1','c1dd5095337611dab6e7a06af9ee4cb25c0ec994332f08ac8b49410e95347142','7d62fd626f08f7f28002a3f61eeb1b69a8aa6790348ec92aa6a81f45f23ebb29'),('146','2026-10-19 22:01:05','2','customer','1','data','invoice_updated','invoice','15','{\"before\":{\"total_minor\":10390000,\"due_date\":null,\"lines\":4},\"after\":{\"total_minor\":5590000,\"due_date\":null,\"lines\":4}}','127.0.0.1','7d62fd626f08f7f28002a3f61eeb1b69a8aa6790348ec92aa6a81f45f23ebb29','1c0ebee8ec8f825c61e1ace7e071ab69b4f169db83d7d75d3c61b7d2c0ff0535'),('147','2026-10-19 22:01:05','2','customer','1','data','invoice_created','invoice','16','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":1000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','1c0ebee8ec8f825c61e1ace7e071ab69b4f169db83d7d75d3c61b7d2c0ff0535','f5a486c18c6a07c0c6f5181fd5d88df175bba4fae5f1a92fe16d2990a2c32f68'),('148','2026-10-19 22:01:05','2','customer','1','data','stock_item_autocreated','stock_item','5','{\"name\":\"Stoksuz giriş\",\"kind\":\"product\"}','127.0.0.1','f5a486c18c6a07c0c6f5181fd5d88df175bba4fae5f1a92fe16d2990a2c32f68','bad325c2077f4d4bcdea5e2bc1276fc5277a486a39c7b7eb99deb97ebb445b90'),('149','2026-10-19 22:01:05','2','customer','1','data','invoice_created','invoice','17','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":4000,\"due_date\":null,\"new_items\":1}','127.0.0.1','bad325c2077f4d4bcdea5e2bc1276fc5277a486a39c7b7eb99deb97ebb445b90','3e16afa249bda2d0eec33f12beb437aa468c09f1da52e40e1394bd88fda71623'),('151','2026-10-19 22:01:05','2','customer','1','data','stock_item_autocreated','stock_item','7','{\"name\":\"Idem\",\"kind\":\"product\"}','127.0.0.1','3e16afa249bda2d0eec33f12beb437aa468c09f1da52e40e1394bd88fda71623','958d912a0aa07aa040ef6273c59eccc307396d6ed012861143f04f25eb34aee5'),('152','2026-10-19 22:01:05','2','customer','1','data','invoice_created','invoice','19','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":100,\"due_date\":null,\"new_items\":1}','127.0.0.1','958d912a0aa07aa040ef6273c59eccc307396d6ed012861143f04f25eb34aee5','dc45bca4490cee3e640e3568515319796f6b2a52d826e5cc64d82f72a980eab0'),('153','2026-10-19 22:01:05','2','customer','1','data','invoice_created','invoice','20','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":4500000,\"due_date\":null,\"new_items\":0}','127.0.0.1','dc45bca4490cee3e640e3568515319796f6b2a52d826e5cc64d82f72a980eab0','673748799eb55790f03b7bf1e2487bc4dad46aba10d2e4a83cfb5e39376237ad'),('154','2026-10-19 22:01:05','2','customer','1','data','invoice_cancelled','invoice','20','{\"reason\":\"müşteri vazgeçti\",\"total_minor\":4500000,\"was\":\"issued\"}','127.0.0.1','673748799eb55790f03b7bf1e2487bc4dad46aba10d2e4a83cfb5e39376237ad','f65d7acbfcae340c92a5f38e77e8855186f85bf53b8fcd9db14921a8a8b15605'),('155','2026-10-19 22:01:05','2','customer','1','data','stock_item_autocreated','stock_item','8','{\"name\":\"Silinecek\",\"kind\":\"product\"}','127.0.0.1','f65d7acbfcae340c92a5f38e77e8855186f85bf53b8fcd9db14921a8a8b15605','1b62d14748776157b24e706a692eff02647d6d6bd7c67d8b0cf28f7f901198bf'),('156','2026-10-19 22:01:05','2','customer','1','data','invoice_created','invoice','21','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":200,\"due_date\":null,\"new_items\":1}','127.0.0.1','1b62d14748776157b24e706a692eff02647d6d6bd7c67d8b0cf28f7f901198bf','5e1a0427b5983da0e1ffbd07cad6336a70588afde1829687c977b4e67161680b'),('157','2026-10-19 22:01:05','2','customer','1','data','invoice_deleted','invoice','21','{\"snapshot\":{\"kind\":\"purchase\",\"number\":\"T4-DEL\",\"contact_id\":2,\"issue_date\":\"2026-10-20\",\"due_date\":null,\"currency\":\"TRY\",\"status\":\"issued\",\"total_minor\":200}}','127.0.0.1','5e1a0427b5983da0e1ffbd07cad6336a70588afde1829687c977b4e67161680b','5f3bc546e02872edd9f5e2733fb7aa2c5d688931c59ad2f7e9e79517022d2023'),('158','2026-10-19 22:01:06','2','customer','1','data','invoice_updated','invoice','9','{\"before\":{\"total_minor\":1000000,\"due_date\":null,\"lines\":1},\"after\":{\"total_minor\":1200000,\"due_date\":null,\"lines\":1}}','127.0.0.1','5f3bc546e02872edd9f5e2733fb7aa2c5d688931c59ad2f7e9e79517022d2023','9175e345eb6f303b48ab9d2d6a12b089f04d6ec830d6f2068b163f2462ca16f2'),('159','2026-10-19 22:01:06','2','customer','1','data','invoice_created','invoice','22','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":50000,\"due_date\":null,\"new_items\":0}','127.0.0.1','9175e345eb6f303b48ab9d2d6a12b089f04d6ec830d6f2068b163f2462ca16f2','e1901ab1bf53991c512eef52ae8e074737aaa8a4f675b3e8dfac38d0374f6fe0'),('160','2026-10-19 22:01:06','2','customer','1','data','collection_created','transaction','33','{\"amount_minor\":50000,\"contact_id\":1,\"allocations\":{\"29\":50000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','e1901ab1bf53991c512eef52ae8e074737aaa8a4f675b3e8dfac38d0374f6fe0','06cc75dbd3e8aefdda41584fad7b8cf1ef267d589608b936404260cf185cffb6'),('161','2026-10-19 22:01:06','2','customer','1','data','invoice_created','invoice','23','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":30000,\"due_date\":null,\"new_items\":0}','127.0.0.1','06cc75dbd3e8aefdda41584fad7b8cf1ef267d589608b936404260cf185cffb6','e22b461624585ce2b58263ce1d2f76d22c9dccbb1a6f5ff2072e64e0a0833ba3'),('162','2026-10-19 22:01:06','2','customer','1','data','invoice_delivery','invoice','22','{\"lines\":1,\"date\":\"2026-10-20\"}','127.0.0.1','e22b461624585ce2b58263ce1d2f76d22c9dccbb1a6f5ff2072e64e0a0833ba3','9de250903377accb96c4a8afc823aaa55945b7d611071e543630339cc8f3be69'),('163','2026-10-19 22:01:06','2','customer','1','data','invoice_created','invoice','24','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":2000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','9de250903377accb96c4a8afc823aaa55945b7d611071e543630339cc8f3be69','0d5a06d65cae111ed632029e9fa47dad1291cbcea48e7ed9939fc86c119d5216'),('164','2026-10-19 22:01:06','2','customer','1','data','payment_created','transaction','34','{\"amount_minor\":2000000,\"contact_id\":2,\"allocations\":{\"31\":2000000},\"unallocated_minor\":0,\"for_workspace_id\":1}','127.0.0.1','0d5a06d65cae111ed632029e9fa47dad1291cbcea48e7ed9939fc86c119d5216','ef336a08ca3e1567d3aad043dbc311ad00640fc4aa01be485b0f9486af340798'),('165','2026-10-19 22:01:06','2','customer','1','data','transaction_meta_updated','transaction','34','{\"before\":{\"description\":\"Şahsi hesaptan ödendi, dekont sonra eklenecek\",\"reason\":\"ABC müşterisi siparişi malzeme alımı\"},\"after\":{\"description\":\"dekont eklendi\",\"reason\":\"Güncel neden\"}}','127.0.0.1','ef336a08ca3e1567d3aad043dbc311ad00640fc4aa01be485b0f9486af340798','81f21d3615f49dbb623ea444d896b8d3271daa844faf77d0f4f0fbb99c90b6bc'),('166','2026-10-19 22:01:07','2','customer','1','data','transfer_created','transfer','17911928cfdcd0bef2f875d92d','{\"from\":5,\"to\":1,\"amount_minor\":700000,\"kind\":\"owner_in\"}','127.0.0.1','81f21d3615f49dbb623ea444d896b8d3271daa844faf77d0f4f0fbb99c90b6bc','d2caeb0b900d4cfb7432fd38e131cf04a1c53bc3408d6fd701665de19b2a4850'),('167','2026-10-19 22:01:07','2','customer','1','data','transfer_created','transfer','fab92ee8f8b66fbc2e7350a4d5','{\"from\":1,\"to\":5,\"amount_minor\":2700000,\"kind\":\"owner_out\"}','127.0.0.1','d2caeb0b900d4cfb7432fd38e131cf04a1c53bc3408d6fd701665de19b2a4850','9fbc7030ee04e8a4056ea3df05e985963690ece02aa3ed69742a9e1ec960e350'),('168','2026-10-19 22:01:07','2','customer','1','data','transfer_created','transfer','79d48162b95819a7c9662a39d3','{\"from\":1,\"to\":2,\"amount_minor\":1000,\"kind\":\"transfer\"}','127.0.0.1','9fbc7030ee04e8a4056ea3df05e985963690ece02aa3ed69742a9e1ec960e350','f818de50e389e70ab5e5a2227a8ece9b96b8b6e5b07b73d20798ca1b70836ba5'),('169','2026-10-19 22:01:07','2','customer','1','data','account_created','account','8','{\"opening_minor\":0}','127.0.0.1','f818de50e389e70ab5e5a2227a8ece9b96b8b6e5b07b73d20798ca1b70836ba5','793bd0dcbaea8c7ab87de865f880314d936a46ea990f24df19de93f9fa6fbe16'),('170','2026-10-19 22:01:07','2','customer','1','data','account_updated','account','8','{\"before\":{\"name\":\"Yanlış Kasa\",\"kind\":\"cash\",\"currency\":\"TRY\"},\"after\":{\"name\":\"Yanlış Kasa 2\",\"kind\":\"bank\",\"currency\":\"EUR\"}}','127.0.0.1','793bd0dcbaea8c7ab87de865f880314d936a46ea990f24df19de93f9fa6fbe16','c98fe9b1a992e0256e4884dcf3c61fc85aba4540f54a76ef07d33277639a6160'),('171','2026-10-19 22:01:07','2','customer','1','data','account_deleted','account','8','{\"name\":\"Yanlış Kasa 2\",\"opening_minor\":0}','127.0.0.1','c98fe9b1a992e0256e4884dcf3c61fc85aba4540f54a76ef07d33277639a6160','5c3d3e6cdff2a9d9b5ed13e6bef60b72f3d3ee9182ea8320efd4793b0caf3f9b'),('172','2026-10-19 22:01:07','2','customer','1','data','contact_created','contact','3',NULL,'127.0.0.1','5c3d3e6cdff2a9d9b5ed13e6bef60b72f3d3ee9182ea8320efd4793b0caf3f9b','5ca6a40689957aa83c41c49285734f8f715e46123d5a147d1bfff3302272e0d3'),('173','2026-10-19 22:01:07','2','customer','1','data','contacts_deleted','contacts','3','{\"name\":\"Silinecek Cari\"}','127.0.0.1','5ca6a40689957aa83c41c49285734f8f715e46123d5a147d1bfff3302272e0d3','f8aad166ed9fac20174707d1bb02fce5660726cd6e88aea2ccb8442f056a0acb'),('174','2026-10-19 22:01:07','2','customer','1','data','categories_deleted','categories','35','{\"name\":\"Silinecek Kat\"}','127.0.0.1','f8aad166ed9fac20174707d1bb02fce5660726cd6e88aea2ccb8442f056a0acb','8d1e64843e1f05cbeb63cb17ae4e9099db163ed9cee7fcbec4e632bab000c147'),('175','2026-10-19 22:01:07','2','customer','1','data','project_created','project','2',NULL,'127.0.0.1','8d1e64843e1f05cbeb63cb17ae4e9099db163ed9cee7fcbec4e632bab000c147','bbe9d22efc70c47dbbcab35afbbbe29006ac41e224275a56d73236f0f996a96c'),('176','2026-10-19 22:01:07','2','customer','1','data','projects_deleted','projects','2','{\"name\":\"Silinecek Proje\"}','127.0.0.1','bbe9d22efc70c47dbbcab35afbbbe29006ac41e224275a56d73236f0f996a96c','289196dcc3f1e9b6d653b44e71d2613a04ea1eaa2716dd9eac073f4b6b3107a1'),('177','2026-10-19 22:01:07','2','customer','1','data','stock_items_deleted','stock_items','10','{\"name\":\"Boş Kart\"}','127.0.0.1','289196dcc3f1e9b6d653b44e71d2613a04ea1eaa2716dd9eac073f4b6b3107a1','8c109f2b36845a059cfb777e62c9472ab656c0201d20fe20500952b9b09cd1d1'),('178','2026-10-19 22:01:07','2','customer','1','data','warehouses_deleted','warehouses','2','{\"name\":\"Boş Depo\"}','127.0.0.1','8c109f2b36845a059cfb777e62c9472ab656c0201d20fe20500952b9b09cd1d1','7105c5ad367c3aeb3fbab11c9bc936f111f37c713edd7eb2ecf60b4493a770a6'),('179','2026-10-19 22:01:07','2','customer','1','data','entry_created','entry','32','{\"kind\":\"payable\",\"amount_minor\":80000,\"installments\":1}','127.0.0.1','7105c5ad367c3aeb3fbab11c9bc936f111f37c713edd7eb2ecf60b4493a770a6','4c123dbac958ba79a83cc7190ef44086fc5ead52991dc508ecd67f4601ca87f5'),('180','2026-10-19 22:01:07','2','customer','1','data','entry_rescheduled','entry','32','{\"before\":{\"title\":\"Elektrik\",\"provider\":\"Enerjisa\",\"period\":null,\"amount_minor\":80000,\"due_date\":\"2026-10-25\"},\"after\":{\"title\":\"Elektrik (düzeltildi)\",\"provider\":\"Başka\",\"period\":\"2026-10\",\"due_date\":null,\"amount_minor\":85000}}','127.0.0.1','4c123dbac958ba79a83cc7190ef44086fc5ead52991dc508ecd67f4601ca87f5','d18630cbaa7876b5c7809fac7799436e680a337d8d6cdc69b4dc4a8479c17ea9'),('181','2026-10-19 22:01:07','2','customer','1','data','entry_deleted','entry','32','{\"snapshot\":{\"workspace_id\":2,\"kind\":\"payable\",\"source\":\"personal_bill\",\"contact_id\":null,\"title\":\"Elektrik (düzeltildi)\",\"currency\":\"TRY\",\"amount_minor\":85000,\"due_date\":null}}','127.0.0.1','d18630cbaa7876b5c7809fac7799436e680a337d8d6cdc69b4dc4a8479c17ea9','4d75bbf6c3ca45d1f61150b710d3e5f6ef1ee210ad06dc0d0c84c6206e5acf4a'),('182','2026-10-19 22:01:07','2','customer','1','data','entry_created','entry','33','{\"kind\":\"payable\",\"amount_minor\":10000,\"installments\":1}','127.0.0.1','4d75bbf6c3ca45d1f61150b710d3e5f6ef1ee210ad06dc0d0c84c6206e5acf4a','23cb09e901fb81ebf2984a025ae7fe28dd2cd8ad1a23133be533a76c8e98b4b1'),('183','2026-10-19 22:01:08','2','customer','1','data','payment_created','transaction','41','{\"amount_minor\":4000,\"contact_id\":null,\"allocations\":{\"33\":4000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','23cb09e901fb81ebf2984a025ae7fe28dd2cd8ad1a23133be533a76c8e98b4b1','c4ac947bc6242302a2dfb8215da4633bd5838808ef60041431a391ad58099197'),('184','2026-10-19 22:01:08','2','customer','1','data','document_uploaded','invoice','9','{\"doc\":2,\"size\":70}','127.0.0.1','c4ac947bc6242302a2dfb8215da4633bd5838808ef60041431a391ad58099197','a4f44a191bf83364818df97ae979dc4e3bd741f79c95c5f95e0a825aef6bdb37'),('185','2026-10-19 22:01:08','2','customer','1','data','document_deleted','document','2',NULL,'127.0.0.1','a4f44a191bf83364818df97ae979dc4e3bd741f79c95c5f95e0a825aef6bdb37','3a4fb616c3fb4e259940bce44ae64227b1aa0888a2f03df16050d70101d51afd'),('186','2026-10-19 22:01:08','2','customer','1','data','document_uploaded','transaction','34','{\"doc\":3,\"size\":70}','127.0.0.1','3a4fb616c3fb4e259940bce44ae64227b1aa0888a2f03df16050d70101d51afd','cf20b084b859edd804d571a392a7c267188f5a5975af804ba0cb209eb0e557e9'),('187','2026-10-19 22:01:08','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','cf20b084b859edd804d571a392a7c267188f5a5975af804ba0cb209eb0e557e9','dc2cfa5379b7740b5072753cc938b7bb049ed660790262da80c63ba212c1c288'),('188','2026-10-19 22:01:08','3','customer','2','security','login_success',NULL,NULL,NULL,'127.0.0.1','dc2cfa5379b7740b5072753cc938b7bb049ed660790262da80c63ba212c1c288','d35afdffb620549e328e481273df0dbe4edcf25f22a0a8edbd47dcae33c93998'),('189','2026-10-19 22:01:08','2','customer','1','data','contact_created','contact','4',NULL,'127.0.0.1','d35afdffb620549e328e481273df0dbe4edcf25f22a0a8edbd47dcae33c93998','f4355f4e3a7e8978a5acd1365449fc8fb327d9f5318e7592c88ad3fb474a7a4a'),('190','2026-10-19 22:01:08','2','customer','1','data','invoice_created','invoice','25','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":10000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','f4355f4e3a7e8978a5acd1365449fc8fb327d9f5318e7592c88ad3fb474a7a4a','268bf0596ea384e9afe43066ba365b816fc5375f8205422b82efa207d44d94d1'),('191','2026-10-19 22:01:08','2','customer','1','data','collection_created','transaction','42','{\"amount_minor\":3000000,\"contact_id\":4,\"allocations\":{\"34\":3000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','268bf0596ea384e9afe43066ba365b816fc5375f8205422b82efa207d44d94d1','571e8a57a7fafed6267b6fbfaad05b92180ea74c3a8ee03855dda9f2c220fd4e'),('192','2026-10-19 22:01:09','2','customer','1','data','contact_created','contact','5',NULL,'127.0.0.1','571e8a57a7fafed6267b6fbfaad05b92180ea74c3a8ee03855dda9f2c220fd4e','e7f874d1593cccbee258404b022c42b051fb5cb7efea081f3e979e79fa9c4d5c'),('193','2026-10-19 22:01:09','2','customer','1','data','collection_created','transaction','43','{\"amount_minor\":3000000,\"contact_id\":5,\"allocations\":[],\"unallocated_minor\":3000000,\"for_workspace_id\":null}','127.0.0.1','e7f874d1593cccbee258404b022c42b051fb5cb7efea081f3e979e79fa9c4d5c','711273009cee0b82fc825086cc0169af2349b3c861de9af5c4c7596aa748d5a3'),('194','2026-10-19 22:01:09','2','customer','1','data','transaction_created','transaction','44','{\"kind\":\"income\",\"amount_minor\":7700,\"replaces\":null}','127.0.0.1','711273009cee0b82fc825086cc0169af2349b3c861de9af5c4c7596aa748d5a3','a38b3c8672d0f2b6de7d88a6cb54bde86a311b628c7777b02399d13c481c1ad4'),('195','2026-10-19 22:01:09','2','customer','1','data','transaction_voided','transaction','44','{\"reason\":\"test\",\"before\":{\"kind\":\"income\",\"amount_minor\":7700,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[44]}','127.0.0.1','a38b3c8672d0f2b6de7d88a6cb54bde86a311b628c7777b02399d13c481c1ad4','7bc0904fa87d3fc262967017df8f961ec2492be137dace480e3d4611ff256b1e'),('196','2026-10-19 22:01:09','2','customer','1','data','transaction_created','transaction','45','{\"kind\":\"income\",\"amount_minor\":50000,\"replaces\":null}','127.0.0.1','7bc0904fa87d3fc262967017df8f961ec2492be137dace480e3d4611ff256b1e','07dd3706b3904f3dce401ba4e10f7d27c705acea58d78e7008e7727cb310f908'),('197','2026-10-19 22:01:09','2','customer','1','data','income_converted_to_collection','transaction','45','{\"amount_minor\":50000,\"contact_id\":5,\"was_vat_minor\":0}','127.0.0.1','07dd3706b3904f3dce401ba4e10f7d27c705acea58d78e7008e7727cb310f908','67d0d94753cf49f75efafb8b3e8a3531823f96ef56b072bf92501458c18c583a'),('198','2026-10-19 22:01:09','2','customer','1','data','transaction_voided','transaction','45','{\"reason\":\"test temizliği\",\"before\":{\"kind\":\"collection\",\"amount_minor\":50000,\"date\":\"2026-10-20\",\"account_id\":1},\"legs\":[45]}','127.0.0.1','67d0d94753cf49f75efafb8b3e8a3531823f96ef56b072bf92501458c18c583a','cc89f52cec47d566bccd6d32b85d9165907faaad1a6405140c10de7035f0b481'),('199','2026-10-19 22:01:09','2','customer','1','data','invoice_created','invoice','26','{\"kind\":\"sales\",\"status\":\"issued\",\"total_minor\":10000000,\"due_date\":null,\"new_items\":0}','127.0.0.1','cc89f52cec47d566bccd6d32b85d9165907faaad1a6405140c10de7035f0b481','399a2ad61354663f1312ff63f70177c06bd8fc74a50b8d1893f50cccc4023891'),('200','2026-10-19 22:01:09','2','customer','1','data','payment_allocated','transaction','43','{\"new_minor\":3000000,\"allocated_minor\":3000000,\"unallocated_minor\":0}','127.0.0.1','399a2ad61354663f1312ff63f70177c06bd8fc74a50b8d1893f50cccc4023891','87f3c60599aaf1304402790160c412f4f8153b395c56b578588f4159e70d4185'),('201','2026-10-19 22:01:09','2','customer','1','data','entry_updated','entry','35','{\"before\":{\"planned_date\":null},\"after\":{\"planned_date\":\"2026-10-18\"}}','127.0.0.1','87f3c60599aaf1304402790160c412f4f8153b395c56b578588f4159e70d4185','8197e1e4db9ee50360c85a1e2861261d5f80d5b9b3105299fc1ecf8e76432ea3');
/*FBEND*/
INSERT INTO `audit_log` VALUES ('202','2026-10-19 22:01:09','2','customer','1','data','entry_updated','entry','35','{\"before\":{\"planned_date\":\"2026-10-18\"},\"after\":{\"planned_date\":\"2026-10-20\"}}','127.0.0.1','8197e1e4db9ee50360c85a1e2861261d5f80d5b9b3105299fc1ecf8e76432ea3','efa9adbf1cf20daf98126df5fd9489a6b84cdd3655e9bf2b4dd0043b7671c06d'),('203','2026-10-19 22:01:09','2','customer','1','data','collection_created','transaction','46','{\"amount_minor\":7000000,\"contact_id\":5,\"allocations\":{\"35\":7000000},\"unallocated_minor\":0,\"for_workspace_id\":null}','127.0.0.1','efa9adbf1cf20daf98126df5fd9489a6b84cdd3655e9bf2b4dd0043b7671c06d','9f9cae168f339c92eac90e7273e1a053b2432b19c76dbb4a9f7125b648989985'),('204','2026-10-19 22:01:09','2','customer','1','data','invoice_created','invoice','27','{\"kind\":\"purchase\",\"status\":\"issued\",\"total_minor\":100000,\"due_date\":\"2026-10-25\",\"new_items\":0}','127.0.0.1','9f9cae168f339c92eac90e7273e1a053b2432b19c76dbb4a9f7125b648989985','ab0bc40e5d45caf5d32d6b6d72a7f7beb58260baf3df875d4abd24d530c3fbc2'),('205','2026-10-19 22:01:09','2','customer','1','security','login_success',NULL,NULL,NULL,'127.0.0.1','ab0bc40e5d45caf5d32d6b6d72a7f7beb58260baf3df875d4abd24d530c3fbc2','1cc0595892ac17471489cea9152541053749ea8c9482ac9bf516813e6d41713d'),('206','2026-10-19 22:01:31','1','admin',NULL,'security','login_success',NULL,NULL,NULL,'127.0.0.1','1cc0595892ac17471489cea9152541053749ea8c9482ac9bf516813e6d41713d','31ff5087c188eacaa5e4b1e911d72f9493d11cf2b59817d60a5821bb8067dadc'),('207','2026-10-19 22:01:31','2','customer','1','data','contact_created','contact','6',NULL,'127.0.0.1','31ff5087c188eacaa5e4b1e911d72f9493d11cf2b59817d60a5821bb8067dadc','5a9fb68907549464fbbf5f0a3df45bdaacf8c097f47cb16bed21b213637cf514'),('208','2026-10-19 22:01:32','2','customer','1','data','document_uploaded','transaction','46','{\"doc\":4,\"size\":70}','127.0.0.1','5a9fb68907549464fbbf5f0a3df45bdaacf8c097f47cb16bed21b213637cf514','73ae936ec75ba0bc9c45b31066482f16fd3c5debc96fac610fdd7108e1f58f61');
/*FBEND*/
DROP TABLE IF EXISTS `budgets`;
/*FBEND*/
CREATE TABLE `budgets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `month` char(7) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `amount_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_bud` (`tenant_id`,`category_id`,`month`,`currency`),
  CONSTRAINT `fk_bu_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `budgets` VALUES ('1','1','9','2026-10','TRY','200000');
/*FBEND*/
DROP TABLE IF EXISTS `captchas`;
/*FBEND*/
CREATE TABLE `captchas` (
  `id` char(32) NOT NULL,
  `answer_hash` char(64) NOT NULL,
  `pow_seed` char(32) NOT NULL,
  `pow_bits` tinyint(4) NOT NULL,
  `ip_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_captcha_exp` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `captchas` VALUES ('03d5e121ddaf9b5014c127b6385e9e7e','c33da01e47bb7a51dcd5c226427e69551a5ac51fe52558731c6dc41f01612f10','c3356f1258ace252','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:02:33','2026-10-19 21:59:33'),('0d3882b10a4543c54d10cca9f56ad708','762d45c6c2c0a39689faecd5fbb6b57e9fd7fd7506fbca8db7c464520120b0c8','efb8698d42001913','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:33','2026-10-19 22:00:33'),('1478ade6fb7d4348f9f1885a55b1b07f','c50b1cecfd308ee1e09ed31c878140e2982766ce5ae7cb4122e4385509a7bc10','f54ec331bb25db11','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:33','2026-10-19 22:00:33'),('1728f75bfaa17115f00f871c8e236192','712bec1840ae34451c56d015f93a91035864593ba4f5a8cb7bd9b8f7540326c2','626f5b80ad28216c','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:33','2026-10-19 22:00:33'),('1772ab0b2ad21025afae54a5a15cf6b2','985e41bb16bd17d6d9786129cc84331da83289d565c61a6fb21e16bb778ebe7d','1d24031116253591','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:32','2026-10-19 22:00:32'),('1e8a6eaff11848ad0098e8ee58153a99','63ad4b99d064907eb754ec9dd52d3539c389263fe508e640cfd8b5e204e78a20','5c0b75cbe930ba82','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:30',NULL),('1f35b22fbba2f8b2c714ca6ba9d6dd2a','33b3521c8b07b447d2ad4375ae4d9f0e7b0fef81ea348430d30b1d97d20ca9b0','d873e86bf6a2a7c4','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:01:04','2026-10-19 21:58:04'),('25a114ca467e6f3111f9e26953a8879b','0c8c0d3017740304948f080a0e327354aafef5eee8d6b486a8558ab26ba3ae11','81406978ded9d0ee','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:04:09','2026-10-19 22:01:09'),('27d0b517b756383f9a67fd7cdc125489','c1753f9107076a0252036e343f70ffb127ea5b0c13b9da1c1b810f36e34098ca','6127e3c45cb3e75e','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:32','2026-10-19 22:00:32'),('28555f2c07c6c2849eeb302ea36baa78','6adda588509f84cb5466779b3c733325852b8f8c8f1b2db29866fbc3f159f8ef','e8fe31cd8bf42046','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:01:04','2026-10-19 21:58:04'),('2b5a55857766e9114d7b432ac722664b','087a41a1a662f554fcdb1ab54393bb8701855dcbc064d7916c670e1dc09953f2','cc6622ef3efd0c02','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:32','2026-10-19 22:00:32'),('351e2995eaea342502d7304ab2ef2477','4a9d8525861ffdc55c35643806b85e9a9cb4452b26f631b2ce0249c78a2a11bf','f81e6de4a09ea0e3','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:40','2026-10-19 22:00:40'),('35d6a5602e880df612cefc75b1f79133','98109ca98677a88f57476322887e6904c41fc03156184cf783ee4286514bc98b','c4dbf4865090fcef','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:02:02',NULL),('36e96065e6f857df91d622fc3b99fb87','0c8e9218d6076712f77a6ac892dc18fab945d8290ae8aa3d4dc79006f6bf71d0','445d2fe62fd19974','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:01:08','2026-10-19 21:58:08'),('3d6830cc253f40502e4ba021a86f4f9a','a9fb9491a97ef31bc0114de80e0c8a9b0c6e4bd7a4396ac559fd58b93f8cff80','8a9e491dd700dd98','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:32','2026-10-19 22:00:32'),('497ea85d32fe0b43c25204c6ff602399','f832d55d9e38539779b1817621fa4987007deffece7b305e2baecc9a7b386ac8','087d679262d6cb61','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:33','2026-10-19 22:00:33'),('5d4a8001e639eaecbb2711ae1eacb120','ba9dea909f1dfa7f2a2c32a590ae3175f3673710104fac090dbe3fa39b14aa6d','ca212d3dd47b8fb8','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:01:04','2026-10-19 21:58:04'),('6260efca51fae4decd59d95baee85d35','d16d8e5ebdcf8569aae995e024bb6ba0e4bcc59f32d829dd6fdd2a3673809bc1','b13cc53c48717266','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:32','2026-10-19 22:00:32'),('66c57690f69164ecb43005915ba816ec','b44505f76c718f7d61baa860c9345565b704181b52f770c55bdac76823ba340d','ccd1cf6a029f9e5b','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:04:02','2026-10-19 22:01:02'),('688e0de53433ff2541fbfa6e395f1d1f','c3f03cb496061db7e02693109d155e4d416b3fa672f67affef7c2af2ab0a4313','672564ab59e41201','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:04:09','2026-10-19 22:01:09'),('6974aaa8bd01ab2b2075183a14537716','632ff151f516c80a79d7a4c6fcdb92cd65bcf2158015a13fd14caf6ed3f21ffd','6c19e67fdf6af0ec','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:32','2026-10-19 22:00:32'),('6d486be4d0473d1dc015eb63762d84f1','56ee09b1d37ee15ea8cc05b41e69edce18cfc8859e6d51e785b48bb74fecc53a','c1f2d12413d3d302','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:31','2026-10-19 22:00:31'),('751a935207c3af25cb074c5a8f9dbdbc','0abc5c56f390bdefb58428dbb91339616d1acebc2a01fe798149f27ace1a5e10','b41b825285dbad49','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:30','2026-10-19 22:00:30'),('7ac5733e8db3fe7a596b9ff10a4ab379','e8f01f292d4bb5c3623bfc3d2bd28c5034a43c17f5a1e2b00452cea021c66d5c','cb70d3697e3a5aaf','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:02:02','2026-10-19 21:59:02'),('83c02c4e9158aa3942aa071327d4112c','8f2efa9e5a6160d95ec9bb6afb72e6b2a3f204c373fb908f72c5c6f5f41c2f36','86bb27881d885b90','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:04:01','2026-10-19 22:01:01'),('88c37a3223040a7d7a32ebf135df119a','1217bc52d9cb4ad9873dd9805ddb3c27e34fc2f432a888141e92e059e2d1c065','9bd02e1e9dff7a68','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:31','2026-10-19 22:00:31'),('9585c589d37a798f439acd6c28216ad7','784ccc26553f612d9a9347aa7e882fa2d5040b830ca2259078ded8c11f436122','d3e04866fb7ffcc2','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:00','2026-10-19 22:00:00'),('a8691c859cd8a1daa141b1c092867a24','c83f63ea019bc789f9c08c2ca032bc949d09da91f437ed3a1882cd19475ea016','1828f776d1acb6a4','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:31','2026-10-19 22:00:31'),('abecb2008a5e62e65cd1dd7c7ff13784','9d5b304cd86eeda691d93b6d107b257d66ffa4d3bf38f1460dd4c0ba1dd9e70d','ac5e2e3d64c1e35a','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:04:08','2026-10-19 22:01:08'),('b2811dbde1ca1ddc3bccfeeb32c21faf','a7961a5b04d566070f0e99a8796dbc52e946d6493b138ee550fe216a27e5dbb8','49dcd212fd7ca261','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:30','2026-10-19 22:00:30'),('bd617c35583cc5884fefda156869a6b9','0856d8655797c4be8c65acaca7a276410868e0e4c8082cbedeb103026705efd1','77439a3952f712ee','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:33','2026-10-19 22:00:33'),('c17777a4509e70843864f8a965307c4c','8e243621e1d8fb869e7641ba3a776a99cbf03e88c9871ed7e8c3b0002e04a89d','b7229f792cad1420','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:33','2026-10-19 22:00:33'),('d1a78e739fb90fc5a67e47d45e5c7a04','5316a6a911d678d45d8d9bf3d8847f67eb303c55edc90d39a6d0c24475c73ab1','795ed51407bdfb0b','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:32','2026-10-19 22:00:32'),('d3268aed286477ed631a06efc914dda5','2e788fb93128b02feb2ceb5b4dfdb554153793a4094226ef1703b47cb2525d27','a8f296ea5b014e56','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:30','2026-10-19 22:00:30'),('dc6928737eb8b7432fce7f59f265f095','8b63247cf19a0b09b628430bd8991a125e1ba377bac709b458783e71ddd2c3a4','df2ab3c7c8fdc3b5','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:01:32','2026-10-19 21:58:32'),('e2ce8211b1aa77b3ad07c451ee35c655','656809b7772315ec17c8fae288c6ecca7936347a8afd62700707eef09774e539','f0807bf05f113eab','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:32','2026-10-19 22:00:32'),('e4cc010e7e22046a558b9aa69ee2093f','8e3941c733d1db928013649b8d89193bc117ffa45e1d4d029745b960e6e7cab0','9484a4fa20b17e07','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:32','2026-10-19 22:00:32'),('e7a8dfbeed7656a70720e78c186517af','0adee880596cc7eadbe6b683e7608315bae69bb801e28ca6e1e68199c9a8d38b','0a38dcbacd02f9fe','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:04:08','2026-10-19 22:01:08'),('eb6c6c95399e1072798412d26e32d7d0','a62f8ea10ce189e41a5f424899846499146cd6793fc9dd53053cd5b384e6556e','3cfd0a85266dea50','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:03:33','2026-10-19 22:00:33'),('fdd7418656a2f227edc4dd5a8c65d999','3500dc3bd30605201526f6f06c21e627ca06bc925f102ba34779a90552c3d945','5af5e955e79666ab','8','9f2db8f07634ca4e0e799a6b0b2b5f2c0b6fec32eef398ae6c28e7435ff7b0d8','2026-10-19 22:02:02','2026-10-19 21:59:02');
/*FBEND*/
DROP TABLE IF EXISTS `card_installments`;
/*FBEND*/
CREATE TABLE `card_installments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `card_id` bigint(20) unsigned NOT NULL,
  `purchase_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ci_t` (`tenant_id`,`card_id`,`due_date`),
  KEY `fk_ci_p` (`purchase_id`),
  CONSTRAINT `fk_ci_p` FOREIGN KEY (`purchase_id`) REFERENCES `card_purchases` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `card_installments` VALUES ('1','1','1','1','1','2026-11-15','40000'),('2','1','1','1','2','2026-12-15','40000'),('3','1','1','1','3','2027-01-15','40000');
/*FBEND*/
DROP TABLE IF EXISTS `card_purchases`;
/*FBEND*/
CREATE TABLE `card_purchases` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `card_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `txn_date` date NOT NULL,
  `description` varchar(250) NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `installments` int(11) NOT NULL DEFAULT 1,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_cp_t` (`tenant_id`,`card_id`),
  CONSTRAINT `fk_cp_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `card_purchases` VALUES ('1','1','1','1','2026-10-20','Ofis malzemesi','120000','2000','20000','3','9',NULL,NULL,'posted','2026-10-19 22:00:36');
/*FBEND*/
DROP TABLE IF EXISTS `cards`;
/*FBEND*/
CREATE TABLE `cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `limit_minor` bigint(20) NOT NULL DEFAULT 0,
  `statement_day` tinyint(4) NOT NULL DEFAULT 1,
  `due_day` tinyint(4) NOT NULL DEFAULT 10,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cd_t` (`tenant_id`),
  CONSTRAINT `fk_cd_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `cards` VALUES ('1','1','1','Kurumsal Kart',NULL,'TRY','5000000','5','15','0','2026-10-19 22:00:36');
/*FBEND*/
DROP TABLE IF EXISTS `categories`;
/*FBEND*/
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('income','expense') NOT NULL,
  `name` varchar(100) NOT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_cat` (`tenant_id`,`kind`,`name`),
  CONSTRAINT `fk_cat_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `categories` VALUES ('1','1','income','Satış Geliri','0'),('2','1','income','Hizmet Geliri','0'),('3','1','income','Kira Geliri','0'),('4','1','income','Faiz Geliri','0'),('5','1','income','Diğer Gelirler','0'),('6','1','expense','Yakıt','0'),('7','1','expense','Ulaşım','0'),('8','1','expense','Yemek','0'),('9','1','expense','Malzeme','0'),('10','1','expense','İşçilik','0'),('11','1','expense','Taşeron','0'),('12','1','expense','Kira','0'),('13','1','expense','Abonelik','0'),('14','1','expense','Banka Masrafı','0'),('15','1','expense','Vergi','0'),('16','1','expense','Sigorta','0'),('17','1','expense','Diğer Giderler','0'),('18','2','income','Satış Geliri','0'),('19','2','income','Hizmet Geliri','0'),('20','2','income','Kira Geliri','0'),('21','2','income','Faiz Geliri','0'),('22','2','income','Diğer Gelirler','0'),('23','2','expense','Yakıt','0'),('24','2','expense','Ulaşım','0'),('25','2','expense','Yemek','0'),('26','2','expense','Malzeme','0'),('27','2','expense','İşçilik','0'),('28','2','expense','Taşeron','0'),('29','2','expense','Kira','0'),('30','2','expense','Abonelik','0'),('31','2','expense','Banka Masrafı','0'),('32','2','expense','Vergi','0'),('33','2','expense','Sigorta','0'),('34','2','expense','Diğer Giderler','0');
/*FBEND*/
DROP TABLE IF EXISTS `contacts`;
/*FBEND*/
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('customer','supplier','both') NOT NULL DEFAULT 'customer',
  `name` varchar(200) NOT NULL,
  `tax_no` varchar(30) DEFAULT NULL,
  `tax_office` varchar(100) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `address` varchar(400) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ct_t` (`tenant_id`),
  CONSTRAINT `fk_ct_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `contacts` VALUES ('1','1','customer','Müşteri A',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 22:00:34'),('2','1','supplier','Tedarikçi B',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 22:00:34'),('4','1','customer','Avans Müşterisi',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 22:01:08'),('5','1','customer','Avans Müşterisi 2',NULL,NULL,NULL,NULL,NULL,NULL,'0','2026-10-19 22:01:09'),('6','1','customer','<script>alert(1)</script>',NULL,NULL,NULL,NULL,NULL,'\"><img src=x onerror=alert(1)>','0','2026-10-19 22:01:31');
/*FBEND*/
DROP TABLE IF EXISTS `documents`;
/*FBEND*/
CREATE TABLE `documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `entity` varchar(30) NOT NULL,
  `entity_id` bigint(20) unsigned NOT NULL,
  `orig_name` varchar(200) NOT NULL,
  `stored_name` char(64) NOT NULL,
  `mime` varchar(100) NOT NULL,
  `size_bytes` bigint(20) NOT NULL,
  `sha256` char(64) NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_doc_ent` (`tenant_id`,`entity`,`entity_id`),
  CONSTRAINT `fk_doc_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `documents` VALUES ('1','1','transaction','18','fis.png','3243592af22858577de1eee8e8de9758da3909bdfc389b1c8309820d76998921','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 22:00:39',NULL),('2','1','invoice','9','fatura.png','faf2bd70e29e5600c6e83aa4e291f215ecf203eb9dfdd082f9a7d9ebb5b37f57','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 22:01:08','2026-10-19 22:01:08'),('3','1','transaction','34','dekont.png','cc25b0b464d9caefb05e2f8c846aae363fc4e36b99c77e1b8ac95ea225e71d42','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 22:01:08',NULL),('4','1','transaction','46','fis2.png','48fd91e46a2e6b2b2b257f701fa5a4393957f2429b67f113d13d0beb7d000bbc','image/png','70','497790947d4666760ce38f3c00e852c71fdb66cae849bae8e9ede352719e1581','2','2026-10-19 22:01:32',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `entries`;
/*FBEND*/
CREATE TABLE `entries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `kind` enum('receivable','payable') NOT NULL,
  `source` enum('manual','invoice','personal_bill','recurring','milestone') NOT NULL DEFAULT 'manual',
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `recurring_id` bigint(20) unsigned DEFAULT NULL,
  `group_id` varchar(26) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  `seq_total` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `provider` varchar(120) DEFAULT NULL,
  `period` varchar(20) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `amount_minor` bigint(20) NOT NULL,
  `due_date` date DEFAULT NULL,
  `original_due_date` date DEFAULT NULL,
  `priority` tinyint(4) NOT NULL DEFAULT 2,
  `affects_pl` tinyint(4) NOT NULL DEFAULT 0,
  `status` enum('open','cancelled') NOT NULL DEFAULT 'open',
  `note` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `invoice_key` varchar(40) DEFAULT NULL,
  `planned_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_entry_invoice` (`tenant_id`,`invoice_key`),
  UNIQUE KEY `ux_entry_recur` (`tenant_id`,`recurring_id`,`due_date`),
  KEY `ix_en_t` (`tenant_id`,`status`,`due_date`),
  KEY `ix_en_planned` (`tenant_id`,`status`,`planned_date`),
  CONSTRAINT `fk_en_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `entries` VALUES ('1','1','1','receivable','manual','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Büyük satış',NULL,NULL,'TRY','10000000','2026-10-30','2026-10-30','2','0','open',NULL,'2026-10-19 22:00:34',NULL,NULL,NULL),('2','1','1','payable','manual','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Plan: kira',NULL,NULL,'TRY','500000','2026-11-09','2026-11-09','2','1','open',NULL,'2026-10-19 22:00:35',NULL,NULL,NULL),('3','1','1','payable','recurring',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'Aylık abonelik',NULL,NULL,'TRY','30000','2026-10-23','2026-10-23','2','1','open',NULL,'2026-10-19 22:00:35',NULL,NULL,NULL),('4','1','1','payable','recurring',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'Aylık abonelik',NULL,NULL,'TRY','30000','2026-11-23','2026-11-23','2','1','open',NULL,'2026-10-19 22:00:35',NULL,NULL,NULL),('5','1','1','receivable','invoice','1',NULL,NULL,'1',NULL,NULL,NULL,NULL,'Satış faturası FB-2026-001 — Müşteri A',NULL,NULL,'TRY','120000','2026-11-04','2026-11-04','2','0','open',NULL,'2026-10-19 22:00:35',NULL,'1',NULL),('7','1','1','receivable','manual','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'EUR alacak',NULL,NULL,'EUR','50000','2026-10-25','2026-10-25','2','0','open',NULL,'2026-10-19 22:00:35',NULL,NULL,NULL),('8','1','1','payable','manual','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tedarikçi borcu',NULL,NULL,'TRY','1000000','2026-10-30','2026-10-17','2','0','open',NULL,'2026-10-19 22:00:35',NULL,NULL,NULL),('9','1','2','payable','personal_bill',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Elektrik','Enerjisa','2026-10','TRY','80000','2026-10-20','2026-10-20','2','1','open',NULL,'2026-10-19 22:00:36',NULL,NULL,NULL),('10','1','1','receivable','invoice','1','1',NULL,'3',NULL,NULL,NULL,NULL,'Satış faturası PR-1 — Müşteri A',NULL,NULL,'TRY','1200000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:00:37',NULL,'3',NULL),('11','1','1','payable','invoice','2','1',NULL,'4',NULL,NULL,NULL,NULL,'Alış faturası ALIS-9 — Tedarikçi B',NULL,NULL,'TRY','480000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:00:37',NULL,'4',NULL),('12','1','1','receivable','milestone','1','1',NULL,NULL,NULL,NULL,NULL,NULL,'Santral Kurulumu — Hakediş 2',NULL,NULL,'TRY','2000000','2026-11-19','2026-11-19','2','1','open',NULL,'2026-10-19 22:00:37',NULL,NULL,NULL),('13','1','1','payable','invoice','2',NULL,NULL,'5',NULL,NULL,NULL,NULL,'Alış faturası STK-1 — Tedarikçi B',NULL,NULL,'TRY','120000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:00:37',NULL,'5',NULL),('14','1','1','payable','invoice','2',NULL,NULL,'6',NULL,NULL,NULL,NULL,'Alış faturası T4-1-6d9d — Tedarikçi B',NULL,NULL,'TRY','100000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:02',NULL,'6',NULL),('15','1','1','payable','invoice','2',NULL,NULL,'7',NULL,NULL,NULL,NULL,'Alış faturası T4-2-0f5d — Tedarikçi B',NULL,NULL,'TRY','50000','2026-10-30','2026-10-27','2','0','open',NULL,'2026-10-19 22:01:02',NULL,'7',NULL),('16','1','1','payable','invoice','2',NULL,NULL,'8',NULL,NULL,NULL,NULL,'Alış faturası T4-3-b17e — Tedarikçi B',NULL,NULL,'TRY','50000','2026-12-04','2026-12-04','2','0','open',NULL,'2026-10-19 22:01:02',NULL,'8',NULL),('17','1','1','payable','invoice','2',NULL,NULL,'9',NULL,NULL,NULL,NULL,'Alış faturası T4-5-55bb — Tedarikçi B',NULL,NULL,'TRY','1200000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:02',NULL,'9',NULL),('18','1','1','payable','invoice','2',NULL,NULL,'10',NULL,NULL,NULL,NULL,'Alış faturası T4-6-dde5 — Tedarikçi B',NULL,NULL,'TRY','1000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:03',NULL,'10',NULL),('19','1','1','payable','invoice','2',NULL,NULL,'11',NULL,NULL,NULL,NULL,'Alış faturası T4-7-976b — Tedarikçi B',NULL,NULL,'TRY','1000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:03',NULL,'11',NULL),('20','1','1','payable','invoice','2',NULL,NULL,'12',NULL,NULL,NULL,NULL,'Alış faturası T4-8-43c1 — Tedarikçi B',NULL,NULL,'TRY','6000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:03',NULL,'12',NULL),('21','1','1','payable','invoice','2',NULL,NULL,'13',NULL,NULL,NULL,NULL,'Alış faturası T4-9-cccd — Tedarikçi B',NULL,NULL,'TRY','4500000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:03',NULL,'13',NULL),('22','1','1','receivable','invoice','1',NULL,NULL,'14',NULL,NULL,NULL,NULL,'Satış faturası T4-10-dfcb — Müşteri A',NULL,NULL,'TRY','500000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:04',NULL,'14',NULL),('23','1','1','payable','invoice','2',NULL,NULL,'15',NULL,NULL,NULL,NULL,'Alış faturası T4-STK-1 — Tedarikçi B',NULL,NULL,'TRY','5590000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:04',NULL,'15',NULL),('24','1','1','payable','invoice','2',NULL,NULL,'16',NULL,NULL,NULL,NULL,'Alış faturası T4-STK-2 — Tedarikçi B',NULL,NULL,'TRY','1000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:05',NULL,'16',NULL),('25','1','1','payable','invoice','2',NULL,NULL,'17',NULL,NULL,NULL,NULL,'Alış faturası T4-STK-3 — Tedarikçi B',NULL,NULL,'TRY','4000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:05',NULL,'17',NULL),('26','1','1','payable','invoice','2',NULL,NULL,'19',NULL,NULL,NULL,NULL,'Alış faturası T4-IDEM — Tedarikçi B',NULL,NULL,'TRY','100',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:05',NULL,'19',NULL),('27','1','1','receivable','invoice','1',NULL,NULL,'20',NULL,NULL,NULL,NULL,'Satış faturası T4-S-BZ — Müşteri A',NULL,NULL,'TRY','4500000',NULL,NULL,'2','0','cancelled',NULL,'2026-10-19 22:01:05','2026-10-19 22:01:05','20',NULL),('29','1','1','receivable','invoice','1',NULL,NULL,'22',NULL,NULL,NULL,NULL,'Satış faturası T4-S-NO — Müşteri A',NULL,NULL,'TRY','50000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:06',NULL,'22',NULL),('30','1','1','payable','invoice','2',NULL,NULL,'23',NULL,NULL,NULL,NULL,'Alış faturası T4-SUP-NO — Tedarikçi B',NULL,NULL,'TRY','30000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:06',NULL,'23',NULL),('31','1','1','payable','invoice','2',NULL,NULL,'24',NULL,NULL,NULL,NULL,'Alış faturası T4-11-ffd6 — Tedarikçi B',NULL,NULL,'TRY','2000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:06',NULL,'24',NULL),('33','1','2','payable','personal_bill',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Su',NULL,NULL,'TRY','10000','2026-10-25','2026-10-25','2','1','open',NULL,'2026-10-19 22:01:07',NULL,NULL,NULL),('34','1','1','receivable','invoice','4',NULL,NULL,'25',NULL,NULL,NULL,NULL,'Satış faturası HOME-1 — Avans Müşterisi',NULL,NULL,'TRY','10000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:08',NULL,'25',NULL),('35','1','1','receivable','invoice','5',NULL,NULL,'26',NULL,NULL,NULL,NULL,'Satış faturası HOME-2 — Avans Müşterisi 2',NULL,NULL,'TRY','10000000',NULL,NULL,'2','0','open',NULL,'2026-10-19 22:01:09',NULL,'26','2026-10-20'),('36','1','1','payable','invoice','2',NULL,NULL,'27',NULL,NULL,NULL,NULL,'Alış faturası HOME-P1 — Tedarikçi B',NULL,NULL,'TRY','100000','2026-10-25','2026-10-25','2','0','open',NULL,'2026-10-19 22:01:09',NULL,'27',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `fx_rates`;
/*FBEND*/
CREATE TABLE `fx_rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `currency` char(3) NOT NULL,
  `rate_date` date NOT NULL,
  `rate` decimal(18,8) NOT NULL,
  `source` varchar(30) NOT NULL DEFAULT 'manual',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_fx` (`tenant_id`,`currency`,`rate_date`),
  CONSTRAINT `fk_fx_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `fx_rates` VALUES ('1','1','EUR','2026-10-20','40.50000000','manual'),('2','1','USD','2026-10-20','35.25000000','manual');
/*FBEND*/
DROP TABLE IF EXISTS `idempotency_keys`;
/*FBEND*/
CREATE TABLE `idempotency_keys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `ikey` char(64) NOT NULL,
  `route` varchar(160) NOT NULL,
  `status_code` smallint(6) DEFAULT NULL,
  `response` mediumtext DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_idem` (`tenant_id`,`ikey`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `idempotency_keys` VALUES ('1','1','50346c991863bd4e7314577421d30118ef64222967edb595027a5b60c0c35800','POST /transactions','201','{\"ok\":true,\"id\":17,\"warning\":null}','2026-10-19 22:00:38'),('3','1','892a1ea86ce45dce03a9a21cae9e9239b6d2ba66aae4f8bc5c3fbffa5e912c83','POST /payments','201','{\"ok\":true,\"id\":25,\"allocated_minor\":400000,\"unallocated_minor\":0}','2026-10-19 22:01:02'),('4','1','13187ffa1d21679b3bd41d9322f94d10f77d4bf8f3c08ad4cff5cd5c89bc56a8','POST /payments','201','{\"ok\":true,\"id\":26,\"allocated_minor\":600000,\"unallocated_minor\":0}','2026-10-19 22:01:02'),('6','1','017611807d00d77284716a3d41f94737dcf21580f541415bac49d653936e017a','POST /payments','201','{\"ok\":true,\"id\":27,\"allocated_minor\":1000000,\"unallocated_minor\":2000000}','2026-10-19 22:01:03'),('8','1','d375fcb5c7a560e42b35a70921444fb8be4553d6d4e15522fd5510f0dd0dab2e','POST /payments','201','{\"ok\":true,\"id\":28,\"allocated_minor\":5000000,\"unallocated_minor\":0}','2026-10-19 22:01:03'),('9','1','ef2d06b7eae521f1b4b28fefed34c1507d3a9a314f5abd57c6d21635e7c00d94','POST /payments/27/allocate','200','{\"ok\":true,\"allocated_minor\":3000000,\"unallocated_minor\":0}','2026-10-19 22:01:03'),('10','1','2525f307fb8a54859746180997fe51a4aa20dc0569ff8fb14440d6aae2e5244a','POST /payments','201','{\"ok\":true,\"id\":29,\"allocated_minor\":0,\"unallocated_minor\":10000}','2026-10-19 22:01:04'),('12','1','870b32ed56f78335564325c955af95d604b0bb408598412d7e2606ebde523619','POST /payments','201','{\"ok\":true,\"id\":30,\"allocated_minor\":0,\"unallocated_minor\":7000}','2026-10-19 22:01:04'),('14','1','6c3cb134ea101ab5bac0df30f7ea94112759a45ad5aadd82adfad241d132ec7e','POST /payments','201','{\"ok\":true,\"id\":31,\"allocated_minor\":0,\"unallocated_minor\":7000}','2026-10-19 22:01:04'),('15','1','688dd34178cc67cb1d46dd506065f8dd00b12dcf7910cd0c62dce0c1d037dd84','POST /payments','201','{\"ok\":true,\"id\":32,\"allocated_minor\":500000,\"unallocated_minor\":300000}','2026-10-19 22:01:04'),('22','1','ccdd5e6d272bfc7fe7aa1e3bfbcbde58d1fe8a6869387dcfd3ef2578bfcbc859','POST /invoices','201','{\"ok\":true,\"id\":15,\"warnings\":[],\"new_items\":3}','2026-10-19 22:01:04'),('23','1','576d6d67a4529d37fedc17843343f7f84dce033451433dd6e19a60df8a04fb19','POST /invoices','201','{\"ok\":true,\"id\":19,\"warnings\":[],\"new_items\":1}','2026-10-19 22:01:05'),('25','1','5894ce1f015d1b86a3f500cf8fad0d2d551b6a558fc3b570ef78dd53485a2d61','POST /payments','201','{\"ok\":true,\"id\":33,\"allocated_minor\":50000,\"unallocated_minor\":0}','2026-10-19 22:01:06'),('26','1','d5328f10fdae3b5ef0a281ea88c6ba1420d0306229064c0abeaa3065b348856b','POST /invoices/22/deliver','200','{\"ok\":true,\"delivery\":{\"state\":\"partial\",\"tracked_milli\":5000,\"fulfilled_milli\":2000,\"pending_milli\":3000}}','2026-10-19 22:01:06'),('28','1','77256d78a7f6e547cacb165734c1c8a2418a463d59c0f62a7c531f08d88a5e90','POST /payments','201','{\"ok\":true,\"id\":34,\"allocated_minor\":2000000,\"unallocated_minor\":0}','2026-10-19 22:01:06'),('29','1','8d72b228720e05131256dcc80dd27be8d73ad6f190a495fb6b78335d3e38c4dd','POST /transfers','201','{\"ok\":true,\"group\":\"17911928cfdcd0bef2f875d92d\",\"ids\":[35,36]}','2026-10-19 22:01:07'),('31','1','9319e575b46caeb5aba715380f247fd36a3cdcb9a1f620e195b0f8835c603bd3','POST /transfers','201','{\"ok\":true,\"group\":\"fab92ee8f8b66fbc2e7350a4d5\",\"ids\":[37,38]}','2026-10-19 22:01:07'),('32','1','3b2101f6368092ed06bcddf72960e63e35acaa88076c5804c8e576efcfe51bc8','POST /transfers','201','{\"ok\":true,\"group\":\"79d48162b95819a7c9662a39d3\",\"ids\":[39,40]}','2026-10-19 22:01:07'),('33','1','37ade4237fde108f304ae78bdba7e60b040fca58cd65926aa23fc19240a760da','POST /entries/33/settle','201','{\"ok\":true,\"id\":41,\"remaining_minor\":6000}','2026-10-19 22:01:07'),('37','1','1b30ad559e8106f05be8c46242b9d5ac4dc3566741033686f7b29771e9fdd9d0','POST /payments','201','{\"ok\":true,\"id\":42,\"allocated_minor\":3000000,\"unallocated_minor\":0}','2026-10-19 22:01:08'),('38','1','bfb9a9bce722b4fe04b56f4e7633ece191db50d08005a2b3df11fc3f35cec9a4','POST /transactions','201','{\"ok\":true,\"id\":43,\"warning\":\"Tutar müşteri avansı olarak cari hesaba işlendi (gelir sayılmadı; fatura ile eşleştirebilirsiniz).\"}','2026-10-19 22:01:09'),('39','1','bad597bde5c68440cffb80de7e50153727d5655688f809b2e58aa28e0cdba4e9','POST /transactions','201','{\"ok\":true,\"id\":44,\"warning\":null}','2026-10-19 22:01:09'),('40','1','30f75d30c011b51c6e425f24304aa617c9d63218581bf367d9d91d0e9bff0fad','POST /transactions','201','{\"ok\":true,\"id\":45,\"warning\":null}','2026-10-19 22:01:09'),('41','1','baaafa4ce70babc738629a0d444316ca0ee77b45e379fa0dd7a0109d83a71469','POST /payments/43/allocate','200','{\"ok\":true,\"allocated_minor\":3000000,\"unallocated_minor\":0}','2026-10-19 22:01:09'),('42','1','72584e5234f907af7b0b08faae85456a3337e0b89f2a01510e22da681edde0ca','POST /payments','201','{\"ok\":true,\"id\":46,\"allocated_minor\":7000000,\"unallocated_minor\":0}','2026-10-19 22:01:09');
/*FBEND*/
DROP TABLE IF EXISTS `invoice_lines`;
/*FBEND*/
CREATE TABLE `invoice_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `invoice_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `description` varchar(300) NOT NULL,
  `item_id` bigint(20) unsigned DEFAULT NULL,
  `warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `qty_milli` bigint(20) NOT NULL,
  `unit` varchar(20) NOT NULL DEFAULT 'adet',
  `unit_price_minor` bigint(20) NOT NULL,
  `discount_bp` int(11) NOT NULL DEFAULT 0,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `net_minor` bigint(20) NOT NULL,
  `vat_minor` bigint(20) NOT NULL,
  `total_minor` bigint(20) NOT NULL,
  `fulfilled_milli` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_il_inv` (`invoice_id`),
  CONSTRAINT `fk_il_inv` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `invoice_lines` VALUES ('1','1','1','1','Danışmanlık',NULL,NULL,'1000','adet','100000','0','2000','100000','20000','120000','0'),('2','1','3','1','Hakediş 1',NULL,NULL,'1000','adet','1000000','0','2000','1000000','200000','1200000','0'),('3','1','4','1','Malzeme',NULL,NULL,'1000','adet','400000','0','2000','400000','80000','480000','0'),('4','1','5','1','Kablo','1','1','10000','adet','10000','0','2000','100000','20000','120000','10000'),('5','1','6','1','Kalem',NULL,NULL,'1000','adet','100000','0','0','100000','0','100000','0'),('6','1','7','1','Kalem',NULL,NULL,'1000','adet','50000','0','0','50000','0','50000','0'),('7','1','8','1','Kalem',NULL,NULL,'1000','adet','50000','0','0','50000','0','50000','0'),('8','1','9','1','Kalem (düzeltilmiş)',NULL,NULL,'1000','adet','1200000','0','0','1200000','0','1200000','0'),('9','1','10','1','Kalem',NULL,NULL,'1000','adet','1000000','0','0','1000000','0','1000000','0'),('10','1','11','1','Kalem',NULL,NULL,'1000','adet','1000000','0','0','1000000','0','1000000','0'),('11','1','12','1','Kalem',NULL,NULL,'1000','adet','6000000','0','0','6000000','0','6000000','0'),('12','1','13','1','Kalem',NULL,NULL,'1000','adet','4500000','0','0','4500000','0','4500000','0'),('13','1','14','1','Kalem',NULL,NULL,'1000','adet','500000','0','0','500000','0','500000','0'),('14','1','15','1','Buzdolabı T4','2','1','3000','adet','1000000','0','2000','3000000','600000','3600000','3000'),('15','1','15','2','Televizyon T4','3','1','2000','adet','800000','0','2000','1600000','320000','1920000','2000'),('16','1','15','3','Nakliye T4','4',NULL,'1000','adet','50000','0','2000','50000','10000','60000','0'),('17','1','15','4','Serbest not satırı',NULL,NULL,'1000','adet','10000','0','0','10000','0','10000','0'),('18','1','16','1','buzdolabı t4','2','1','1000','adet','1000000','0','0','1000000','0','1000000','1000'),('19','1','17','1','Stoksuz giriş','5',NULL,'4000','adet','1000','0','0','4000','0','4000','0'),('20','1','19','1','Idem','7','1','1000','adet','100','0','0','100','0','100','1000'),('21','1','20','1','Buzdolabı satış','2','1','3000','adet','1500000','0','0','4500000','0','4500000','3000'),('23','1','22','1','Stoksuz','9','1','5000','adet','10000','0','0','50000','0','50000','2000'),('24','1','23','1','Stoksuz tedarik','9','1','5000','adet','6000','0','0','30000','0','30000','5000'),('25','1','24','1','Kalem',NULL,NULL,'1000','adet','2000000','0','0','2000000','0','2000000','0'),('26','1','25','1','İş',NULL,NULL,'1000','adet','10000000','0','0','10000000','0','10000000','0'),('27','1','26','1','İş',NULL,NULL,'1000','adet','10000000','0','0','10000000','0','10000000','0'),('28','1','27','1','Mal',NULL,NULL,'1000','adet','100000','0','0','100000','0','100000','0');
/*FBEND*/
DROP TABLE IF EXISTS `invoices`;
/*FBEND*/
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `kind` enum('sales','purchase') NOT NULL,
  `number` varchar(60) DEFAULT NULL,
  `contact_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `issue_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `status` enum('planned','issued','cancelled') NOT NULL DEFAULT 'issued',
  `subtotal_minor` bigint(20) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `total_minor` bigint(20) NOT NULL DEFAULT 0,
  `note` text DEFAULT NULL,
  `cancel_reason` varchar(300) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `dedupe_key` varchar(300) DEFAULT NULL,
  `defer_delivery` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_inv_dedupe` (`tenant_id`,`dedupe_key`),
  KEY `ix_inv_t` (`tenant_id`,`issue_date`),
  CONSTRAINT `fk_inv_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `invoices` VALUES ('1','1','1','sales','FB-2026-001','1',NULL,'2026-10-20','2026-11-04','TRY','issued','100000','20000','120000',NULL,NULL,NULL,'2','2026-10-19 22:00:35','a754d2aa8eeed97efccef5a323ae68f9e6c145b8a336eb2712976e6d4c2d2240','0'),('3','1','1','sales','PR-1','1','1','2026-10-20',NULL,'TRY','issued','1000000','200000','1200000',NULL,NULL,NULL,'2','2026-10-19 22:00:37','b8bc46e741c40ec3b74a4651c8dd1fa976d82fbcf0a1be20c7c81f4972a509ad','0'),('4','1','1','purchase','ALIS-9','2','1','2026-10-20',NULL,'TRY','issued','400000','80000','480000',NULL,NULL,NULL,'2','2026-10-19 22:00:37','7e15c3cdf198254634085553a61d00d96f61631d5e3c9d5ebf1177cfcda79456','0'),('5','1','1','purchase','STK-1','2',NULL,'2026-10-20',NULL,'TRY','issued','100000','20000','120000',NULL,NULL,NULL,'2','2026-10-19 22:00:37','f9a2c7eab1de39765fe12024afa7c15639f12f15ebebef3f0f3282fa95242c94','0'),('6','1','1','purchase','T4-1-6d9d','2',NULL,'2026-08-21',NULL,'TRY','issued','100000','0','100000',NULL,NULL,NULL,'2','2026-10-19 22:01:02','955b40dd9c1ae77eca66cbf55775bb1dc2253362a14392741e2f6f6ea7a6c505','0'),('7','1','1','purchase','T4-2-0f5d','2',NULL,'2026-10-20',NULL,'TRY','issued','50000','0','50000','sadece not',NULL,NULL,'2','2026-10-19 22:01:02','06f11f26834b7dd4f6e509cf2e07469f55cb289a14f71cae0593256db601e10d','0'),('8','1','1','purchase','T4-3-b17e','2',NULL,'2026-10-20','2026-12-04','TRY','issued','50000','0','50000',NULL,NULL,NULL,'2','2026-10-19 22:01:02','3d2c4eb4582b2845412c9f44c2957d6aece2bde9f49844c3edc6c3da163cb63b','0'),('9','1','1','purchase','T4-5-55bb','2',NULL,'2026-10-20',NULL,'TRY','issued','1200000','0','1200000',NULL,NULL,NULL,'2','2026-10-19 22:01:02','9d0d0c17ecf68e408428d39e97b5aa8b469ac6a56e9ce36dc19564f8edb861dd','0'),('10','1','1','purchase','T4-6-dde5','2',NULL,'2026-10-20',NULL,'TRY','issued','1000000','0','1000000',NULL,NULL,NULL,'2','2026-10-19 22:01:03','9057c16d390083d6cb98a3bf778a8b19fb62c8b078e4baf271f7ceb2cd3c5e03','0'),('11','1','1','purchase','T4-7-976b','2',NULL,'2026-10-20',NULL,'TRY','issued','1000000','0','1000000',NULL,NULL,NULL,'2','2026-10-19 22:01:03','e520baa7056872c9b811711f5f78c430ee144f0f4c36e71dd8df9a7272806a0b','0'),('12','1','1','purchase','T4-8-43c1','2',NULL,'2026-10-20',NULL,'TRY','issued','6000000','0','6000000',NULL,NULL,NULL,'2','2026-10-19 22:01:03','f5b313e8188b41e33b5d2ab9c1cd92400bf2fc737135a3df0567f6df0100de74','0'),('13','1','1','purchase','T4-9-cccd','2',NULL,'2026-10-20',NULL,'TRY','issued','4500000','0','4500000',NULL,NULL,NULL,'2','2026-10-19 22:01:03','ba76bf79b2874f06a3cf755e19fbe7b7116e3977fc7264c5716ebface8214197','0'),('14','1','1','sales','T4-10-dfcb','1',NULL,'2026-10-20',NULL,'TRY','issued','500000','0','500000',NULL,NULL,NULL,'2','2026-10-19 22:01:04','297dd6430bf4f64ba6bc90eaa7e4ddf05c825d1d7a538648884b99faf2e3f4d2','0'),('15','1','1','purchase','T4-STK-1','2',NULL,'2026-10-20',NULL,'TRY','issued','4660000','930000','5590000',NULL,NULL,NULL,'2','2026-10-19 22:01:04','e1ac5254b542481ebc8036b673ec23d57ec477cd765925e8a5581e79aa80aa51','0'),('16','1','1','purchase','T4-STK-2','2',NULL,'2026-10-20',NULL,'TRY','issued','1000000','0','1000000',NULL,NULL,NULL,'2','2026-10-19 22:01:05','c6744dea9981945fc0f907bffe09b2086d250fc7ef48f1c5ee7e3109e50ea926','0'),('17','1','1','purchase','T4-STK-3','2',NULL,'2026-10-20',NULL,'TRY','issued','4000','0','4000',NULL,NULL,NULL,'2','2026-10-19 22:01:05','ce05d1a80529a7c8550e2e6e342f17d7f3106eaeff60605ab0dc05c37537db37','0'),('19','1','1','purchase','T4-IDEM','2',NULL,'2026-10-20',NULL,'TRY','issued','100','0','100',NULL,NULL,NULL,'2','2026-10-19 22:01:05','a14dbf3ccf5544863fd18803b9b6543230df5f719b52e2ad5d546e37c2668f53','0'),('20','1','1','sales','T4-S-BZ','1',NULL,'2026-10-20',NULL,'TRY','cancelled','4500000','0','4500000',NULL,'müşteri vazgeçti','2026-10-19 22:01:05','2','2026-10-19 22:01:05','b846f7f8969fec18addb81f07e3380439c716b190f0c93696bced8118bbd4026','0'),('22','1','1','sales','T4-S-NO','1',NULL,'2026-10-20',NULL,'TRY','issued','50000','0','50000',NULL,NULL,NULL,'2','2026-10-19 22:01:06','bdf6d8bde42d0bde5010b566f66755e61b64925556c291ec3a003d471838c04f','0'),('23','1','1','purchase','T4-SUP-NO','2',NULL,'2026-10-20',NULL,'TRY','issued','30000','0','30000',NULL,NULL,NULL,'2','2026-10-19 22:01:06','f37b2b06e1d61b54548261d81dc7b53d8f379fc6cd554fd54ffb2a94cb67e5f1','0'),('24','1','1','purchase','T4-11-ffd6','2',NULL,'2026-10-20',NULL,'TRY','issued','2000000','0','2000000',NULL,NULL,NULL,'2','2026-10-19 22:01:06','5444f41ebd4854f55b8a7ade602e5849a5644c8c0ba2a18ece2b863ca9f822f0','0'),('25','1','1','sales','HOME-1','4',NULL,'2026-10-20',NULL,'TRY','issued','10000000','0','10000000',NULL,NULL,NULL,'2','2026-10-19 22:01:08','802eaa9e5dec5bf3741d41a35f84fffb8c6fbf524c2d54c7e56482152f9fb06c','0'),('26','1','1','sales','HOME-2','5',NULL,'2026-10-20',NULL,'TRY','issued','10000000','0','10000000',NULL,NULL,NULL,'2','2026-10-19 22:01:09','2db1d2e1d0f25daa74f8343e8ab5fda6a283cf10c7081cea0187863d9aaf59fb','0'),('27','1','1','purchase','HOME-P1','2',NULL,'2026-10-20','2026-10-25','TRY','issued','100000','0','100000',NULL,NULL,NULL,'2','2026-10-19 22:01:09','eecb2094c884fea81c14757a257954083fcd315a0df08288073dc5e2af4e1253','0');
/*FBEND*/
DROP TABLE IF EXISTS `loan_installments`;
/*FBEND*/
CREATE TABLE `loan_installments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `loan_id` bigint(20) unsigned NOT NULL,
  `seq` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `principal_minor` bigint(20) NOT NULL,
  `interest_minor` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_li_t` (`tenant_id`,`loan_id`),
  KEY `fk_li_l` (`loan_id`),
  CONSTRAINT `fk_li_l` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `loan_installments` VALUES ('1','1','1','1','2026-11-20','894715','240000'),('2','1','1','2','2026-12-20','912609','222106'),('3','1','1','3','2027-01-20','930861','203854'),('4','1','1','4','2027-02-20','949479','185236'),('5','1','1','5','2027-03-20','968468','166247'),('6','1','1','6','2027-04-20','987838','146877'),('7','1','1','7','2027-05-20','1007594','127121'),('8','1','1','8','2027-06-20','1027746','106969'),('9','1','1','9','2027-07-20','1048301','86414'),('10','1','1','10','2027-08-20','1069267','65448'),('11','1','1','11','2027-09-20','1090653','44062'),('12','1','1','12','2027-10-20','1112469','22249');
/*FBEND*/
DROP TABLE IF EXISTS `loans`;
/*FBEND*/
CREATE TABLE `loans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `bank_name` varchar(120) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `principal_minor` bigint(20) NOT NULL,
  `monthly_rate_bp` int(11) NOT NULL DEFAULT 0,
  `term_months` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `status` enum('active','closed','cancelled') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ln_t` (`tenant_id`),
  CONSTRAINT `fk_ln_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `loans` VALUES ('1','1','1','İşletme Kredisi',NULL,'TRY','12000000','200','12','2026-10-20','active','2026-10-19 22:00:36');
/*FBEND*/
DROP TABLE IF EXISTS `login_tickets`;
/*FBEND*/
CREATE TABLE `login_tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `token_hash` char(64) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `ip` varchar(64) NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_tickets_token` (`token_hash`),
  KEY `fk_tickets_user` (`user_id`),
  CONSTRAINT `fk_tickets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `login_tickets` VALUES ('1','b90da23e44184125345b361388c9abe803f58ee034806165e7368be81755902f','1','127.0.0.1','1','2026-10-19 22:03:04',NULL),('2','2038a9a2d50f54798f0f4b039d1edccd5dd7b67cb2aee5beb0288942815875cb','1','127.0.0.1','1','2026-10-19 22:03:04','2026-10-19 21:58:04'),('3','7b9fa029eae82e8758e0d1bdf6df19d7d2a9dd55b25e80d5b00bf3aa7872f30b','1','127.0.0.1','1','2026-10-19 22:03:08','2026-10-19 21:58:32'),('4','b3944772f8b688b8ca74c6021c35ebcef99d733b7695e40bb1098f0477c2a7ff','1','127.0.0.1','1','2026-10-19 22:03:32','2026-10-19 21:59:02'),('5','8605059f4270b5dd8d8af69e9c749051f5fc4ea1010b52aa2c2648e1e4dfe09c','1','127.0.0.1','0','2026-10-19 22:04:02',NULL),('6','57645ce88c283177a95316922eb5ceca2819d276da4e46fc98ab52319ceb136d','1','127.0.0.1','1','2026-10-19 22:04:02','2026-10-19 21:59:32'),('7','d4a3a16db171586a48370efdd498162bab256d682a41238d98204f891081c14e','1','127.0.0.1','1','2026-10-19 22:04:33','2026-10-19 22:00:00'),('8','cb5dad984129e4ad4cf2d8753338ce7d14a2d7da43d324b488ce000f7cdd0ae6','1','127.0.0.1','1','2026-10-19 22:05:00','2026-10-19 22:00:30'),('9','c0b8d5a50aa3a4a51945d68eb1ac0e35546eafb37679e16503c69585a59685d3','1','127.0.0.1','1','2026-10-19 22:05:40','2026-10-19 22:01:01'),('10','92bd274250455d5fc4e513a96d2440323942d128bcd270470e8588abff5c858f','1','127.0.0.1','1','2026-10-19 22:06:10','2026-10-19 22:01:31');
/*FBEND*/
DROP TABLE IF EXISTS `password_tokens`;
/*FBEND*/
CREATE TABLE `password_tokens` (
  `token_hash` char(64) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `purpose` enum('reset','invite') NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`token_hash`),
  KEY `ix_pt_user` (`user_id`),
  CONSTRAINT `fk_pt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `password_tokens` VALUES ('64e1370b1172ead27b1989c22e9d98320ea41a35f8e0653dd82223702dabcc72','2','reset','2026-10-19 22:30:32','2026-10-19 22:00:33',NULL,'2026-10-19 22:00:32'),('cad7b85d95d2a680b2c7c50f13e9c51e4cf44847540adf38f82650347f25c94f','2','invite','2026-10-22 22:00:30','2026-10-19 22:00:31','1','2026-10-19 22:00:30');
/*FBEND*/
DROP TABLE IF EXISTS `payment_allocations`;
/*FBEND*/
CREATE TABLE `payment_allocations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `txn_id` bigint(20) unsigned NOT NULL,
  `entry_id` bigint(20) unsigned NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `status` enum('active','reversed') NOT NULL DEFAULT 'active',
  `note` varchar(300) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `reversed_at` datetime DEFAULT NULL,
  `reversed_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_pa_txn` (`tenant_id`,`txn_id`,`status`),
  KEY `ix_pa_entry` (`tenant_id`,`entry_id`,`status`),
  KEY `fk_pa_txn` (`txn_id`),
  KEY `fk_pa_entry` (`entry_id`),
  CONSTRAINT `fk_pa_entry` FOREIGN KEY (`entry_id`) REFERENCES `entries` (`id`),
  CONSTRAINT `fk_pa_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`),
  CONSTRAINT `fk_pa_txn` FOREIGN KEY (`txn_id`) REFERENCES `transactions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `payment_allocations` VALUES ('1','1','1','1','6000000','active',NULL,'2','2026-10-19 22:00:34',NULL,NULL),('2','1','2','1','4000000','active',NULL,'2','2026-10-19 22:00:34',NULL,NULL),('3','1','5','5','120000','active',NULL,'2','2026-10-19 22:00:35',NULL,NULL),('4','1','9','8','300000','active',NULL,'2','2026-10-19 22:00:35',NULL,NULL),('5','1','14','10','1200000','active',NULL,'2','2026-10-19 22:00:37',NULL,NULL),('6','1','15','11','480000','active',NULL,'2','2026-10-19 22:00:37',NULL,NULL),('7','1','25','17','400000','active',NULL,'2','2026-10-19 22:01:02',NULL,NULL),('8','1','26','17','600000','active',NULL,'2','2026-10-19 22:01:02',NULL,NULL),('9','1','27','18','1000000','reversed',NULL,'2','2026-10-19 22:01:03','2026-10-19 22:01:03','2'),('10','1','28','19','1000000','active',NULL,'2','2026-10-19 22:01:03',NULL,NULL),('11','1','28','20','4000000','active',NULL,'2','2026-10-19 22:01:03',NULL,NULL),('12','1','27','21','2000000','reversed',NULL,'2','2026-10-19 22:01:03','2026-10-19 22:01:03','2'),('13','1','27','20','1500000','active',NULL,'2','2026-10-19 22:01:03',NULL,NULL),('14','1','27','21','500000','active',NULL,'2','2026-10-19 22:01:03',NULL,NULL),('15','1','32','22','500000','active',NULL,'2','2026-10-19 22:01:04',NULL,NULL),('16','1','33','29','50000','active',NULL,'2','2026-10-19 22:01:06',NULL,NULL),('17','1','34','31','2000000','active',NULL,'2','2026-10-19 22:01:06',NULL,NULL),('18','1','41','33','4000','active',NULL,'2','2026-10-19 22:01:07',NULL,NULL),('19','1','42','34','3000000','active',NULL,'2','2026-10-19 22:01:08',NULL,NULL),('20','1','43','35','3000000','active',NULL,'2','2026-10-19 22:01:09',NULL,NULL),('21','1','46','35','7000000','active',NULL,'2','2026-10-19 22:01:09',NULL,NULL);
/*FBEND*/
DROP TABLE IF EXISTS `project_milestones`;
/*FBEND*/
CREATE TABLE `project_milestones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `due_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `entry_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pm_t` (`tenant_id`),
  CONSTRAINT `fk_pm_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `project_milestones` VALUES ('1','1','1','Hakediş 2','2026-11-19','2000000','12','2026-10-19 22:00:37');
/*FBEND*/
DROP TABLE IF EXISTS `project_quotes`;
/*FBEND*/
CREATE TABLE `project_quotes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned NOT NULL,
  `kind` enum('quote','order') NOT NULL DEFAULT 'quote',
  `number` varchar(60) DEFAULT NULL,
  `quote_date` date NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `status` enum('draft','sent','accepted','rejected') NOT NULL DEFAULT 'draft',
  `note` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pq_t` (`tenant_id`),
  CONSTRAINT `fk_pq_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
DROP TABLE IF EXISTS `projects`;
/*FBEND*/
CREATE TABLE `projects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(160) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `contract_minor` bigint(20) NOT NULL DEFAULT 0,
  `est_cost_minor` bigint(20) NOT NULL DEFAULT 0,
  `status` enum('planned','active','done','cancelled') NOT NULL DEFAULT 'active',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_pr_t` (`tenant_id`),
  CONSTRAINT `fk_pr_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `projects` VALUES ('1','1','1','1','Santral Kurulumu','TRY','5000000','3000000','active',NULL,NULL,NULL,'0','2026-10-19 22:00:37');
/*FBEND*/
DROP TABLE IF EXISTS `rate_limits`;
/*FBEND*/
CREATE TABLE `rate_limits` (
  `k` varchar(120) NOT NULL,
  `hits` int(11) NOT NULL,
  `window_start` datetime NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `rate_limits` VALUES ('2fa_enable:1','2','2026-10-19 21:58:04'),('2fa_ip:127.0.0.1','9','2026-10-19 21:58:04'),('adm_acc:1:1:accounts','1','2026-10-19 22:01:01'),('adm_acc:1:1:reports','1','2026-10-19 22:01:01'),('adm_acc:1:1:transactions','1','2026-10-19 22:01:01'),('api_ip:127.0.0.1','555','2026-10-19 22:00:33'),('api_user:1','4','2026-10-19 22:01:32'),('api_user:2','10','2026-10-19 22:01:32'),('api_user:3','38','2026-10-19 22:00:31'),('captcha_ip:127.0.0.1','40','2026-10-19 21:58:04'),('forgot_id:10b002daf7d0d7bb6ce4ddb1eace6e6ea8797dc2ae8eac370896018434fdc32b','1','2026-10-19 22:00:32'),('forgot_id:9d158211d6d187975b6ea8731d701836746c45264805fb516c4b825d77575a12','1','2026-10-19 22:00:32'),('forgot_ip:127.0.0.1','2','2026-10-19 22:00:32'),('honeypot:127.0.0.1','1','2026-10-19 22:00:30'),('login_id:2adbc0b959b6cefa8a28619eba9556a8b3e989948da312fdc252299441054066','11','2026-10-19 21:58:04'),('login_id:9d158211d6d187975b6ea8731d701836746c45264805fb516c4b825d77575a12','15','2026-10-19 22:00:31'),('login_id:bf7af099680062112c03af6bf21788199efd3be7eb5577030428c546327e2d13','1','2026-10-19 22:00:30'),('login_id:d3206c76a6d95265cea4f2b55e315c420f7dadad3198cdfba7831a080179d026','7','2026-10-19 22:00:31'),('login_ip:127.0.0.1','40','2026-10-19 21:58:04'),('pwchange:3','4','2026-10-19 22:00:31'),('reset_ip:127.0.0.1','4','2026-10-19 22:00:31');
/*FBEND*/
DROP TABLE IF EXISTS `recurring_templates`;
/*FBEND*/
CREATE TABLE `recurring_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `entry_kind` enum('receivable','payable') NOT NULL,
  `title` varchar(200) NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `frequency` enum('weekly','monthly','yearly') NOT NULL DEFAULT 'monthly',
  `next_date` date NOT NULL,
  `anchor_day` tinyint(4) NOT NULL DEFAULT 1,
  `end_date` date DEFAULT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `last_generated` date DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_rt_t` (`tenant_id`),
  CONSTRAINT `fk_rt_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `recurring_templates` VALUES ('1','1','1','payable','Aylık abonelik','30000','TRY',NULL,NULL,'monthly','2026-12-23','23',NULL,'1','2026-10-20','2026-10-19 22:00:35');
/*FBEND*/
DROP TABLE IF EXISTS `schema_migrations`;
/*FBEND*/
CREATE TABLE `schema_migrations` (
  `version` varchar(100) NOT NULL,
  `checksum` char(64) NOT NULL,
  `applied_at` datetime NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*FBEND*/
INSERT INTO `schema_migrations` VALUES ('001_core','2d7a0f529b8d465b588d781044a60d9cb4baf28da2486cf3fea7a419c77b2087','2026-10-19 21:58:03'),('002_finance','280896f0df01ee75f67ba9f9195332cffca21c8e6a49a5c4c3626a6abd726ced','2026-10-19 21:58:03'),('003_payments_allocations','64f57c10b2fca0825123cf9bfe36db39250c1789b8cf7b2c1a1c8eef9a37b87c','2026-10-19 21:58:03'),('004_planned_dates','d7b59bc0ce7bd1a5010ac728fe803eb2ad31bf0d17355987959945fbfdf62ccb','2026-10-19 21:58:03');
/*FBEND*/
DROP TABLE IF EXISTS `sessions`;
/*FBEND*/
CREATE TABLE `sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `token_hash` char(64) NOT NULL,
  `prev_token_hash` char(64) DEFAULT NULL,
  `prev_valid_until` datetime DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `epoch` int(11) NOT NULL,
  `csrf_secret` char(64) NOT NULL,
  `ip` varchar(64) NOT NULL,
  `ua_hash` char(64) NOT NULL,
  `label` varchar(160) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `last_seen_at` datetime NOT NULL,
  `rotated_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `revoked_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sessions_token` (`token_hash`),
  KEY `ix_sessions_prev` (`prev_token_hash`),
  KEY `ix_sessions_user` (`user_id`),
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `sessions` VALUES ('1','1fdbf499d8767f8f34336737b293b2ccaa939000bfdea9d78c7308c4d31c4eff',NULL,'2026-10-19 21:58:03','1','2','2594f093580ccf20a877d799f3ffcafad5a24c1f3c17c925fdf4ba783183ab64','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:58:04','2026-10-19 21:58:04','2026-10-19 21:58:04','2026-10-20 09:58:04',NULL),('2','0fa652b974ff2558310279eec8bc08391865c63dc6df9f8775dcc7a1b9e824ce','4c5b2ea5aab3b17d8a4945fc31a024a8b4781117325a66aa8a2a64bd2bc65ab6','2026-10-19 21:58:03','1','2','9547250dd73ea45dd53999db3a172a86dd9b8090eae758d9337af45f749ea4b8','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:58:04','2026-10-19 21:58:08','2026-10-19 21:58:08','2026-10-20 09:58:04',NULL),('3','5ebaa4e15944eb906f86e124b00551fd0db5472168ca924e4107400dce800b6c',NULL,NULL,'1','2','8bb4c38f9efab2f1f403bf90478c4b55a0e04501bdd2ea857019b5b0c93d04fb','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:58:32','2026-10-19 21:58:32','2026-10-19 21:58:32','2026-10-20 09:58:32',NULL),('4','6171baa3edb69012ab8b58967c5b277a6014120d497eea932984595f17307119',NULL,NULL,'1','2','fb1225e1bc424ad94f22326126232426aaa912f98ed91633bda83b1e4ab5b15f','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:59:02','2026-10-19 21:59:02','2026-10-19 21:59:02','2026-10-20 09:59:02','2026-10-19 21:59:02'),('5','0f28f5d99926d561b6428b4a9f63bc79d85881fdb94a3918ab5915378bc6f480',NULL,NULL,'1','2','444c352e6bdc3fd60dc0b50d118f4042f85f9325819b6c3ee82b6c820291dfd8','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 21:59:32','2026-10-19 21:59:32','2026-10-19 21:59:32','2026-10-20 09:59:32',NULL),('6','3a57fe59e59b474e3b5d1fc32bf5339c213207c79792774d5a03da8d33f6cf3d',NULL,NULL,'1','2','97773c444bf6594936b0b2837cb7d607b9c8ce1252154c2bbfb3b963d2a90cf7','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:00','2026-10-19 22:00:00','2026-10-19 22:00:00','2026-10-20 10:00:00',NULL),('7','bee1028dd34f3b285d54e7b49245ac11db15705968e7d26e434638f6c2d147a3','15b0c199288c6b03fc2a4706f2013c5ba579435a537bc202b0bcbad1d0ddf7e1','2026-10-19 22:01:33','1','2','0982b3a05c5942f1a148929cd98180c3b0e3a77fa9d92c4b2153cbb540e92fdf','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:30','2026-10-19 22:00:33','2026-10-19 22:00:33','2026-10-20 10:00:30',NULL),('8','d34d829d2d3e51e545bc2564717f9ed2299e7da3427317d13e579a0cca450a24',NULL,NULL,'3','1','0b4b1e574ac5730e3c076de124a8416772de39ea3c9779e3900bfcf7493f2319','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:31','2026-10-19 22:00:31','2026-10-19 22:00:31','2026-10-20 10:00:31','2026-10-19 22:00:31'),('9','ef7692756bf24610c631f42aa9d905f2dfef4f424e40a7c31b47005c2c2f0719',NULL,NULL,'3','2','fb8626a3d0fa64d21c8917f7e966816966f4970ccd587fe677e00a1e1c8357a1','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:31','2026-10-19 22:00:31','2026-10-19 22:00:31','2026-10-20 10:00:31','2026-10-19 22:00:33'),('10','c50bbc34027e53452fd76a8f8f850405e70d951fa93e57d4077c48d07a20063d',NULL,NULL,'2','2','baa51e2a4d257001f59b1957e9bdb43510984ba0fadb3a77949b7b6d47ffa50b','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:31','2026-10-19 22:00:31','2026-10-19 22:00:31','2026-10-20 10:00:31','2026-10-19 22:00:31'),('11','f6672866470aaeb5e3d4935bf7ab421db43a2a50da9cb9c2f86c56c37047edf9',NULL,NULL,'2','2','e3863760718a92278d2d8b38d58ce7a878d99e7e4e28a2cea9ca1c1c1ec5662c','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:31','2026-10-19 22:00:31','2026-10-19 22:00:31','2026-10-20 10:00:31','2026-10-19 22:00:33'),('12','083a62b81a67c7d62d44cf79bd0bd98017b7960168c5ec4b51f532a0a3c8126b',NULL,NULL,'2','2','256e94c1b6a0e0ef35be3fc51b64a8808ddd9479a24b7a1ac9cb678d04764d0c','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:32','2026-10-19 22:00:32','2026-10-19 22:00:32','2026-10-20 10:00:32','2026-10-19 22:00:33'),('13','40fe2576fe7d2efe150300b50f0e7e83c6d9d1893e8d6d8e19a8aeacb705bb98',NULL,NULL,'2','2','9f4f1aa0d5a73c1db8f8417f9711e245918190709619789fc9f8258ca3ca66de','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:33','2026-10-19 22:00:33','2026-10-19 22:00:33','2026-10-20 10:00:33','2026-10-19 22:00:33'),('14','6b218fe9e87f593ba0c0720e693aa95a6c1bd6b157e1a348216cf84c38793af6',NULL,NULL,'2','3','32daed342427962cc719a0b7cfa3ce30b6c48de9cd9d61151c26f3997c1d688a','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:33','2026-10-19 22:00:33','2026-10-19 22:00:33','2026-10-20 10:00:33','2026-10-19 22:01:01'),('15','b7b35acdb8b2ff34916ad8296876851bd2d94cbedd85eb3f59ca721bdec06e1d',NULL,NULL,'3','2','c883eec245e34e2fee67a635801234442970220b490987286ab6640e9fba33bb','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:33','2026-10-19 22:00:33','2026-10-19 22:00:33','2026-10-20 10:00:33','2026-10-19 22:00:33'),('16','dafecfc62b3b5afe63a6914bdc2877da7f36a6cee3555873b169b8e03f888982',NULL,NULL,'3','3','af0ef5b001c8cd5fbd91c78c83b328a445d2c60228a27e3ff2dfd1f7cfe0d18a','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:33','2026-10-19 22:00:33','2026-10-19 22:00:33','2026-10-20 10:00:33',NULL),('17','fe9c65cad5a2c18954469f56ce7ee5d4ec37a411d310cdf35e1037d2338ebfd6','90645c8f26de3aee2be29330d5d5b4ba90e91c28e4b0e0fd1b2b5aa177fd751b','2026-10-19 22:02:01','2','3','ea4ed1f236018bfea20f5b107575894b1261e1eebe96a8b688fcb70c0c4f94bd','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:33','2026-10-19 22:01:01','2026-10-19 22:01:01','2026-10-20 10:00:33','2026-10-19 22:01:01'),('18','b303a55d8c1a0c944bc4611f24ea83befabdb2de52b6b2d1e143bfac80266ea7','901de8502c4872fa1dde660f057c690d00733c3d7c3f5931bdf81a1bf8cee5a3','2026-10-19 22:01:39','3','3','cdff7aef5b1d2d36d4a272b4b8ac614c3527a097ab1cc55a0a5ad0f581a61e03','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:00:34','2026-10-19 22:00:39','2026-10-19 22:00:39','2026-10-20 10:00:34',NULL),('19','e105e6fbd89b32c0ab233ba74792b27269b7f31cb2e0da2c2fb1e699a00601d8',NULL,NULL,'1','2','b2cd03f2fe3872a7072c340815c0aaf31931898725665d86ce9ef97a5117ff68','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:01:01','2026-10-19 22:01:01','2026-10-19 22:01:01','2026-10-20 10:01:01',NULL),('20','8ac431f0c6a2ddb052b9ec9736cd2a797e90e3fc2b96284a333772e41d3857ca','9c29af1137abb043e81adf1826717172700789a0dc6511f8e6d409b5f5f3d64a','2026-10-19 22:02:08','2','4','bc3cc14e790ca316202851e50503b0a42620e495b00ddf90305648e053908171','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:01:02','2026-10-19 22:01:08','2026-10-19 22:01:08','2026-10-20 10:01:02',NULL),('21','7637ef8e98aad6f5448a1dfd99f7aa3eda64a468b00eba0a3733b6fe6f33f57e','af1bf748e95d2620edd8fcd0c03fd690904ce1e385568684736535559d5a47a4','2026-10-19 22:02:08','3','3','8f99e1ada24b5ced2a0b255c7a497a9e2700b3b92b4a7109c0eafe58af9bf3de','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:01:02','2026-10-19 22:01:08','2026-10-19 22:01:08','2026-10-20 10:01:02',NULL),('22','674bb14d4aeaa8bf6277e80f27f0cae43c101721004ec3de18f6fc06477354b6',NULL,NULL,'2','4','6fcbe68c81a5f58b94dcc6c00696f0ec30730ca9d71e9ab4c5ad66d755886489','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:01:08','2026-10-19 22:01:08','2026-10-19 22:01:08','2026-10-20 10:01:08',NULL),('23','3440938e8c41da016e9cb52449efe00bcca533fbd46b8721f435dd1938243115',NULL,NULL,'3','3','375afb971ba979630621e4b38edc369a080edcca42271a481864775255cf21dd','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:01:08','2026-10-19 22:01:08','2026-10-19 22:01:08','2026-10-20 10:01:08',NULL),('24','a2db04af8a51fb533dc725965633349128ec44f2a6886f332380badc39bde6e0','a949536b5a6eeda2dd09b971ab3a9ac2794404efe5b71cba13ccc52b511498cf','2026-10-19 22:02:31','2','4','5e654d98bd7df5e44f8af25133b4073df0330a704eda3901a1f1e0d74ab331fe','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:01:09','2026-10-19 22:01:31','2026-10-19 22:01:31','2026-10-20 10:01:09',NULL),('25','22fa5767abe3ce2fb5b3c5720fa8d41044bb5770b43197710ec0efd51419abd8',NULL,NULL,'1','2','d42cbee7b0a83df41cb5b190ec39acfc0505f9538eab5cc209a9f675c239024e','127.0.0.1','d48e4e173a18e9c18945b9d94b062f07f5973ef00ed0ebe0ef79bfd6662af800','Tarayıcı / Bilinmeyen','2026-10-19 22:01:31','2026-10-19 22:01:31','2026-10-19 22:01:31','2026-10-20 10:01:31',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `statement_lines`;
/*FBEND*/
CREATE TABLE `statement_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `line_date` date NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `line_hash` char(64) NOT NULL,
  `matched_txn_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('unmatched','matched','ignored') NOT NULL DEFAULT 'unmatched',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sl_hash` (`tenant_id`,`account_id`,`line_hash`),
  CONSTRAINT `fk_sl_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `statement_lines` VALUES ('1','1','1','2026-10-20','POS TAHSILAT','25000','2dd70cd3ad2358a7943c0e8cac8c05d73ae6b21e9d93ef0e63fb60ee1c70cd29','13','matched','2026-10-19 22:00:37'),('2','1','1','2026-10-20','KOMISYON','-500','6ab4bf50d5e6e6224b07dfaa833e7336a0a25f2c620a77c0244f5807239ae01d',NULL,'unmatched','2026-10-19 22:00:37'),('3','1','1','2026-10-20','KOMISYON','-500','982e8957d68f530fe63e2ee3fadbda5c9c4640deb1e8a5a1e1faae6365fca202',NULL,'unmatched','2026-10-19 22:00:37');
/*FBEND*/
DROP TABLE IF EXISTS `stock_items`;
/*FBEND*/
CREATE TABLE `stock_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `kind` enum('product','service') NOT NULL DEFAULT 'product',
  `code` varchar(60) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `unit` varchar(20) NOT NULL DEFAULT 'adet',
  `barcode` varchar(60) DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `sale_price_minor` bigint(20) NOT NULL DEFAULT 0,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 2000,
  `min_qty_milli` bigint(20) NOT NULL DEFAULT 0,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_si_code` (`tenant_id`,`code`),
  CONSTRAINT `fk_si_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `stock_items` VALUES ('1','1','product','KBL-1','Kablo 10m','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:00:37'),('2','1','product','BZD-T4','Buzdolabı T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:01:04'),('3','1','product',NULL,'Televizyon T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:01:04'),('4','1','service',NULL,'Nakliye T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:01:04'),('5','1','product',NULL,'Stoksuz giriş','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:01:05'),('7','1','product','IDM-1','Idem','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:01:05'),('8','1','product','DEL-1','Silinecek','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:01:05'),('9','1','product','NOSTK','Stoksuz Ürün T4','adet',NULL,'TRY','0','2000','0','0','2026-10-19 22:01:06');
/*FBEND*/
DROP TABLE IF EXISTS `stock_movements`;
/*FBEND*/
CREATE TABLE `stock_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `warehouse_id` bigint(20) unsigned NOT NULL,
  `kind` enum('in','out','return_in','return_out') NOT NULL,
  `qty_milli` bigint(20) NOT NULL,
  `unit_cost_minor` bigint(20) NOT NULL DEFAULT 0,
  `move_date` date NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_sm_t` (`tenant_id`,`item_id`),
  KEY `ix_sm_inv` (`invoice_id`),
  CONSTRAINT `fk_sm_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `stock_movements` VALUES ('1','1','1','1','in','10000','10000','2026-10-20',NULL,'5','Alış faturası','posted','2026-10-19 22:00:37'),('2','1','1','1','out','2000','10000','2026-10-20','1',NULL,NULL,'posted','2026-10-19 22:00:37'),('3','1','1','1','out','9000','10000','2026-10-20',NULL,NULL,NULL,'posted','2026-10-19 22:00:37'),('4','1','2','1','in','5000','1000000','2026-10-20',NULL,'15','Alış faturası','posted','2026-10-19 22:01:04'),('5','1','3','1','in','2000','800000','2026-10-20',NULL,'15','Alış faturası','posted','2026-10-19 22:01:04'),('6','1','2','1','in','2000','1000000','2026-10-20',NULL,'15','Alış faturası','posted','2026-10-19 22:01:05'),('7','1','2','1','return_out','4000','1000000','2026-10-20',NULL,'15','Alış faturası (düzeltme)','posted','2026-10-19 22:01:05'),('8','1','2','1','in','1000','1000000','2026-10-20',NULL,'16','Alış faturası','posted','2026-10-19 22:01:05'),('9','1','7','1','in','1000','100','2026-10-20',NULL,'19','Alış faturası','posted','2026-10-19 22:01:05'),('10','1','2','1','out','3000','1000000','2026-10-20',NULL,'20','Satış faturası','voided','2026-10-19 22:01:05'),('12','1','9','1','in','5000','6000','2026-10-20',NULL,'23','Alış faturası','posted','2026-10-19 22:01:06'),('13','1','9','1','out','2000','6000','2026-10-20',NULL,'22','Satış faturası','posted','2026-10-19 22:01:06');
/*FBEND*/
DROP TABLE IF EXISTS `system_settings`;
/*FBEND*/
CREATE TABLE `system_settings` (
  `k` varchar(80) NOT NULL,
  `v` mediumtext DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
DROP TABLE IF EXISTS `tenants`;
/*FBEND*/
CREATE TABLE `tenants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `company_name` varchar(200) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `status` enum('active','suspended','archived') NOT NULL DEFAULT 'active',
  `settings` mediumtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tenants_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `tenants` VALUES ('1','Alfa Ltd','Alfa Ticaret',NULL,'active','{\"locale\":\"tr-TR\",\"theme\":\"dark\",\"date_format\":\"DD.MM.YYYY\",\"default_workspace_id\":null,\"default_account_id\":1,\"vat_rates\":[0,800,1000,2000],\"preferred_currency\":\"TRY\",\"notify\":{\"due\":true,\"overdue\":true,\"card\":true,\"bills\":false,\"email\":false},\"invoice\":{\"prefix\":\"\",\"default_due_days\":30,\"note\":\"\"},\"stock\":{\"allow_negative\":false}}','1','2026-10-19 22:00:30','2026-10-19 22:01:09',NULL),('2','Beta AŞ',NULL,NULL,'active','{\"locale\":\"tr-TR\",\"notify\":{\"due\":true,\"overdue\":true,\"card\":true,\"bills\":true,\"email\":false}}','1','2026-10-19 22:00:31','2026-10-19 22:01:08',NULL);
/*FBEND*/
DROP TABLE IF EXISTS `transactions`;
/*FBEND*/
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `workspace_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `direction` enum('in','out') NOT NULL,
  `kind` enum('income','expense','collection','payment','transfer','fx','card_payment','loan_payment','loan_proceeds','adjustment','owner_in','owner_out') NOT NULL,
  `amount_minor` bigint(20) NOT NULL,
  `interest_minor` bigint(20) NOT NULL DEFAULT 0,
  `currency` char(3) NOT NULL,
  `txn_date` date NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `entry_id` bigint(20) unsigned DEFAULT NULL,
  `card_id` bigint(20) unsigned DEFAULT NULL,
  `loan_id` bigint(20) unsigned DEFAULT NULL,
  `loan_installment_id` bigint(20) unsigned DEFAULT NULL,
  `transfer_group` varchar(26) DEFAULT NULL,
  `fx_rate` decimal(18,8) DEFAULT NULL,
  `vat_rate_bp` int(11) NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) NOT NULL DEFAULT 0,
  `status` enum('posted','voided') NOT NULL DEFAULT 'posted',
  `void_reason` varchar(300) DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `voided_by` bigint(20) unsigned DEFAULT NULL,
  `replaces_id` bigint(20) unsigned DEFAULT NULL,
  `statement_line_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `reason` varchar(300) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `method` varchar(30) DEFAULT NULL,
  `for_workspace_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tx_acc` (`tenant_id`,`account_id`,`status`),
  KEY `ix_tx_date` (`tenant_id`,`txn_date`),
  KEY `ix_tx_entry` (`entry_id`),
  KEY `ix_tx_group` (`transfer_group`),
  KEY `fk_tx_a` (`account_id`),
  KEY `ix_tx_contact` (`tenant_id`,`contact_id`),
  KEY `ix_tx_forws` (`tenant_id`,`for_workspace_id`),
  CONSTRAINT `fk_tx_a` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `fk_tx_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `transactions` VALUES ('1','1','1','1','in','collection','6000000','0','TRY','2026-10-20','Tahsilat: Büyük satış',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:34',NULL,NULL,NULL,NULL),('2','1','1','1','in','collection','4000000','0','TRY','2026-10-20','Tahsilat: Büyük satış',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:34',NULL,NULL,NULL,NULL),('3','1','1','1','out','transfer','2000000','0','TRY','2026-10-20','Transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'785f5684783ad8dc07a502189a',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:34',NULL,NULL,NULL,NULL),('4','1','1','2','in','transfer','2000000','0','TRY','2026-10-20','Transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'785f5684783ad8dc07a502189a',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:34',NULL,NULL,NULL,NULL),('5','1','1','1','in','collection','120000','0','TRY','2026-10-20','Tahsilat: Satış faturası FB-2026-001 — Müşteri A',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:35',NULL,NULL,NULL,NULL),('6','1','1','1','out','fx','1000000','0','TRY','2026-10-20','Döviz: TRY→EUR kur 0.02500000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'30c779aa29b1a4afb61e2971c0','0.02500000','0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:35',NULL,NULL,NULL,NULL),('7','1','1','3','in','fx','25000','0','EUR','2026-10-20','Döviz: TRY→EUR kur 0.02500000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'30c779aa29b1a4afb61e2971c0','0.02500000','0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:35',NULL,NULL,NULL,NULL),('8','1','1','1','out','expense','1500','0','TRY','2026-10-20','Döviz işlem masrafı','14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:35',NULL,NULL,NULL,NULL),('9','1','1','1','out','payment','300000','0','TRY','2026-10-20','Ödeme: Tedarikçi borcu',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:35',NULL,NULL,NULL,NULL),('10','1','1','1','out','card_payment','40000','0','TRY','2026-10-20','Kart ödemesi: Kurumsal Kart',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:36',NULL,NULL,NULL,NULL),('11','1','1','1','in','loan_proceeds','12000000','0','TRY','2026-10-20','Kredi kullandırım: İşletme Kredisi',NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:36',NULL,NULL,NULL,NULL),('12','1','1','1','out','loan_payment','1134715','240000','TRY','2026-10-20','Kredi taksiti 1/12: İşletme Kredisi',NULL,NULL,NULL,NULL,NULL,'1','1',NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:36',NULL,NULL,NULL,NULL),('13','1','1','1','in','income','25000','0','TRY','2026-10-20','POS TAHSILAT','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,'1','2','2026-10-19 22:00:37',NULL,NULL,NULL,NULL),('14','1','1','1','in','collection','1200000','0','TRY','2026-10-20','Tahsilat: Satış faturası PR-1 — Müşteri A',NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:37',NULL,NULL,NULL,NULL),('15','1','1','1','out','payment','480000','0','TRY','2026-10-20','Ödeme: Alış faturası ALIS-9 — Tedarikçi B',NULL,'2','1',NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:37',NULL,NULL,NULL,NULL),('16','1','1','1','out','expense','50000','0','TRY','2026-10-20','Yakıt','6',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:37',NULL,NULL,NULL,NULL),('17','1','1','1','in','income','100000','0','TRY','2026-10-20','Çift tık testi','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','Hatalı giriş','2026-10-19 22:00:38','2',NULL,NULL,'2','2026-10-19 22:00:38',NULL,NULL,NULL,NULL),('18','1','1','1','out','expense','10000','0','TRY','2026-10-20','eski',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','Düzenleme ile yenisi oluşturuldu','2026-10-19 22:00:38','2',NULL,NULL,'2','2026-10-19 22:00:38',NULL,NULL,NULL,NULL),('19','1','1','1','out','expense','12000','0','TRY','2026-10-20','düzeltilmiş',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,'18',NULL,'2','2026-10-19 22:00:38',NULL,NULL,NULL,NULL),('20','1','1','1','out','expense','120000','0','TRY','2026-10-20','KDV dahil',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2000','20000','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:38',NULL,NULL,NULL,NULL),('21','1','1','1','out','expense','120000','0','TRY','2026-10-20','KDV hariç',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2000','20000','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:38',NULL,NULL,NULL,NULL),('22','1','1','2','out','adjustment','5000','0','TRY','2026-10-20','Bakiye düzeltme: Sayım farkı',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:38',NULL,NULL,NULL,NULL),('23','1','1','1','out','expense','100','0','TRY','2026-10-20','=HYPERLINK(\"http://evil\",\"x\")',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:00:39',NULL,NULL,NULL,NULL),('24','1','1','1','out','expense','7700','0','TRY','2026-10-20','admin düzeltilecek',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','[Yönetici düzeltmesi] Mükerrer giriş','2026-10-19 22:01:01','1',NULL,NULL,'2','2026-10-19 22:01:01',NULL,NULL,NULL,NULL),('25','1','1','1','out','payment','400000','0','TRY','2026-10-20','Ödeme: Alış faturası T4-5-55bb — Tedarikçi B',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:02','Kısmi ödeme',NULL,NULL,NULL),('26','1','1','1','out','payment','600000','0','TRY','2026-10-20','Ödeme: Alış faturası T4-5-55bb — Tedarikçi B',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:02',NULL,NULL,NULL,NULL),('27','1','1','1','out','payment','3000000','0','TRY','2026-10-20','Toplu gönderim',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:03',NULL,NULL,NULL,NULL),('28','1','1','1','out','payment','5000000','0','TRY','2026-10-20','Ödeme: Alış faturası T4-7-976b — Tedarikçi B',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','test iptal','2026-10-19 22:01:04','2',NULL,NULL,'2','2026-10-19 22:01:03',NULL,NULL,NULL,NULL),('29','1','1','2','out','payment','10000','0','TRY','2026-10-20','çift tık',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:04',NULL,NULL,NULL,NULL),('30','1','1','1','out','payment','7000','0','TRY','2026-10-20','Ödeme',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:04',NULL,'DKN-77',NULL,NULL),('31','1','1','1','out','payment','7000','0','TRY','2026-10-20','Ödeme',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:04',NULL,'DKN-77',NULL,NULL),('32','1','1','1','in','collection','800000','0','TRY','2026-10-20','Tahsilat: Satış faturası T4-10-dfcb — Müşteri A',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:04',NULL,NULL,NULL,NULL),('33','1','1','1','in','collection','50000','0','TRY','2026-10-20','Tahsilat: Satış faturası T4-S-NO — Müşteri A',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:06',NULL,NULL,NULL,NULL),('34','1','2','5','out','payment','2000000','0','TRY','2026-10-20','dekont eklendi',NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:06','Güncel neden','SAHSI-1','transfer','1'),('35','1','2','5','out','owner_in','700000','0','TRY','2026-10-20','Sermaye',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'17911928cfdcd0bef2f875d92d',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:07',NULL,NULL,NULL,NULL),('36','1','1','1','in','owner_in','700000','0','TRY','2026-10-20','Sermaye',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'17911928cfdcd0bef2f875d92d',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:07',NULL,NULL,NULL,NULL),('37','1','1','1','out','owner_out','2700000','0','TRY','2026-10-20','Geri ödeme',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fab92ee8f8b66fbc2e7350a4d5',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:07',NULL,NULL,NULL,NULL),('38','1','2','5','in','owner_out','2700000','0','TRY','2026-10-20','Geri ödeme',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fab92ee8f8b66fbc2e7350a4d5',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:07',NULL,NULL,NULL,NULL),('39','1','1','1','out','transfer','1000','0','TRY','2026-10-20','iç transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'79d48162b95819a7c9662a39d3',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:07',NULL,NULL,NULL,NULL),('40','1','1','2','in','transfer','1000','0','TRY','2026-10-20','iç transfer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'79d48162b95819a7c9662a39d3',NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:07',NULL,NULL,NULL,NULL),('41','1','2','5','out','payment','4000','0','TRY','2026-10-20','Ödeme: Su',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:07',NULL,NULL,NULL,NULL),('42','1','1','1','in','collection','3000000','0','TRY','2026-10-20','Tahsilat: Satış faturası HOME-1 — Avans Müşterisi',NULL,'4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:08',NULL,NULL,NULL,NULL),('43','1','1','1','in','collection','3000000','0','TRY','2026-10-20','Avans',NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:09',NULL,NULL,NULL,NULL),('44','1','1','1','in','income','7700','0','TRY','2026-10-20',NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','test','2026-10-19 22:01:09','2',NULL,NULL,'2','2026-10-19 22:01:09',NULL,NULL,NULL,NULL),('45','1','1','1','in','collection','50000','0','TRY','2026-10-20',NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','voided','test temizliği','2026-10-19 22:01:09','2',NULL,NULL,'2','2026-10-19 22:01:09',NULL,NULL,NULL,NULL),('46','1','1','1','in','collection','7000000','0','TRY','2026-10-20','Tahsilat: Satış faturası HOME-2 — Avans Müşterisi 2',NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','posted',NULL,NULL,NULL,NULL,NULL,'2','2026-10-19 22:01:09',NULL,NULL,NULL,NULL);
/*FBEND*/
DROP TABLE IF EXISTS `users`;
/*FBEND*/
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `email` varchar(190) NOT NULL,
  `display_name` varchar(160) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL,
  `admin_flag` tinyint(4) DEFAULT NULL,
  `status` enum('active','suspended','archived') NOT NULL DEFAULT 'active',
  `must_change_password` tinyint(4) NOT NULL DEFAULT 0,
  `email_verified_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(64) DEFAULT NULL,
  `prev_login_at` datetime DEFAULT NULL,
  `prev_login_ip` varchar(64) DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `lock_level` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `totp_secret_enc` text DEFAULT NULL,
  `totp_enabled` tinyint(4) NOT NULL DEFAULT 0,
  `totp_last_step` bigint(20) DEFAULT NULL,
  `recovery_codes` text DEFAULT NULL,
  `session_epoch` int(11) NOT NULL DEFAULT 1,
  `password_changed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_users_email` (`email`),
  UNIQUE KEY `ux_users_admin` (`admin_flag`),
  KEY `ix_users_tenant` (`tenant_id`),
  CONSTRAINT `fk_users_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `users` VALUES ('1',NULL,'owner@test.local','Yönetici','$argon2id$v=19$m=19456,t=2,p=1$aXRYZWo2UEx1bXJZV2Q0cQ$UCoBMrOfWbbK4vTE8NOFg1hRPVbqxLJxGCE05DTkv5E','admin','1','active','0','2026-10-19 21:58:03','2026-10-19 22:01:31','127.0.0.1','2026-10-19 22:01:01','127.0.0.1','0','0',NULL,'JLJx1lR8pLhRbWa3a68Nr60b3kt1KYsDOi3gsXJGGquB+GPgy+7aIXHBW5dCwmpHjYkAEZIQnZlvrh2h','1','59748244','[\"cd5a65ad87c394de5ff67b31e880093331016331dc9e13ea50cdc2016400f01a\",\"4d289b4ebfdc7e4eac441f688a883cace8276072b14affb32484fb5e6b7b4483\",\"c9bb7758603860dcbfc6c8dc6fd2e3cd3a3e7f1d813a983774893512e7ca321c\",\"05413146a4bb641b6fc8d855da769226ae9d946f806a862dc4b357f5896a514a\",\"f3a65a577b130e9b44d6f3cfcb67c82117d873d5f547acc98cb4ad5400a86f8b\",\"36877e90798ec67413e2865f429b4ea8dcc7270fe46e010ce6ad6b905623baad\",\"50d967c2483aab5133228f441c30fb164350b824278cc24719594bb134034c5a\",\"39ed8d36f155fde543def7975c4c4a176bd9e7b68c8bfe06e2744ab48dbc5a29\"]','2','2026-10-19 21:58:03','2026-10-19 21:58:03'),('2','1','alfa@test.local','Hile','$argon2id$v=19$m=19456,t=2,p=1$OXdaWVU0M0p4TS8ycGRqbQ$wcHUoiWEnCO/GSDQKq7UGyHLVDFhqGVDuZeeoPfueTw','customer',NULL,'active','0','2026-10-19 22:00:31','2026-10-19 22:01:09','127.0.0.1','2026-10-19 22:01:08','127.0.0.1','0','0',NULL,NULL,'0',NULL,NULL,'4','2026-10-19 22:00:33','2026-10-19 22:00:30'),('3','2','beta@test.local','Beta AŞ','$argon2id$v=19$m=19456,t=2,p=1$MVAwSTVMdWxBeEJyNmhBag$gMuwGLJ/bB5vyAUCn1pnXXBiJzg6gFl31A4MPU7zflM','customer',NULL,'active','0',NULL,'2026-10-19 22:01:08','127.0.0.1','2026-10-19 22:01:02','127.0.0.1','0','0',NULL,NULL,'0',NULL,NULL,'3','2026-10-19 22:00:31','2026-10-19 22:00:31');
/*FBEND*/
DROP TABLE IF EXISTS `warehouses`;
/*FBEND*/
CREATE TABLE `warehouses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_wh` (`tenant_id`,`name`),
  CONSTRAINT `fk_wh_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `warehouses` VALUES ('1','1','Ana Depo','0');
/*FBEND*/
DROP TABLE IF EXISTS `workspaces`;
/*FBEND*/
CREATE TABLE `workspaces` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `kind` enum('business','personal') NOT NULL DEFAULT 'business',
  `legal_name` varchar(200) DEFAULT NULL,
  `tax_no` varchar(30) DEFAULT NULL,
  `color` varchar(9) DEFAULT NULL,
  `archived` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_ws_name` (`tenant_id`,`name`),
  CONSTRAINT `fk_ws_t` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*FBEND*/
INSERT INTO `workspaces` VALUES ('1','1','Horizon','business',NULL,NULL,NULL,'0','2026-10-19 22:00:34'),('2','1','Şahsi','personal',NULL,NULL,NULL,'0','2026-10-19 22:00:34'),('3','2','Beta Ortak','business',NULL,NULL,NULL,'0','2026-10-19 22:00:39');
/*FBEND*/
SET FOREIGN_KEY_CHECKS=1;
/*FBEND*/
/*FBCOUNTS {"accounts":7,"audit_log":207,"budgets":1,"captchas":40,"card_installments":3,"card_purchases":1,"cards":1,"categories":34,"contacts":5,"documents":4,"entries":33,"fx_rates":2,"idempotency_keys":25,"invoice_lines":27,"invoices":24,"loan_installments":12,"loans":1,"login_tickets":10,"password_tokens":2,"payment_allocations":21,"project_milestones":1,"project_quotes":0,"projects":1,"rate_limits":21,"recurring_templates":1,"schema_migrations":4,"sessions":25,"statement_lines":3,"stock_items":8,"stock_movements":12,"system_settings":0,"tenants":2,"transactions":46,"users":3,"warehouses":1,"workspaces":3}*/
